import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button.jsx';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Shield, FileCheck, Boxes, ArrowRight, AlertTriangle, CheckCircle2, BookOpen } from 'lucide-react';

const Home = ({ username }) => {
  const navigate = useNavigate();

  const features = [
    {
      icon: Shield,
      title: 'Security-First Approach',
      description: 'Built on OWASP Top 10 for LLMs and AWS security best practices'
    },
    {
      icon: FileCheck,
      title: 'Dual Assessment',
      description: 'Concept Review (pre-development) and Product Review (post-development)'
    },
    {
      icon: Boxes,
      title: 'Platform Compatibility',
      description: '11 Low Code and 4 High Code platforms with data type validation'
    }
  ];

  const assessmentCards = [
    {
      title: 'Concept Review',
      description: 'Pre-development security assessment for AI agent projects',
      icon: FileCheck,
      color: '#232F3E',
      route: '/concept-review',
      features: [
        'Pre-flight permission screening',
        '16-question risk assessment',
        'Platform compatibility check',
        'Data classification validation',
        'Risk scoring (0-40 scale)',
        'PDF report generation'
      ],
      recommended: 'Use before starting development'
    },
    {
      title: 'Product Review',
      description: 'Post-development security analysis with code/prompt scanning',
      icon: CheckCircle2,
      color: '#FF9900',
      route: '/product-review',
      features: [
        'Pre-flight permission screening',
        'Automated security analysis',
        'Low Code: Prompt security scan',
        'High Code: Code security scan',
        '16-question risk assessment',
        'Concept vs Product comparison',
        'PDF report with recommendations'
      ],
      recommended: 'Use after development completion'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-[#232F3E] to-[#37475A] text-white">
        <div className="max-w-7xl mx-auto px-6 py-16">
          <div className="max-w-3xl">
            <div className="flex items-center gap-3 mb-4">
              <Shield className="h-12 w-12 text-[#FF9900]" />
              <h1 className="text-5xl font-bold">SAFER-AI</h1>
            </div>
            {username && (
              <p className="text-lg text-[#FF9900] mb-2">Welcome back, {username}!</p>
            )}
            <p className="text-2xl font-semibold mb-4 text-gray-200">
              Security Assessment Framework for Evaluating Risk in AI Agents
            </p>
            <p className="text-lg text-gray-300 leading-relaxed">
              A comprehensive security assessment tool designed specifically for Amazon developers building AI agent projects. 
              SAFER-AI helps you evaluate security risks, ensure platform compatibility, and maintain compliance with AWS data handling policies.
            </p>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="max-w-7xl mx-auto px-6 py-12 flex-1">
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <Card key={index} className="border-2 border-gray-200 hover:border-[#FF9900] transition-colors">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <div className="p-3 bg-[#232F3E] rounded-lg">
                      <Icon className="h-6 w-6 text-white" />
                    </div>
                    <CardTitle className="text-lg">{feature.title}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">{feature.description}</p>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Quick Start Section */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">Choose Your Assessment</h2>
          <div className="grid md:grid-cols-2 gap-8">
            {assessmentCards.map((card, index) => {
              const Icon = card.icon;
              return (
                <Card key={index} className="border-2 hover:shadow-xl transition-shadow" style={{ borderColor: card.color }}>
                  <CardHeader className="bg-white border-b-2" style={{ borderColor: card.color }}>
                    <div className="flex items-center gap-3 mb-2">
                      <div className="p-3 rounded-lg" style={{ backgroundColor: card.color }}>
                        <Icon className="h-8 w-8 text-white" />
                      </div>
                      <div>
                        <CardTitle className="text-2xl">{card.title}</CardTitle>
                        <CardDescription className="text-base mt-1">{card.description}</CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="p-6">
                    <div className="mb-6">
                      <div className="inline-block px-3 py-1 rounded-full text-sm font-semibold mb-4" 
                           style={{ backgroundColor: `${card.color}20`, color: card.color }}>
                        {card.recommended}
                      </div>
                      <ul className="space-y-2">
                        {card.features.map((feature, idx) => (
                          <li key={idx} className="flex items-start gap-2 text-gray-700">
                            <CheckCircle2 className="h-5 w-5 flex-shrink-0 mt-0.5" style={{ color: card.color }} />
                            <span>{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                    <Button 
                      onClick={() => navigate(card.route)}
                      className="w-full text-white font-semibold"
                      style={{ backgroundColor: card.color }}
                    >
                      Start {card.title}
                      <ArrowRight className="ml-2 h-5 w-5" />
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Platform Mechanism Section */}
        <Card className="border-2 border-[#232F3E] mb-12">
          <CardHeader className="bg-gradient-to-r from-[#232F3E] to-[#37475A] text-white">
            <div className="flex items-center gap-3">
              <Boxes className="h-8 w-8 text-[#FF9900]" />
              <div>
                <CardTitle className="text-2xl">Platform & Data Compatibility</CardTitle>
                <CardDescription className="text-gray-200 text-base">
                  Explore supported platforms and data type compatibility matrix
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-6">
            <div className="grid md:grid-cols-2 gap-6 mb-6">
              <div>
                <h3 className="font-semibold text-lg mb-3 text-gray-900">Low Code Platforms (11)</h3>
                <ul className="space-y-1 text-gray-700">
                  <li>• Party Rock, Cedric, Amazon Q Internal</li>
                  <li>• Mentor, Field Advisor, Matome</li>
                  <li>• BedrockBot, Loki, Clue</li>
                  <li>• PowerChat, AssistAPN</li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold text-lg mb-3 text-gray-900">High Code Platforms (4)</h3>
                <ul className="space-y-1 text-gray-700">
                  <li>• AWS Bedrock RAG Agent</li>
                  <li>• AWS Bedrock Multi-Agent</li>
                  <li>• AWS Lambda Function</li>
                  <li>• Custom GenAI Solution</li>
                </ul>
              </div>
            </div>
            <Button 
              onClick={() => navigate('/mechanism')}
              variant="outline"
              className="w-full border-2 border-[#232F3E] text-[#232F3E] hover:bg-[#232F3E] hover:text-white font-semibold"
            >
              <BookOpen className="mr-2 h-5 w-5" />
              View Complete Compatibility Matrix
            </Button>
          </CardContent>
        </Card>

        {/* Important Notes */}
        <div className="grid md:grid-cols-2 gap-6">
          <Card className="border-l-4 border-l-[#FF9900] bg-orange-50">
            <CardHeader>
              <div className="flex items-center gap-2">
                <AlertTriangle className="h-6 w-6 text-[#FF9900]" />
                <CardTitle className="text-lg">Data Restrictions</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-gray-700 mb-2">
                <strong>Not allowed on any Low Code platform:</strong>
              </p>
              <ul className="list-disc list-inside text-gray-700 space-y-1">
                <li>Customer Content</li>
                <li>Customer-Created Metadata</li>
                <li>Highly Sensitive Security Data</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-[#232F3E] bg-blue-50">
            <CardHeader>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-6 w-6 text-[#232F3E]" />
                <CardTitle className="text-lg">Assessment Benefits</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <ul className="list-disc list-inside text-gray-700 space-y-1">
                <li>Identify security risks early</li>
                <li>Ensure platform compatibility</li>
                <li>Generate compliance reports</li>
                <li>Get SWAT team recommendations</li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-[#232F3E] text-white py-6 mt-16">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center">
            <p className="text-sm text-gray-400">© GNSS - Security Workspace and Access Team</p>
            <div className="mt-2 flex justify-center gap-6 text-sm">
              <a href="https://w.amazon.com/bin/view/PSAS-Ops-Security/Internal/AIGuardian/" className="hover:text-[#FF9900] transition-colors">Wiki</a>
              <a href="https://app.asana.com/1/8442528107068/project/1211625440332553/list/1211625749296635" className="hover:text-[#FF9900] transition-colors">Contact SWAT Team</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Home;