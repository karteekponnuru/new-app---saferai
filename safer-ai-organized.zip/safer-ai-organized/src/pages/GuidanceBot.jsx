import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button.jsx';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { X, ArrowRight, MessageCircle } from 'lucide-react';

const GuidanceBot = ({ onComplete }) => {
  const navigate = useNavigate();
  const [showChat, setShowChat] = useState(false);
  const [chatFlow, setChatFlow] = useState(null);
  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers] = useState({});
  const [chatHistory, setChatHistory] = useState([]);

  const chatFlows = {
    getting_started: [
      {
        id: 'start',
        question: 'What are you trying to build or automate?',
        options: [
          { text: 'Summarize or analyze internal data', next: 'data_check' },
          { text: 'Automate TT or SIM workflows', result: 'swat_review' },
          { text: 'Generate or review documents (PRFAQ, MBR, etc.)', next: 'data_check' },
          { text: 'Integrate with external tools or APIs', result: 'tt_required' },
          { text: 'Build a new GenAI app or model', result: 'swat_review' }
        ]
      },
      {
        id: 'data_check',
        question: 'What kind of data will your agent use?',
        options: [
          { text: 'Customer data or content', result: 'swat_review' },
          { text: 'AWS Support data', next: 'app_selection' },
          { text: 'Internal business docs/contracts', next: 'app_selection' },
          { text: 'Employee or operational data', next: 'app_selection' },
          { text: 'Public/non-sensitive data', result: 'safe_proceed' }
        ]
      },
      {
        id: 'app_selection',
        question: 'Which app or tool are you planning to use?',
        options: [
          { text: 'Cedric', result: 'safe_proceed' },
          { text: 'Amazon Q Internal', result: 'safe_proceed' },
          { text: 'Mentor', result: 'safe_proceed' },
          { text: 'Party Rock', result: 'safe_proceed' },
          { text: 'Other / Not sure', result: 'safe_proceed' }
        ]
      }
    ],
    questions: [
      {
        id: 'start',
        question: 'Will your automation access or modify TTs or SIMs?',
        options: [
          { text: 'Yes', result: 'swat_review' },
          { text: 'No', next: 'data_usage' }
        ]
      },
      {
        id: 'data_usage',
        question: 'Will your agent process customer data or internal operational data?',
        options: [
          { text: 'Customer Data', result: 'swat_review' },
          { text: 'Internal Data', next: 'access_check' }
        ]
      },
      {
        id: 'access_check',
        question: 'Does your agent require Unfettered Search or Case Locker access?',
        options: [
          { text: 'Yes', result: 'swat_review' },
          { text: 'No', next: 'integration_check' }
        ]
      },
      {
        id: 'integration_check',
        question: 'Will your agent use or share data with external tools (like Slack, Google Sheets, or APIs)?',
        options: [
          { text: 'Yes', result: 'tt_required' },
          { text: 'No', result: 'safe_proceed' }
        ]
      }
    ],
    ready_to_build: [
      {
        id: 'start',
        question: 'Have you already designed your agent or automation?',
        options: [
          { text: 'Yes, ready for review', result: 'start_review' },
          { text: 'Still planning', next: 'use_case' }
        ]
      },
      {
        id: 'use_case',
        question: 'What will your agent do?',
        options: [
          { text: 'Document summarization', next: 'data_type' },
          { text: 'Ticket automation', result: 'swat_review' },
          { text: 'Data analysis', next: 'data_type' },
          { text: 'External integration', result: 'tt_required' }
        ]
      },
      {
        id: 'data_type',
        question: 'What data will it use?',
        options: [
          { text: 'Internal documents', result: 'safe_proceed' },
          { text: 'Customer data', result: 'swat_review' },
          { text: 'Public data', result: 'safe_proceed' }
        ]
      }
    ]
  };

  const getResult = (resultType) => {
    const results = {
      safe_proceed: {
        icon: '✅',
        title: 'Safe to Build',
        message: 'Your idea aligns with policy and approved use cases. You can proceed with development.',
        action: 'Proceed to SAFER-AI Portal',
        color: 'bg-green-50 border-green-200',
        onClick: () => onComplete()
      },
      tt_required: {
        icon: '⚠️',
        title: 'Needs TT',
        message: 'External integration or special API use requires visibility. Please raise a TT for security vetting.',
        action: 'Raise a Consultation Request',
        color: 'bg-yellow-50 border-yellow-200',
        link: 'https://app.asana.com/1/8442528107068/project/1211625440332553/list/1211625749296635'
      },
      swat_review: {
        icon: '🔴',
        title: 'Requires Security Review',
        message: 'Customer data, UFS, or production system access detected. Security consultation required before proceeding.',
        action: 'Raise a Consultation Request with SWAT Team',
        color: 'bg-red-50 border-red-200',
        link: 'https://app.asana.com/1/8442528107068/project/1211625440332553/list/1211625749296635'
      },
      start_review: {
        icon: '⚙️',
        title: 'Ready for Review',
        message: 'Great! You can start the formal review process.',
        action: 'Go to Concept Review',
        color: 'bg-blue-50 border-blue-200',
        onClick: () => {
          onComplete();
          navigate('/concept-review');
        }
      }
    };
    return results[resultType] || results.safe_proceed;
  };

  const startChat = (flow) => {
    setChatFlow(flow);
    setCurrentStep(0);
    setAnswers({});
    setChatHistory([]);
    setShowChat(true);
  };

  const closeChat = () => {
    setShowChat(false);
    setChatFlow(null);
    setCurrentStep(0);
    setAnswers({});
    setChatHistory([]);
  };

  const handleAnswer = (question, answer) => {
    const newAnswers = { ...answers, [question]: answer };
    setAnswers(newAnswers);
    setChatHistory([...chatHistory, { question, answer }]);

    const flow = chatFlows[chatFlow];
    const currentQuestion = flow.find(q => q.question === question);
    const selectedOption = currentQuestion.options.find(opt => opt.text === answer);

    if (selectedOption.next) {
      const nextQuestionIndex = flow.findIndex(q => q.id === selectedOption.next);
      setCurrentStep(nextQuestionIndex);
    }
  };

  const getCurrentQuestion = () => {
    const flow = chatFlows[chatFlow];
    if (!flow || currentStep >= flow.length) return null;
    return flow[currentStep];
  };

  const renderChatContent = () => {
    const currentQuestion = getCurrentQuestion();
    
    if (!currentQuestion) return null;

    // Check if we have a result from the last answer
    if (chatHistory.length > 0) {
      const lastAnswer = chatHistory[chatHistory.length - 1];
      const flow = chatFlows[chatFlow];
      const lastQuestion = flow.find(q => q.question === lastAnswer.question);
      if (lastQuestion) {
        const selectedOption = lastQuestion.options.find(opt => opt.text === lastAnswer.answer);
        if (selectedOption?.result) {
          const result = getResult(selectedOption.result);
          return (
            <div>
              {/* Show chat history */}
              <div className="mb-6 space-y-4">
                {chatHistory.map((item, idx) => (
                  <div key={idx} className="space-y-2">
                    <div className="p-3 bg-gray-100 rounded-lg">
                      <p className="font-medium text-gray-700">{item.question}</p>
                    </div>
                    <div className="p-3 bg-[#FF9900] bg-opacity-10 rounded-lg ml-8">
                      <p className="text-gray-900">{item.answer}</p>
                    </div>
                  </div>
                ))}
              </div>
              
              {/* Result */}
              <div className={`p-6 rounded-lg border-2 ${result.color}`}>
                <div className="text-4xl mb-4">{result.icon}</div>
                <h3 className="text-xl font-bold mb-2">{result.title}</h3>
                <p className="mb-4 text-gray-700">{result.message}</p>
                {result.link ? (
                  <a href={result.link} target="_blank" rel="noopener noreferrer">
                    <Button className="bg-[#FF9900] hover:bg-[#ec8f00]">
                      {result.action} <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </a>
                ) : (
                  <Button className="bg-[#FF9900] hover:bg-[#ec8f00]" onClick={result.onClick}>
                    {result.action} <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                )}
              </div>
            </div>
          );
        }
      }
    }

    return (
      <div>
        {/* Show chat history */}
        {chatHistory.length > 0 && (
          <div className="mb-6 space-y-4">
            {chatHistory.map((item, idx) => (
              <div key={idx} className="space-y-2">
                <div className="p-3 bg-gray-100 rounded-lg">
                  <p className="font-medium text-gray-700">{item.question}</p>
                </div>
                <div className="p-3 bg-[#FF9900] bg-opacity-10 rounded-lg ml-8">
                  <p className="text-gray-900">{item.answer}</p>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Current question */}
        <div className="mb-6">
          <div className="p-4 bg-gray-100 rounded-lg mb-4">
            <p className="text-lg font-medium text-gray-800">{currentQuestion.question}</p>
          </div>
          <div className="space-y-2">
            {currentQuestion.options.map((option, idx) => (
              <Button
                key={idx}
                onClick={() => handleAnswer(currentQuestion.question, option.text)}
                className="w-full justify-start text-left bg-white hover:bg-[#FF9900] hover:text-white text-gray-900 border-2 border-gray-300 hover:border-[#FF9900] transition-all"
              >
                {option.text}
              </Button>
            ))}
          </div>
        </div>
      </div>
    );
  };

  const mainOptions = [
    {
      icon: '🚀',
      title: 'Getting Started',
      description: 'I want to build an agent but don\'t know where to start',
      action: () => startChat('getting_started')
    },
    {
      icon: '✍️',
      title: 'Secure Prompt Writing',
      description: 'I want to know how to write a prompt in a secure way',
      action: () => window.open('https://w.amazon.com/bin/view/Security/AI-Security/GenAI-Sec/Toolkit/Testing/Framework/v2/', '_blank')
    },
    {
      icon: '🔍',
      title: 'Concept Review',
      description: 'I have an idea and want it reviewed for security assessment',
      action: () => {
        onComplete();
        navigate('/concept-review');
      }
    },
    {
      icon: '✅',
      title: 'Product Review',
      description: 'I have a product/agent ready and completed concept review',
      action: () => {
        onComplete();
        navigate('/product-review');
      }
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-[#232F3E] text-white py-4 px-8 border-b border-gray-700">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-3">
            <MessageCircle className="h-8 w-8 text-[#FF9900]" />
            <div>
              <h1 className="text-2xl font-bold">SAFER-AI Guidance Bot</h1>
              <p className="text-sm text-gray-300">Your AI Security Assistant</p>
            </div>
          </div>
          <Button 
            onClick={onComplete}
            variant="outline"
            className="border-[#FF9900] text-[#FF9900] hover:bg-[#FF9900] hover:text-white"
          >
            Skip to Portal
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-8 py-16">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Welcome! How can I help you today?</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            I'm here to guide you through building secure AI agents. Select an option below to get started.
          </p>
        </div>

        {/* Options Grid */}
        <div className="grid md:grid-cols-2 gap-6 max-w-5xl mx-auto">
          {mainOptions.map((option, index) => (
            <Card 
              key={index} 
              className="hover:shadow-xl transition-all cursor-pointer border-2 border-gray-200 bg-white hover:border-[#FF9900] hover:scale-105"
              onClick={option.action}
            >
              <CardHeader>
                <CardTitle className="flex items-center gap-3 text-2xl">
                  <span className="text-4xl">{option.icon}</span>
                  {option.title}
                </CardTitle>
                <CardDescription className="text-base text-gray-600 mt-2">
                  {option.description}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button 
                  className="w-full bg-[#FF9900] hover:bg-[#ec8f00] text-white font-semibold"
                >
                  {option.title === 'Secure Prompt Writing' ? 'View Wiki' : 'Get Started'}
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Help Section */}
        <div className="mt-16 max-w-4xl mx-auto">
          <Card className="bg-white border-2 border-[#FF9900]">
            <CardHeader>
              <CardTitle className="text-xl text-center text-gray-900">Need More Help?</CardTitle>
            </CardHeader>
            <CardContent className="text-center">
              <p className="text-gray-700 mb-4">
                For complex queries or additional security guidance, reach out to the SWAT Team
              </p>
              <a 
                href="https://app.asana.com/1/8442528107068/project/1211625440332553/list/1211625749296635" 
                target="_blank" 
                rel="noopener noreferrer"
              >
                <Button className="bg-[#232F3E] hover:bg-[#37475A] text-white">
                  Contact SWAT Team
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </a>
            </CardContent>
          </Card>
        </div>
      </main>

      {/* Chat Modal */}
      {showChat && (
        <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-2xl w-full max-w-3xl max-h-[85vh] overflow-hidden flex flex-col">
            <div className="bg-[#232F3E] text-white p-4 flex justify-between items-center">
              <div className="flex items-center gap-3">
                <MessageCircle className="h-6 w-6 text-[#FF9900]" />
                <h3 className="text-xl font-bold">Guidance Bot</h3>
              </div>
              <button 
                onClick={closeChat} 
                className="hover:bg-[#FF9900] p-2 rounded transition-colors"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="p-6 overflow-y-auto flex-1">
              <div className="mb-6 p-4 bg-[#FF9900] bg-opacity-10 rounded-lg border-l-4 border-[#FF9900]">
                <p className="text-gray-800">
                  👋 Hi! I'm your Guidance Bot. Let's figure out if your idea or automation is safe to build.
                </p>
              </div>
              {renderChatContent()}
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 py-6 mt-16">
        <div className="max-w-7xl mx-auto px-8 text-center text-sm text-gray-600">
          © CTOSS GNSS Team - Amazon Selling Partner Support
        </div>
      </footer>
    </div>
  );
};

export default GuidanceBot;