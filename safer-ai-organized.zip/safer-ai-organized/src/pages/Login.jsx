import React, { useState, useEffect } from 'react';
import { useAuth } from 'react-oidc-context';
import { Button } from '@/components/ui/button.jsx';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Shield, User, Loader2 } from 'lucide-react';

const Login = ({ onLogin }) => {
  const auth = useAuth();
  const [username, setUsername] = useState('');
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  // Check if already authenticated
  useEffect(() => {
    if (auth.isAuthenticated) {
      console.log('✅ Already authenticated, calling onLogin');
      const userEmail = auth.user?.profile?.email || auth.user?.profile?.preferred_username || username;
      if (onLogin) {
        onLogin(userEmail);
      }
    }
  }, [auth.isAuthenticated]);

  const handleLogin = async (e) => {
    e.preventDefault();
    
    if (!username.trim()) {
      return;
    }

    try {
      setIsLoggingIn(true);
      console.log('🔐 Starting authentication for:', username);
      
      // Store username for later use (optional)
      localStorage.setItem('pending_username', username.trim());
      
      // Trigger Cognito/Federate OAuth flow
      console.log('🔄 Redirecting to Federate SSO...');
      await auth.signinRedirect({
        // Optional: You can pass the username as a hint
        extraQueryParams: {
          identity_provider: "FederateOIDC",
          login_hint: username.trim() // Some identity providers support this
        }
      });
    } catch (error) {
      console.error('❌ Login error:', error);
      setIsLoggingIn(false);
      alert('Login failed. Please try again.');
    }
  };

  // Show loading state while redirecting
  if (isLoggingIn || auth.isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#232F3E] via-[#37475A] to-[#232F3E] flex items-center justify-center p-4">
        <Card className="w-full max-w-md border-2 border-gray-700 shadow-2xl">
          <CardContent className="p-12">
            <div className="text-center">
              <Loader2 className="h-12 w-12 text-[#FF9900] animate-spin mx-auto mb-4" />
              <p className="text-gray-700 font-medium">Redirecting to Amazon SSO...</p>
              <p className="text-sm text-gray-500 mt-2">Please wait while we authenticate you</p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Show error state
  if (auth.error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#232F3E] via-[#37475A] to-[#232F3E] flex items-center justify-center p-4">
        <Card className="w-full max-w-md border-2 border-red-500 shadow-2xl">
          <CardHeader className="text-center">
            <div className="flex justify-center">
              <div className="p-4 bg-red-100 rounded-full">
                <Shield className="h-12 w-12 text-red-600" />
              </div>
            </div>
            <CardTitle className="text-2xl font-bold text-gray-900">Authentication Error</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="p-4 bg-red-50 border border-red-200 rounded-lg mb-4">
              <p className="text-sm text-red-800">{auth.error.message}</p>
            </div>
            <Button 
              onClick={() => {
                auth.removeUser();
                window.location.reload();
              }}
              className="w-full bg-[#FF9900] hover:bg-[#ec8f00] text-white font-semibold py-3"
            >
              Try Again
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#232F3E] via-[#37475A] to-[#232F3E] flex items-center justify-center p-4">
      <Card className="w-full max-w-md border-2 border-gray-700 shadow-2xl">
        <CardHeader className="text-center space-y-4">
          <div className="flex justify-center">
            <div className="p-4 bg-[#FF9900] rounded-full">
              <Shield className="h-12 w-12 text-white" />
            </div>
          </div>
          <div>
            <CardTitle className="text-3xl font-bold text-gray-900">SAFER-AI Portal</CardTitle>
            <CardDescription className="text-base mt-2">
              Security Assessment Framework for Evaluating Risk in AI Agents
            </CardDescription>
          </div>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label htmlFor="username" className="block text-sm font-medium text-gray-700 mb-2">
                Amazon Login
              </label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                <input
                  type="text"
                  id="username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Enter your Amazon login"
                  className="w-full pl-10 pr-4 py-3 border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-[#FF9900] focus:border-[#FF9900] outline-none transition-all"
                  required
                  disabled={isLoggingIn}
                />
              </div>
            </div>
            <Button 
              type="submit"
              className="w-full bg-[#FF9900] hover:bg-[#ec8f00] text-white font-semibold py-3 text-lg"
              disabled={isLoggingIn || !username.trim()}
            >
              {isLoggingIn ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  Authenticating...
                </>
              ) : (
                'Enter Portal'
              )}
            </Button>
          </form>
          <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <p className="text-sm text-gray-700">
              <strong>Note:</strong> You will be redirected to Amazon Federate for secure authentication.
            </p>
          </div>
          <div className="mt-4 p-4 bg-gray-50 border border-gray-200 rounded-lg">
            <p className="text-xs text-gray-600">
              🔒 <strong>Secure Login:</strong> This application uses Amazon Cognito with Federate OIDC for authentication. Your credentials are never stored in this application.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Login;