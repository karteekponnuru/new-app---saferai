import { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useLocation, Navigate } from 'react-router-dom';
import { Amplify } from '@aws-amplify/core';
import { withAuthenticator } from '@aws-amplify/ui-react';
import '@aws-amplify/ui-react/styles.css';
import { Button } from '@/components/ui/button.jsx';
import Login from './pages/Login';
import GuidanceBot from './pages/GuidanceBot';
import Home from './pages/Home';
import Mechanism from './pages/Mechanism';
import ConceptReview from './pages/ConceptReview';
import ProductReview from './pages/ProductReview';
import saferAIApi from './lib/api.js';
import './App.css';
import cognitoAuthConfig from './lib/amplifyConfig.js';

// Configure Amplify at app initialization
Amplify.configure(cognitoAuthConfig);

function Navigation({ username, signOut }) {
  const location = useLocation();
  
  const isActive = (path) => {
    return location.pathname === path;
  };

  return (
    <nav className="bg-[#232F3E] text-white py-4 px-8 border-b border-gray-700">
      <div className="max-w-7xl mx-auto flex justify-between items-center">
        <div className="flex gap-6">
          <Link to="/">
            <Button 
              variant="ghost" 
              className={`text-white hover:text-[#FF9900] hover:bg-transparent ${isActive('/') ? 'text-[#FF9900]' : ''}`}
            >
              Home
            </Button>
          </Link>
          <Link to="/mechanism">
            <Button 
              variant="ghost" 
              className={`text-white hover:text-[#FF9900] hover:bg-transparent ${isActive('/mechanism') ? 'text-[#FF9900]' : ''}`}
            >
              Mechanism
            </Button>
          </Link>
          <Link to="/concept-review">
            <Button 
              variant="ghost" 
              className={`text-white hover:text-[#FF9900] hover:bg-transparent ${isActive('/concept-review') ? 'text-[#FF9900]' : ''}`}
            >
              Concept Review
            </Button>
          </Link>
          <Link to="/product-review">
            <Button 
              variant="ghost" 
              className={`text-white hover:text-[#FF9900] hover:bg-transparent ${isActive('/product-review') ? 'text-[#FF9900]' : ''}`}
            >
              Product Review
            </Button>
          </Link>
        </div>
        <div className="flex items-center gap-4">
          {username && (
            <div className="text-sm text-gray-300">
              Welcome, <span className="text-[#FF9900] font-semibold">{username}</span>
            </div>
          )}
          <Button onClick={signOut} variant="ghost" className="text-white hover:text-[#FF9900] hover:bg-transparent">Sign Out</Button>
        </div>
      </div>
    </nav>
  );
}

function App({ signOut, user }) {
  const [showGuidance, setShowGuidance] = useState(false);
  const [username, setUsername] = useState('');

  useEffect(() => {
    if (user) {
      // Extract username from Amplify user attributes
      const userEmail = user.attributes?.email || user.username || 'User';
      setUsername(userEmail);
      console.log('👤 Logged in user:', userEmail);
      
      // Check if this is first login (no guidance completed flag)
      const guidanceCompleted = localStorage.getItem('guidance_completed');
      if (!guidanceCompleted) {
        setShowGuidance(true);
      }
    }
  }, [user]);

  const handleGuidanceComplete = () => {
    localStorage.setItem('guidance_completed', 'true');
    setShowGuidance(false);
  };

  if (showGuidance) {
    return <GuidanceBot onComplete={handleGuidanceComplete} />;
  }

  return (
    <Router>
      <div className="min-h-screen bg-white">
        <Navigation username={username} signOut={signOut} />
        <Routes>
          <Route path="/" element={<Home username={username} />} />
          <Route path="/mechanism" element={<Mechanism />} />
          <Route path="/concept-review" element={<ConceptReview />} />
          <Route path="/product-review" element={<ProductReview />} />
        </Routes>
      </div>
    </Router>
  );
}

export default withAuthenticator(App);
