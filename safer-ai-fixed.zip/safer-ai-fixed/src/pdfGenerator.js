import { PDFDocument, rgb, StandardFonts } from 'pdf-lib';
import { saveAs } from 'file-saver';

class Flow {
  constructor(pdfDoc, initialY = 750, pageOptions = [612, 792]) {
    this.pdfDoc = pdfDoc;
    this.pageOptions = pageOptions;
    this.currentPage = pdfDoc.addPage(this.pageOptions);
    this.y = initialY;
  }

  checkPageBreak(requiredSpace = 50) {
    if (this.y < requiredSpace) {
      this.currentPage = this.pdfDoc.addPage(this.pageOptions);
      this.y = 750;
      return true;
    }
    return false;
  }

  moveDown(amount) {
    this.y -= amount;
    this.checkPageBreak();
  }

  drawText(text, options) {
    this.checkPageBreak(options.size || 12);
    this.currentPage.drawText(text, { ...options, y: this.y });
    this.moveDown(options.lineHeight || (options.size || 12) + 4);
  }

  drawSmartText(text, options) {
    const {
      font, size, color, maxWidth, lineHeight
    } = options;

    const cleanText = String(text || '')
      .replace(/[^\x00-\x7F]/g, '');

    const paragraphs = cleanText.split('\n');

    for (const paragraph of paragraphs) {
      if (paragraph.trim() === '') {
        this.moveDown(lineHeight);
        continue;
      }

      const words = paragraph.split(' ');
      let line = '';

      for (let i = 0; i < words.length; i++) {
        const testLine = line + words[i] + ' ';
        const testWidth = font.widthOfTextAtSize(testLine, size);

        if (testWidth > maxWidth && line !== '') {
          this.drawText(line.trim(), options);
          line = words[i] + ' ';
        } else {
          line = testLine;
        }
      }

      if (line.trim() !== '') {
        this.drawText(line.trim(), options);
      }
    }
  }

  drawBox(x, width, height, fillColor, borderColor = null) {
    this.checkPageBreak(height);
    this.currentPage.drawRectangle({
      x,
      y: this.y - height,
      width,
      height,
      color: fillColor,
    });

    if (borderColor) {
      this.currentPage.drawRectangle({
        x,
        y: this.y - height,
        width,
        height,
        borderColor,
        borderWidth: 2,
      });
    }
  }
}

export const generateSaferAIPDF = async (reportData) => {
  try {
    const {
      type, // 'concept' or 'product'
      formData,
      answers,
      questions,
      riskScore,
      normalizedScore,
      riskZone,
      preFlightResults,
      promptAnalysisResults, // New: TensorFlow + API results
      codeAnalysisResults, // New: Code analysis results
      conceptReviewData, // For product review comparison
      categoryScores,
      highRiskQuestions,
      recommendations
    } = reportData;

    const pdfDoc = await PDFDocument.create();
    const flow = new Flow(pdfDoc);

    const timesRomanFont = await pdfDoc.embedFont(StandardFonts.TimesRoman);
    const timesRomanBold = await pdfDoc.embedFont(StandardFonts.TimesRomanBold);
    const helvetica = await pdfDoc.embedFont(StandardFonts.Helvetica);
    const helveticaBold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
    const courier = await pdfDoc.embedFont(StandardFonts.Courier);

    const amazonBlue = rgb(0.137, 0.184, 0.243);
    const amazonOrange = rgb(1, 0.6, 0);
    const black = rgb(0, 0, 0);
    const darkGray = rgb(0.3, 0.3, 0.3);
    const lightGray = rgb(0.9, 0.9, 0.9);
    const green = rgb(0.086, 0.639, 0.290);
    const yellow = rgb(0.792, 0.541, 0.024);
    const red = rgb(0.863, 0.149, 0.149);

    // Cover Page
    flow.drawBox(0, 612, 52, amazonBlue);
    flow.drawText('SAFER-AI', { x: 50, size: 28, font: helveticaBold, color: amazonOrange });
    flow.drawText('Security Assessment Framework for Evaluating Risk in AI Agents', { x: 50, size: 10, font: helvetica, color: rgb(1, 1, 1) });

    flow.moveDown(60);

    const reportTitle = type === 'concept' ? 'Concept Review Report' : 'Product Review Report';
    flow.drawText(reportTitle, { x: 50, size: 24, font: helveticaBold, color: amazonBlue });

    const reportSubtitle = type === 'concept' ? 'Pre-Development Security Assessment' : 'Production Deployment Security Assessment';
    flow.drawText(reportSubtitle, { x: 50, size: 12, font: helvetica, color: darkGray });

    flow.moveDown(40);

    // Project Info
    flow.drawBox(50, 512, 150, lightGray);
    flow.drawText(`Project Name: ${formData.projectName || 'N/A'}`, { x: 60, font: helveticaBold, size: 12 });
    flow.drawText(`Developer: ${formData.developer || 'N/A'}`, { x: 60 });
    flow.drawText(`Organization: ${formData.org || 'N/A'}`, { x: 60 });
    flow.drawText(`Platform: ${formData.platform || 'N/A'}`, { x: 60 });
    flow.drawText(`Development Type: ${formData.devType || 'N/A'}`, { x: 60 });
    flow.drawText(`Assessment Date: ${formData.date || 'N/A'}`, { x: 60 });
    flow.drawText(`Data Category: ${formData.dataCategory || 'N/A'}`, { x: 60 });

    if (type === 'product') {
      if (formData.deploymentUrl) {
        flow.drawText(`Deployment URL: ${formData.deploymentUrl}`, { x: 60, size: 9 });
      }
      if (formData.repositoryUrl) {
        flow.drawText(`Repository: ${formData.repositoryUrl}`, { x: 60, size: 9 });
      }
    }

    flow.moveDown(40);

    // Project Goal
    if (formData.goal) {
      flow.drawText('Project Goal & Description:', { x: 50, font: helveticaBold, size: 12, color: amazonBlue });
      flow.drawSmartText(formData.goal, { x: 50, size: 10, color: darkGray, maxWidth: 512, font: helvetica, lineHeight: 14 });
      flow.moveDown(30);
    }

    // ... (rest of the PDF generation logic to be refactored)

    const pdfBytes = await pdfDoc.save();
    const blob = new Blob([pdfBytes], { type: 'application/pdf' });
    const filename = `SAFER-AI_${type}_${(formData.projectName || 'report').replace(/[^a-z0-9]/gi, '_')}_${formData.date || 'unknown'}.pdf`;

    try {
      saveAs(blob, filename);
    } catch (saveAsError) {
      console.warn('file-saver failed, trying alternative method:', saveAsError);
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    }

    console.log('PDF generated successfully:', filename);
    return { success: true, filename };
  } catch (error) {
    console.error('PDF generation error:', error);
    return { success: false, error: error.message };
  }
};

export default generateSaferAIPDF;
