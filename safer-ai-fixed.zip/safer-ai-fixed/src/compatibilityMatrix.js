/**
 * SAFER-AI Compatibility Matrix
 * Source: SMGS Ops - Business Operations & AWS Data Types Guidance
 * 
 * Defines all approved platforms, data classifications, and compatibility rules
 */

// Data Classifications with detailed examples
export const dataClassifications = {
  customer_account: {
    id: 'customer_account',
    name: 'Customer Account Information',
    description: 'Customer identifiable information including names, emails, account IDs, and contact details',
    examples: [
      'Customer names and email addresses',
      'AWS Account IDs and account details',
      'Customer contact information and phone numbers',
      'Customer organization names and addresses',
      'Billing and payment information'
    ],
    riskLevel: 'medium',
    color: 'green',
    allowedPlatforms: ['party_rock', 'cedric', 'amazon_q', 'mentor', 'field_advisor', 'matome', 'bedrockbot', 'loki', 'clue', 'powerchat']
  },
  customer_content: {
    id: 'customer_content',
    name: 'Customer Content',
    description: 'Content created, uploaded, or transmitted by customers',
    examples: [
      'Customer-uploaded files and documents',
      'Customer chat messages and communications',
      'Customer-created code and applications',
      'Customer support ticket content',
      'Customer emails and correspondence'
    ],
    riskLevel: 'critical',
    color: 'red',
    allowedPlatforms: [] // Not allowed on any platform
  },
  customer_metadata: {
    id: 'customer_metadata',
    name: 'Customer-Created Metadata',
    description: 'Metadata generated or created by customer actions',
    examples: [
      'Customer-defined tags and labels',
      'Customer resource naming conventions',
      'Customer-created configuration metadata',
      'Customer workflow metadata',
      'Custom attributes set by customers'
    ],
    riskLevel: 'critical',
    color: 'red',
    allowedPlatforms: [] // Not allowed on any platform
  },
  metadata: {
    id: 'metadata',
    name: 'Metadata',
    description: 'System-generated metadata about AWS services and operations',
    examples: [
      'AWS service configuration metadata',
      'Resource utilization metrics',
      'System-generated timestamps and logs',
      'Service health and status information',
      'API call metadata and CloudTrail data'
    ],
    riskLevel: 'low',
    color: 'green',
    allowedPlatforms: ['party_rock', 'cedric', 'amazon_q', 'mentor', 'field_advisor', 'matome', 'bedrockbot', 'loki', 'clue', 'powerchat', 'assistapn']
  },
  aws_support: {
    id: 'aws_support',
    name: 'AWS Support Data',
    description: 'AWS support case information and ticket data',
    examples: [
      'Support case descriptions and resolutions',
      'Technical support ticket history',
      'Support engineer notes and recommendations',
      'Troubleshooting logs from support cases',
      'Support case metadata and status'
    ],
    riskLevel: 'medium',
    color: 'yellow',
    allowedPlatforms: ['party_rock', 'amazon_q', 'mentor'] // Varies by platform
  },
  aws_content: {
    id: 'aws_content',
    name: 'AWS Content',
    description: 'AWS-created documentation, blogs, and public content',
    examples: [
      'AWS documentation and whitepapers',
      'AWS blog posts and announcements',
      'AWS training materials and guides',
      'AWS reference architectures',
      'AWS best practices and recommendations'
    ],
    riskLevel: 'low',
    color: 'green',
    allowedPlatforms: ['party_rock', 'cedric', 'amazon_q', 'mentor', 'field_advisor', 'matome', 'bedrockbot', 'loki', 'clue', 'powerchat', 'assistapn']
  },
  employee_data: {
    id: 'employee_data',
    name: 'Employee Data',
    description: 'Internal Amazon employee information and data',
    examples: [
      'Employee names and contact information',
      'Employee roles and responsibilities',
      'Internal team structures and org charts',
      'Employee performance data',
      'Internal communication and collaboration data'
    ],
    riskLevel: 'low',
    color: 'green',
    allowedPlatforms: ['party_rock', 'cedric', 'amazon_q', 'mentor', 'field_advisor', 'matome', 'bedrockbot', 'loki', 'clue', 'powerchat', 'assistapn']
  },
  business_partner: {
    id: 'business_partner',
    name: 'Business Partner Data',
    description: 'AWS Partner and seller information',
    examples: [
      'Partner company names and contacts',
      'Partner program participation data',
      'Seller account information',
      'Partner competency and certification data',
      'Partner collaboration and engagement data'
    ],
    riskLevel: 'low',
    color: 'green',
    allowedPlatforms: ['party_rock', 'cedric', 'amazon_q', 'mentor', 'field_advisor', 'matome', 'bedrockbot', 'loki', 'clue', 'powerchat', 'assistapn']
  },
  business_contracts: {
    id: 'business_contracts',
    name: 'Business Contracts',
    description: 'Business agreements and contractual information',
    examples: [
      'Customer agreements and contracts',
      'Partner agreements and terms',
      'Service level agreements (SLAs)',
      'Non-disclosure agreements (NDAs)',
      'Commercial terms and pricing agreements'
    ],
    riskLevel: 'low',
    color: 'green',
    allowedPlatforms: ['party_rock', 'cedric', 'amazon_q', 'mentor', 'field_advisor', 'matome', 'bedrockbot', 'loki', 'clue', 'powerchat', 'assistapn']
  },
  security_data: {
    id: 'security_data',
    name: 'Highly Sensitive Security Data',
    description: 'Security credentials, secrets, and highly sensitive information',
    examples: [
      'API keys and access tokens',
      'Passwords and authentication credentials',
      'Security vulnerability details',
      'Encryption keys and certificates',
      'Security incident investigation data'
    ],
    riskLevel: 'critical',
    color: 'red',
    allowedPlatforms: [] // Not allowed on any platform
  }
};

// Low Code Platforms (11 total)
export const lowCodePlatforms = {
  party_rock: {
    id: 'party_rock',
    name: 'Party Rock',
    type: 'low_code',
    description: 'AWS PartyRock - No-code AI app builder for creating chatbots, virtual assistants, and interactive applications',
    useCases: [
      'Chatbots & Virtual Assistants',
      'Content Generation',
      'Code Assistance & Debugging',
      'Data Analysis & Insights',
      'Image Generation & Enhancement',
      'Business Process Automation',
      'Interactive Games & Storytelling'
    ],
    restrictions: 'No Customer Content or Customer-Created Metadata. No Highly Sensitive Security Data.',
    dataCompatibility: {
      customer_account: true,
      customer_content: false,
      customer_metadata: false,
      metadata: true,
      aws_support: true,
      aws_content: true,
      employee_data: true,
      business_partner: true,
      business_contracts: true,
      security_data: false
    }
  },
  cedric: {
    id: 'cedric',
    name: 'Cedric',
    type: 'low_code',
    description: 'Comprehensive AI assistant for technical work, coding, documentation, and business analysis',
    useCases: [
      'Technical Assistance and Coding',
      'Query and Database Optimization',
      'Engineering Productivity Enhancements',
      'Automated Testing',
      'Document Writing and Summarization',
      'Technical Documentation',
      'Technical Research and Documentation',
      'Proposal and Report Generation',
      'Data Analysis',
      'Market Research and Analysis',
      'Model Comparison and Analysis',
      'Survey Analysis and Summarization',
      'Text Analysis and Summarization',
      'Excel Formula Generation',
      'Content Creation and Editing',
      'Ideation and Creative Writing',
      'Brainstorming and Idea Generation',
      'Presentation Assistance',
      'Meeting Notes and Summarization',
      'Customer Engagement and Feedback Analysis',
      'Language Translation',
      'Accessibility Support'
    ],
    restrictions: 'No Customer Content or Customer-Created Metadata. No AWS Support Data. No Highly Sensitive Security Data.',
    dataCompatibility: {
      customer_account: true,
      customer_content: false,
      customer_metadata: false,
      metadata: true,
      aws_support: false,
      aws_content: true,
      employee_data: true,
      business_partner: true,
      business_contracts: true,
      security_data: false
    }
  },
  amazon_q: {
    id: 'amazon_q',
    name: 'Amazon Q Internal',
    type: 'low_code',
    description: 'Enterprise AI assistant integrated with Amazon internal systems and knowledge bases',
    useCases: [
      'Answering questions based on enterprise systems data',
      'Providing summaries of information',
      'Generating content',
      'Completing tasks securely',
      'Document creation',
      'Task management',
      'Project coordination',
      'Cross-functional collaboration',
      'Integration with productivity tools (Microsoft Office, WorkDocs, Outlook, Slack, Chime, Internal wiki)',
      'Knowledge search and reference using Amazon Knowledge from IDA, Sage, and Salesforce',
      'Custom Q Apps execution (PartyRock-style apps)',
      'Email and onboarding sessions'
    ],
    restrictions: 'No Customer Content or Customer-Created Metadata. No Highly Sensitive Security Data.',
    dataCompatibility: {
      customer_account: true,
      customer_content: false,
      customer_metadata: false,
      metadata: true,
      aws_support: true,
      aws_content: true,
      employee_data: true,
      business_partner: true,
      business_contracts: true,
      security_data: false
    }
  },
  mentor: {
    id: 'mentor',
    name: 'Mentor',
    type: 'low_code',
    description: 'Generative AI Chat for Enterprise Support with AWS documentation and knowledge integration',
    useCases: [
      'Integration with Slack',
      'Answering questions about AWS services and features',
      'Leveraging knowledge from AWS Public Documentation',
      're:Post, AWS Blogs, AWS Managed Services, and TAM Best Practices',
      'Voice interactions (through voice controls)',
      'Custom prompt creation and storage for repeated use',
      'Multi-shot feature for follow-up Q&A using Sage',
      'Support Case, Chat, and SIM Ticket Summarization',
      'Customer Sentiment Analysis',
      'Low Hanging Sentiment Distress',
      'Severity Assessment',
      'Professional dashboard email drafts'
    ],
    restrictions: 'No Customer Content or Customer-Created Metadata. No AWS Support Data. No Highly Sensitive Security Data.',
    dataCompatibility: {
      customer_account: true,
      customer_content: false,
      customer_metadata: false,
      metadata: true,
      aws_support: false,
      aws_content: true,
      employee_data: true,
      business_partner: true,
      business_contracts: true,
      security_data: false
    }
  },
  field_advisor: {
    id: 'field_advisor',
    name: 'Field Advisor',
    type: 'low_code',
    description: 'AI assistant for customer account management and sales pipeline support',
    useCases: [
      'Ask questions about customer accounts and sales pipeline opportunities',
      'Search AWS-specific knowledge bases',
      'Access re:Post, AWS website, blog posts, and service documentation',
      'Summarize documents',
      'Generate emails and prepare for meetings',
      'Securely upload and interact with documents',
      'Handle sensitive data such as account and territory plans',
      'Collaborate in Slack direct messages and private channels'
    ],
    restrictions: 'No Customer Content or Customer-Created Metadata. No AWS Support Data. No Highly Sensitive Security Data.',
    dataCompatibility: {
      customer_account: true,
      customer_content: false,
      customer_metadata: false,
      metadata: true,
      aws_support: false,
      aws_content: true,
      employee_data: true,
      business_partner: true,
      business_contracts: true,
      security_data: false
    }
  },
  matome: {
    id: 'matome',
    name: 'Matome',
    type: 'low_code',
    description: 'Specialized tool for summarization, grammar checking, and Amazon-specific document creation',
    useCases: [
      'Summarization',
      'Grammar check',
      'MBR creation',
      '2x2 creation',
      'Automated evaluation checklist',
      'Email evaluation',
      'Amazon PR/FAQ guidance and best practices',
      'AWS-specific guidance'
    ],
    restrictions: 'No Customer Content or Customer-Created Metadata. No Highly Sensitive Security Data.',
    dataCompatibility: {
      customer_account: true,
      customer_content: false,
      customer_metadata: false,
      metadata: true,
      aws_support: false,
      aws_content: true,
      employee_data: true,
      business_partner: true,
      business_contracts: true,
      security_data: false
    }
  },
  bedrockbot: {
    id: 'bedrockbot',
    name: 'BedrockBot',
    type: 'low_code',
    description: 'General-purpose AI assistant with knowledge base integration and guardrails',
    useCases: [
      'General Assistance',
      'Knowledge Base Integration',
      'Conversational AI',
      'Task Automation',
      'Personalization',
      'Guardrails and Safety'
    ],
    restrictions: 'No Customer Content or Customer-Created Metadata. No Highly Sensitive Security Data.',
    dataCompatibility: {
      customer_account: true,
      customer_content: false,
      customer_metadata: false,
      metadata: true,
      aws_support: false,
      aws_content: true,
      employee_data: true,
      business_partner: true,
      business_contracts: true,
      security_data: false
    }
  },
  loki: {
    id: 'loki',
    name: 'Loki',
    type: 'low_code',
    description: 'Automated partner validation and technical review workflows for AWS Partner Network',
    useCases: [
      'Automate manual P&L (Partner Solutions AI-Driven)',
      'Whiteness in the current APN (Amazon Partner Network)',
      'Program technical validation workflows',
      'Technical validation for FTR (Foundation Technical Review)',
      'Competency Program validation',
      'Managed Service Program validation'
    ],
    restrictions: 'No Customer Content or Customer-Created Metadata. No Highly Sensitive Security Data.',
    dataCompatibility: {
      customer_account: true,
      customer_content: false,
      customer_metadata: false,
      metadata: true,
      aws_support: false,
      aws_content: true,
      employee_data: true,
      business_partner: true,
      business_contracts: true,
      security_data: false
    }
  },
  clue: {
    id: 'clue',
    name: 'Clue',
    type: 'low_code',
    description: 'Asset discovery, code-level solutions, and application engineering platform',
    useCases: [
      'Asset discovery and management',
      'PR code-level code solutions',
      'Integrated application engineering',
      'Multi-level content aggregation',
      'Application level content management'
    ],
    restrictions: 'No Customer Content or Customer-Created Metadata. No Highly Sensitive Security Data.',
    dataCompatibility: {
      customer_account: true,
      customer_content: false,
      customer_metadata: false,
      metadata: true,
      aws_support: false,
      aws_content: true,
      employee_data: true,
      business_partner: true,
      business_contracts: true,
      security_data: false
    }
  },
  powerchat: {
    id: 'powerchat',
    name: 'PowerChat',
    type: 'low_code',
    description: 'Multi-purpose AI assistant for summarization, evaluation, writing, and data analysis',
    useCases: [
      'Summarization',
      'Evaluation',
      'Writing',
      'Data Analysis',
      'Translation',
      'General assistance'
    ],
    restrictions: 'No Customer Content or Customer-Created Metadata. No Highly Sensitive Security Data.',
    dataCompatibility: {
      customer_account: true,
      customer_content: false,
      customer_metadata: false,
      metadata: true,
      aws_support: false,
      aws_content: true,
      employee_data: true,
      business_partner: true,
      business_contracts: true,
      security_data: false
    }
  },
  assistapn: {
    id: 'assistapn',
    name: 'AssistAPN',
    type: 'low_code',
    description: 'AWS Partner Network assistance platform',
    useCases: [
      'Partner program support',
      'APN guidance and assistance',
      'Partner resource access'
    ],
    restrictions: 'No Customer Content or Customer-Created Metadata. No Highly Sensitive Security Data.',
    dataCompatibility: {
      customer_account: false,
      customer_content: false,
      customer_metadata: false,
      metadata: true,
      aws_support: false,
      aws_content: true,
      employee_data: true,
      business_partner: true,
      business_contracts: true,
      security_data: false
    }
  }
};

// High Code Platforms (4 total)
export const highCodePlatforms = {
  bedrock_rag: {
    id: 'bedrock_rag',
    name: 'AWS Bedrock RAG Agent',
    type: 'high_code',
    description: 'Retrieval-Augmented Generation agent using AWS Bedrock with custom knowledge bases',
    useCases: [
      'Custom knowledge base integration',
      'Document retrieval and question answering',
      'Context-aware AI responses',
      'Enterprise search with AI',
      'Semantic search capabilities'
    ],
    restrictions: 'Developer responsible for data handling and security controls. Must implement proper data classification checks.',
    requiresSecurityReview: true,
    dataCompatibility: 'Developer-defined based on implementation'
  },
  bedrock_multi: {
    id: 'bedrock_multi',
    name: 'AWS Bedrock Multi-Agent',
    type: 'high_code',
    description: 'Multi-agent orchestration system using AWS Bedrock for complex workflows',
    useCases: [
      'Complex multi-step workflows',
      'Agent collaboration and orchestration',
      'Task decomposition and delegation',
      'Specialized agent coordination',
      'Advanced AI system integration'
    ],
    restrictions: 'Developer responsible for data handling and security controls. Must implement proper data classification checks.',
    requiresSecurityReview: true,
    dataCompatibility: 'Developer-defined based on implementation'
  },
  lambda_function: {
    id: 'lambda_function',
    name: 'AWS Lambda Function',
    type: 'high_code',
    description: 'Serverless function with AI/ML integration for custom processing',
    useCases: [
      'Custom AI processing pipelines',
      'Event-driven AI workflows',
      'API integration with AI services',
      'Data transformation with AI',
      'Serverless AI applications'
    ],
    restrictions: 'Developer responsible for data handling and security controls. Must implement proper data classification checks.',
    requiresSecurityReview: true,
    dataCompatibility: 'Developer-defined based on implementation'
  },
  custom_genai: {
    id: 'custom_genai',
    name: 'Custom GenAI Solution',
    type: 'high_code',
    description: 'Fully custom generative AI solution with complete control over architecture',
    useCases: [
      'Fully customized AI applications',
      'Custom model integration',
      'Proprietary AI workflows',
      'Advanced AI system design',
      'Enterprise-specific AI solutions'
    ],
    restrictions: 'Developer responsible for all security controls, data handling, and compliance. Requires comprehensive security review.',
    requiresSecurityReview: true,
    dataCompatibility: 'Developer-defined based on implementation'
  }
};

// Combined platforms object
export const allPlatforms = {
  ...lowCodePlatforms,
  ...highCodePlatforms
};

// Helper function to check data compatibility
export const checkDataCompatibility = (platformId, dataTypeId) => {
  const platform = allPlatforms[platformId];
  
  if (!platform) return { compatible: false, reason: 'Platform not found' };
  
  // High code platforms require manual review
  if (platform.type === 'high_code') {
    return {
      compatible: 'review_required',
      reason: 'High code platforms require security review for data compatibility'
    };
  }
  
  // Low code platforms have defined compatibility
  const isCompatible = platform.dataCompatibility[dataTypeId];
  
  return {
    compatible: isCompatible,
    reason: isCompatible 
      ? 'Data type is compatible with this platform' 
      : 'Data type is not allowed on this platform'
  };
};

// Helper function to get platform recommendations
export const getPlatformRecommendations = (dataTypes = []) => {
  const recommendations = {
    low_code: [],
    high_code: [],
    warnings: []
  };
  
  // Check for critical data types
  const hasCriticalData = dataTypes.some(dt => 
    ['customer_content', 'customer_metadata', 'security_data'].includes(dt)
  );
  
  if (hasCriticalData) {
    recommendations.warnings.push(
      'Critical data types detected. No Low Code platforms support Customer Content, Customer-Created Metadata, or Highly Sensitive Security Data.'
    );
    recommendations.high_code = Object.values(highCodePlatforms);
    return recommendations;
  }
  
  // Find compatible low code platforms
  Object.values(lowCodePlatforms).forEach(platform => {
    const allCompatible = dataTypes.every(dt => platform.dataCompatibility[dt]);
    if (allCompatible) {
      recommendations.low_code.push(platform);
    }
  });
  
  // High code platforms always available but require review
  recommendations.high_code = Object.values(highCodePlatforms);
  
  return recommendations;
};

// Risk scoring for data types
export const calculateDataRisk = (dataTypes = []) => {
  let riskScore = 0;
  const riskFactors = [];
  
  dataTypes.forEach(dt => {
    const classification = dataClassifications[dt];
    if (!classification) return;
    
    switch (classification.riskLevel) {
      case 'critical':
        riskScore += 10;
        riskFactors.push(`${classification.name} (Critical Risk)`);
        break;
      case 'medium':
        riskScore += 5;
        riskFactors.push(`${classification.name} (Medium Risk)`);
        break;
      case 'low':
        riskScore += 1;
        riskFactors.push(`${classification.name} (Low Risk)`);
        break;
      default:
        riskScore += 0;
    }
  });
  
  return {
    score: riskScore,
    level: riskScore >= 20 ? 'high' : riskScore >= 10 ? 'medium' : 'low',
    factors: riskFactors
  };
};

export default {
  dataClassifications,
  lowCodePlatforms,
  highCodePlatforms,
  allPlatforms,
  checkDataCompatibility,
  getPlatformRecommendations,
  calculateDataRisk
};

