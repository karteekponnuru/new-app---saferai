import axios from 'axios';
import { Auth } from '@aws-amplify/auth';

const API_BASE_URL = 'https://0wji356jgl.execute-api.ap-south-1.amazonaws.com/prod';
const USE_MOCK_API = import.meta.env.VITE_USE_MOCK_API === 'true';

console.log('🔧 API Configuration:', { 
  baseURL: API_BASE_URL, 
  useMock: USE_MOCK_API 
});

class SaferAIApi {
  constructor() {
    this.client = axios.create({
      baseURL: API_BASE_URL,
      headers: {
        'Content-Type': 'application/json',
      },
    });

    // Add request interceptor to include auth token
    this.client.interceptors.request.use(
      async (config) => {
        try {
          // Get the current session from AWS Amplify Auth
          const session = await Auth.currentSession();
          const idToken = session.getIdToken().getJwtToken();
          
          if (idToken) {
            config.headers.Authorization = `Bearer ${idToken}`;
            console.log('✅ Token added to request for:', config.url);
          } else {
            console.warn('⚠️ No ID token available');
          }
        } catch (error) {
          console.error('❌ Error getting auth token:', error.message);
          // Continue without token - API will return 401 if required
        }
        return config;
      },
      (error) => {
        return Promise.reject(error);
      }
    );

    // Add response interceptor to handle errors
    this.client.interceptors.response.use(
      (response) => response,
      async (error) => {
        if (error.response?.status === 401) {
          console.error('❌ Unauthorized - token may be expired or invalid');
          console.error('Response:', error.response?.data);
          
          // Try to refresh token
          try {
            console.log('🔄 Attempting to refresh token...');
            const session = await Auth.currentSession();
            const newIdToken = session.getIdToken().getJwtToken();
            
            if (newIdToken) {
              console.log('✅ Token refreshed, retrying request');
              error.config.headers.Authorization = `Bearer ${newIdToken}`;
              return this.client.request(error.config);
            }
          } catch (refreshError) {
            console.error('❌ Token refresh failed:', refreshError.message);
            // Redirect to login
            window.location.href = '/';
          }
        } else if (error.response?.status === 403) {
          console.error('❌ Forbidden - insufficient permissions');
          console.error('Response:', error.response?.data);
        } else if (error.response?.status === 500) {
          console.error('❌ Server error:', error.response?.data);
        }
        
        return Promise.reject(error);
      }
    );
  }

  // Prompt Analysis
  async analyzePrompts(data) {
    if (USE_MOCK_API) {
      console.log('🔧 MOCK: Analyzing prompts...', data);
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      return {
        vulnerabilities: [
          {
            type: 'Prompt Injection Risk',
            severity: 'High',
            description: 'System prompt not properly delimited from user input',
            recommendation: 'Use clear delimiters and validate user input'
          },
          {
            type: 'PII Exposure Risk',
            severity: 'Medium',
            description: 'Prompt may include customer email addresses',
            recommendation: 'Implement PII filtering before sending to model'
          }
        ],
        risk_score: 3,
        summary: 'Found 2 security issues: 1 high, 1 medium severity',
        recommendations: [
          'Add clear delimiters between system and user content',
          'Implement PII detection and filtering',
          'Add output validation guardrails',
          'Test for prompt injection vulnerabilities'
        ]
      };
    }

    try {
      console.log('📤 Sending prompt analysis request to:', `${API_BASE_URL}/analyze-prompts`);
      const response = await this.client.post('/analyze-prompts', data);
      console.log('📥 Received prompt analysis response');
      
      // Parse body if it's a string (Lambda response format)
      let result = response.data;
      if (typeof result.body === 'string') {
        result = JSON.parse(result.body);
      }
      
      return result;
    } catch (error) {
      console.error('❌ Error analyzing prompts:', error.message);
      if (error.response) {
        console.error('Response status:', error.response.status);
        console.error('Response data:', error.response.data);
      }
      throw error;
    }
  }

  // Code Analysis
  async analyzeCode(data) {
    if (USE_MOCK_API) {
      console.log('🔧 MOCK: Analyzing code...', data);
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      return {
        vulnerabilities: [
          {
            type: 'SQL Injection Risk',
            severity: 'High',
            line: 45,
            description: 'User input not sanitized before database query',
            recommendation: 'Use parameterized queries or prepared statements'
          },
          {
            type: 'Hardcoded Credentials',
            severity: 'Critical',
            line: 12,
            description: 'API key found in source code',
            recommendation: 'Move credentials to environment variables'
          },
          {
            type: 'Missing Input Validation',
            severity: 'Medium',
            line: 78,
            description: 'No validation on user-supplied data',
            recommendation: 'Implement input validation and sanitization'
          }
        ],
        risk_score: 4,
        summary: 'Found 3 security issues: 1 critical, 1 high, 1 medium severity',
        recommendations: [
          'Remove hardcoded credentials immediately',
          'Implement input validation and sanitization',
          'Use parameterized database queries',
          'Add security headers to API responses'
        ]
      };
    }

    try {
      console.log('📤 Sending code analysis request to:', `${API_BASE_URL}/analyze-code`);
      const response = await this.client.post('/analyze-code', data);
      console.log('📥 Received code analysis response');
      
      // Parse body if it's a string (Lambda response format)
      let result = response.data;
      if (typeof result.body === 'string') {
        result = JSON.parse(result.body);
      }
      
      return result;
    } catch (error) {
      console.error('❌ Error analyzing code:', error.message);
      if (error.response) {
        console.error('Response status:', error.response.status);
        console.error('Response data:', error.response.data);
      }
      throw error;
    }
  }

  // Get all reviews
  async getReviews() {
    if (USE_MOCK_API) {
      console.log('🔧 MOCK: Fetching reviews...');
      await new Promise(resolve => setTimeout(resolve, 1000));
      return [];
    }

    try {
      console.log('📤 Fetching reviews...');
      const response = await this.client.get('/reviews');
      console.log('📥 Received reviews');
      return response.data;
    } catch (error) {
      console.error('❌ Error fetching reviews:', error.message);
      throw error;
    }
  }
}

const saferAIApi = new SaferAIApi();
export default saferAIApi;
