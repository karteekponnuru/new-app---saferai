import { Amplify } from '@aws-amplify/core';

const cognitoAuthConfig = {
  Auth: {
    region: 'ap-south-1',
    userPoolId: 'ap-south-1_tJYrDS5NW',
    userPoolWebClientId: '2643jfjr4492gpr6t5lbnoqnp9',
    oauth: {
      domain: 'ap-south-1tjyrds5nw.auth.ap-south-1.amazoncognito.com',
      scope: ['openid', 'email', 'profile', 'aws.cognito.signin.user.admin'],
      redirectSignIn: window.location.origin + '/auth/callback',
      redirectSignOut: window.location.origin,
      responseType: 'code',
    },
    mandatorySignIn: true,
  },
};

Amplify.configure(cognitoAuthConfig);

export default cognitoAuthConfig;
