import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Alert, AlertDescription } from '@/components/ui/alert.jsx';
import { CheckCircle, XCircle, Info, Code, Zap, Shield, Database, Calculator } from 'lucide-react';
import { lowCodePlatforms, highCodePlatforms } from '@/lib/compatibilityMatrix.js';

const Mechanism = () => {
  const [selectedPlatform, setSelectedPlatform] = useState(null);
  const [selectedDataType, setSelectedDataType] = useState(null);

  // Data Classifications aligned with Amazon's system
  const dataClassifications = [
    {
      id: 'public',
      name: 'Public Data',
      description: 'Information intended for public view (e.g., product listings, press releases)',
      note: "'Public' does not mean 'casual' - requires proper consideration and approval channels",
      riskLevel: 'low',
      color: 'green',
      bgColor: 'bg-green-50',
      borderColor: 'border-green-500',
      textColor: 'text-green-800',
      examples: [
        'Product listings and descriptions',
        'Press releases and public announcements',
        'Marketing materials',
        'Public API documentation',
        'General company information'
      ],
      requirements: [
        'Proper approval channels required',
        'Review before publication',
        'Maintain brand consistency',
        'Legal review for certain content'
      ]
    },
    {
      id: 'confidential',
      name: 'Confidential Data',
      description: 'Sensitive information that would cause minimal risk if exposed',
      note: 'Base level for non-public information',
      riskLevel: 'low',
      color: 'blue',
      bgColor: 'bg-blue-50',
      borderColor: 'border-blue-500',
      textColor: 'text-blue-800',
      examples: [
        'Internal process documents',
        'Team metrics (non-sensitive)',
        'General business correspondence',
        'Non-sensitive project plans',
        'Internal wikis and documentation'
      ],
      requirements: [
        'Internal use only',
        'Standard access controls',
        'Basic logging required',
        'Appropriate permissions'
      ]
    },
    {
      id: 'highly-confidential',
      name: 'Highly Confidential Data',
      description: 'Requires stronger protection than Confidential data - Orange level in Anvil',
      note: 'Unique to customers or vendors (e.g., contract details, payment information). Should not be shared, even if it doesn\'t contain critical elements',
      riskLevel: 'medium',
      color: 'orange',
      bgColor: 'bg-orange-50',
      borderColor: 'border-orange-500',
      textColor: 'text-orange-800',
      examples: [
        'Contract details and negotiations',
        'Payment information',
        'Vendor agreements',
        'Customer business plans',
        'Pricing strategies',
        'Partnership agreements'
      ],
      requirements: [
        'Orange level in Anvil',
        'Permission restrictions required',
        'Encryption at rest and in transit',
        'Comprehensive audit logging',
        'Need-to-know access only'
      ]
    },
    {
      id: 'restricted',
      name: 'Restricted Data',
      description: 'Information that could significantly impact Amazon\'s competitive position if exposed',
      note: 'Should not be shared externally under any circumstances',
      riskLevel: 'high',
      color: 'amber',
      bgColor: 'bg-amber-50',
      borderColor: 'border-amber-500',
      textColor: 'text-amber-800',
      examples: [
        'Business metrics and KPIs',
        'Customer behavior patterns',
        'Financial decision algorithms',
        'Strategic roadmaps',
        'Competitive analysis',
        'Revenue projections',
        'Market expansion plans'
      ],
      requirements: [
        'Strict access controls',
        'Enhanced encryption',
        'Detailed audit trails',
        'Executive approval for access',
        'No external sharing',
        'Secure communication channels only'
      ]
    },
    {
      id: 'critical',
      name: 'Critical Data',
      description: 'Highest level of protection - RED applications in Anvil',
      note: '⚠️ Teams handling Critical (red) data must engage a security certifier during the project\'s design phase',
      riskLevel: 'critical',
      color: 'red',
      bgColor: 'bg-red-50',
      borderColor: 'border-red-500',
      textColor: 'text-red-800',
      examples: [
        'Government-issued IDs',
        'Authentication credentials',
        'Sensitive customer PII',
        'Payment card data (PCI)',
        'Health information (PHI)',
        'Biometric data',
        'Cryptographic keys',
        'Security tokens'
      ],
      requirements: [
        'RED level in Anvil',
        'Security certifier engagement required',
        'Multi-factor authentication',
        'Hardware security modules (HSM)',
        'Real-time monitoring',
        'Immediate incident response',
        'Compliance certifications (PCI-DSS, HIPAA)',
        'Zero-trust architecture'
      ]
    }
  ];

  // Data Type Categories
  const dataTypes = [
    {
      id: 'customer-account',
      name: 'Customer Account Information',
      description: 'Information related to customer accounts, billing, and account management',
      classification: 'critical',
      examples: [
        'Account IDs and identifiers',
        'Billing information',
        'Payment methods',
        'Account contact details',
        'Service usage data',
        'IAM user information'
      ],
      allowedPlatforms: ['mentor', 'amazon-q-internal', 'field-advisor'],
      restrictions: 'Requires encryption, strict access controls, and comprehensive audit logging. PCI-DSS compliance required for payment data.'
    },
    {
      id: 'customer-content',
      name: 'Customer Content',
      description: 'Data and content that customers store and process in services',
      classification: 'critical',
      examples: [
        'Data stored in cloud buckets',
        'Instance data',
        'Database contents',
        'Application data',
        'Customer workloads',
        'Uploaded files and media'
      ],
      allowedPlatforms: [],
      restrictions: '⚠️ Generally not allowed in AI agents. Requires explicit customer consent and comprehensive security controls if absolutely necessary.'
    },
    {
      id: 'customer-metadata',
      name: 'Customer-Created Metadata',
      description: 'Metadata created by customers about their resources',
      classification: 'highly-confidential',
      examples: [
        'Resource tags',
        'Custom configuration settings',
        'User-defined labels',
        'Resource descriptions',
        'Custom metrics',
        'Alarm configurations'
      ],
      allowedPlatforms: ['mentor', 'amazon-q-internal', 'loki'],
      restrictions: 'Requires proper access controls and encryption. Can reveal customer infrastructure patterns.'
    },
    {
      id: 'metadata',
      name: 'Service Metadata',
      description: 'System-generated metadata about services and resources',
      classification: 'confidential',
      examples: [
        'Service logs',
        'Performance metrics',
        'Resource utilization data',
        'System-generated timestamps',
        'Service health data',
        'API call metadata'
      ],
      allowedPlatforms: ['mentor', 'amazon-q-internal', 'loki', 'field-advisor', 'cedric'],
      restrictions: 'Internal use only. Standard access controls apply.'
    },
    {
      id: 'support-data',
      name: 'Support Data',
      description: 'Information from customer support interactions and tickets',
      classification: 'highly-confidential',
      examples: [
        'Support case details',
        'Troubleshooting logs',
        'Customer communications',
        'Technical assistance records',
        'Escalation information',
        'Resolution notes'
      ],
      allowedPlatforms: ['support-genie', 'mentor', 'loki'],
      restrictions: 'Customer consent required for AI processing. Must maintain confidentiality and comply with support policies.'
    },
    {
      id: 'internal-content',
      name: 'Internal Content',
      description: 'Internal documentation, procedures, and knowledge base',
      classification: 'confidential',
      examples: [
        'Internal documentation',
        'Runbooks and procedures',
        'Training materials',
        'Knowledge base articles',
        'Best practices guides',
        'Internal FAQs'
      ],
      allowedPlatforms: ['cedric', 'amazon-q-internal', 'mentor', 'aza', 'matome'],
      restrictions: 'Internal use only. Some content may be Highly Confidential depending on sensitivity.'
    },
    {
      id: 'employee-data',
      name: 'Employee Data',
      description: 'Personal and employment information about employees',
      classification: 'critical',
      examples: [
        'Employee IDs',
        'Compensation information',
        'Performance reviews',
        'Personal contact details',
        'Benefits information',
        'HR records'
      ],
      allowedPlatforms: ['aza'],
      restrictions: '⚠️ Highly restricted. HR approval required. GDPR/privacy law compliance mandatory.'
    },
    {
      id: 'business-partner',
      name: 'Business Partner Data',
      description: 'Information about vendors, partners, and business relationships',
      classification: 'highly-confidential',
      examples: [
        'Vendor contracts',
        'Partnership agreements',
        'Supplier information',
        'Joint venture details',
        'NDA-protected information',
        'Partner pricing'
      ],
      allowedPlatforms: ['mentor', 'amazon-q-internal'],
      restrictions: 'NDA and contractual obligations apply. Legal review required for sharing.'
    },
    {
      id: 'business-contracts',
      name: 'Business Contracts',
      description: 'Legal agreements and contractual documents',
      classification: 'highly-confidential',
      examples: [
        'Customer agreements',
        'Service contracts',
        'Licensing agreements',
        'Terms of service',
        'SLAs and commitments',
        'Legal settlements'
      ],
      allowedPlatforms: ['mentor'],
      restrictions: 'Legal approval required. Highly restricted access. May contain confidential terms.'
    },
    {
      id: 'security-data',
      name: 'Highly Sensitive Security Data',
      description: 'Critical security information and infrastructure details',
      classification: 'critical',
      examples: [
        'Security vulnerabilities',
        'Penetration test results',
        'Security incident details',
        'Cryptographic keys',
        'Access credentials',
        'Security architecture diagrams',
        'Threat intelligence'
      ],
      allowedPlatforms: [],
      restrictions: '⚠️ Extremely restricted. Security team approval required. Never use in AI agents without explicit security review.'
    }
  ];

  // Tool Classifications
  const toolClassifications = [
    { tool: 'Sharepoint', classification: 'Up to Highly Confidential (if configured correctly)', color: 'orange' },
    { tool: 'Shared ANT drive', classification: 'Confidential', color: 'blue' },
    { tool: 'Drive', classification: 'Highly Confidential with permission restrictions', color: 'orange' },
    { tool: 'Workdocs', classification: 'Highly Confidential with permission restrictions', color: 'orange' },
    { tool: 'Quip', classification: 'Highly Confidential with permission restrictions', color: 'orange' },
    { tool: 'Trawler', classification: 'Confidential', color: 'blue' },
    { tool: 'Wiki', classification: 'Confidential (Do NOT store Highly Confidential data)', color: 'blue' },
    { tool: 'Internal Email/Outlook', classification: 'Highly Confidential (with warning prefix and permissions)', color: 'orange' },
    { tool: 'TT/SIM/T-corp', classification: 'Highly Confidential with permission restrictions', color: 'orange' },
    { tool: 'Chime', classification: 'Up to Highly Confidential (internal use only)', color: 'orange' },
    { tool: 'Slack', classification: 'Up to Highly Confidential (private channels only)', color: 'orange' },
    { tool: 'Tableau A3', classification: 'Highly Confidential', color: 'orange' },
    { tool: 'Playbook', classification: 'Confidential', color: 'blue' }
  ];

  // SaferAI Scoring Mechanism
  const scoringMechanism = {
    concept: {
      name: 'Concept Review',
      maxScore: 40,
      categories: [
        { name: 'Data Sensitivity', maxPoints: 10, weight: '25%', description: 'Type and classification of data accessed' },
        { name: 'Access Permissions', maxPoints: 9, weight: '22.5%', description: 'System and API access levels' },
        { name: 'Output Safety', maxPoints: 10, weight: '25%', description: 'Output visibility and review processes' },
        { name: 'Prompt Security', maxPoints: 9, weight: '22.5%', description: 'Input handling and injection risks' },
        { name: 'External Integrations', maxPoints: 9, weight: '22.5%', description: 'Third-party service dependencies' },
        { name: 'Business Impact', maxPoints: 9, weight: '22.5%', description: 'Automation level and failure impact' },
        { name: 'Governance & Logging', maxPoints: 7, weight: '17.5%', description: 'Audit trails and compliance' },
        { name: 'Monitoring & Review', maxPoints: 7, weight: '17.5%', description: 'Continuous monitoring and IR plans' }
      ],
      zones: [
        { name: 'Green Zone', range: '0-16', status: 'Ready to Build', color: 'green', action: 'Proceed with development' },
        { name: 'Amber Zone', range: '17-28', status: 'Design with Care', color: 'yellow', action: 'Review security controls, implement safeguards' },
        { name: 'Red Zone', range: '29-40', status: 'Needs Rework', color: 'red', action: 'Redesign or comprehensive security measures required' }
      ]
    },
    product: {
      name: 'Product Review',
      maxScore: 40,
      categories: [
        { name: 'Data Sensitivity', maxPoints: 10, weight: '25%', description: 'Type and classification of data accessed' },
        { name: 'Access Permissions', maxPoints: 9, weight: '22.5%', description: 'System and API access levels' },
        { name: 'Output Safety', maxPoints: 10, weight: '25%', description: 'Output visibility and review processes' },
        { name: 'Prompt Security', maxPoints: 9, weight: '22.5%', description: 'Input handling and injection risks' },
        { name: 'External Integrations', maxPoints: 9, weight: '22.5%', description: 'Third-party service dependencies' },
        { name: 'Business Impact', maxPoints: 9, weight: '22.5%', description: 'Automation level and failure impact' },
        { name: 'Governance & Logging', maxPoints: 7, weight: '17.5%', description: 'Audit trails and compliance' },
        { name: 'Monitoring & Review', maxPoints: 7, weight: '17.5%', description: 'Continuous monitoring and IR plans' }
      ],
      additionalAnalysis: [
        { name: 'Prompt Security Scan', description: 'Optional OWASP LLM Top 10 vulnerability analysis - findings contribute to overall risk assessment' },
        { name: 'Code Security Scan', description: 'Optional static code analysis - findings contribute to overall risk assessment' }
      ],
      zones: [
        { name: 'Green Zone', range: '0-16', status: 'Ready for Deployment', color: 'green', action: 'Proceed with production deployment' },
        { name: 'Amber Zone', range: '17-28', status: 'Address Issues', color: 'yellow', action: 'Fix identified issues before deployment' },
        { name: 'Red Zone', range: '29-40', status: 'Deployment Blocked', color: 'red', action: 'Critical issues must be resolved' }
      ]
    },
    scoring: {
      methodology: [
        'Each question has options with assigned risk scores (0-5 points)',
        'Higher scores indicate higher security risk',
        'Category scores are summed to calculate total risk score (max 40)',
        'Risk zones are determined by total score thresholds',
        'Optional security scans provide additional vulnerability insights without adding points'
      ],
      interpretation: [
        'Score reflects cumulative security risk across all categories',
        'Multiple moderate risks can elevate overall risk level',
        'Single critical risk (score 5) in any area requires attention',
        'Zone boundaries designed to align with security standards',
        'Comparison between Concept and Product shows risk evolution'
      ]
    }
  };

  const getCompatibilityIcon = (compatible) => {
    if (compatible === true) {
      return <CheckCircle className="h-5 w-5 text-green-600" />;
    } else if (compatible === false) {
      return <XCircle className="h-5 w-5 text-red-600" />;
    }
    return <Info className="h-5 w-5 text-gray-400" />;
  };

  const getCompatibilityBadge = (compatible) => {
    if (compatible === true) {
      return <Badge className="bg-green-100 text-green-800 border-green-300">Allowed</Badge>;
    } else if (compatible === false) {
      return <Badge className="bg-red-100 text-red-800 border-red-300">Not Allowed</Badge>;
    }
    return <Badge className="bg-gray-100 text-gray-800 border-gray-300">Review Required</Badge>;
  };

  const getClassificationColor = (classification) => {
    const colors = {
      'public': 'bg-green-100 text-green-800',
      'confidential': 'bg-blue-100 text-blue-800',
      'highly-confidential': 'bg-orange-100 text-orange-800',
      'restricted': 'bg-amber-100 text-amber-800',
      'critical': 'bg-red-100 text-red-800'
    };
    return colors[classification] || 'bg-gray-100 text-gray-800';
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#232F3E] to-[#37475A] text-white">
        <div className="max-w-7xl mx-auto px-6 py-12">
          <h1 className="text-4xl font-bold mb-3">Platform & Data Compatibility Matrix</h1>
          <p className="text-xl text-gray-200">
            Comprehensive guide to approved AI platforms, data classifications, and SaferAI scoring
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        <Tabs defaultValue="platforms" className="w-full">
          <TabsList className="grid w-full grid-cols-5 mb-8 bg-white border-2 border-gray-200">
            <TabsTrigger value="platforms" className="data-[state=active]:bg-[#232F3E] data-[state=active]:text-white">
              Platform Overview
            </TabsTrigger>
            <TabsTrigger value="data-classifications" className="data-[state=active]:bg-[#232F3E] data-[state=active]:text-white">
              Data Classifications
            </TabsTrigger>
            <TabsTrigger value="data-types" className="data-[state=active]:bg-[#232F3E] data-[state=active]:text-white">
              Data Types
            </TabsTrigger>
            <TabsTrigger value="tools" className="data-[state=active]:bg-[#232F3E] data-[state=active]:text-white">
              Tool Classifications
            </TabsTrigger>
            <TabsTrigger value="scoring" className="data-[state=active]:bg-[#232F3E] data-[state=active]:text-white">
              SaferAI Scoring
            </TabsTrigger>
          </TabsList>

          {/* Platform Overview Tab */}
          <TabsContent value="platforms" className="space-y-6">
            {/* Low Code Platforms */}
            <Card className="border-2 border-[#232F3E]">
              <CardHeader className="bg-gradient-to-r from-[#232F3E] to-[#37475A] text-white">
                <div className="flex items-center gap-3">
                  <Zap className="h-8 w-8 text-[#FF9900]" />
                  <div>
                    <CardTitle className="text-2xl">Low Code Platforms (11)</CardTitle>
                    <CardDescription className="text-gray-200">
                      Pre-built AI applications with limited customization
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                <div className="grid md:grid-cols-2 gap-4">
                  {Object.values(lowCodePlatforms).map((platform) => (
                    <Card 
                      key={platform.id} 
                      className="border hover:border-[#FF9900] transition-colors cursor-pointer"
                      onClick={() => setSelectedPlatform(platform)}
                    >
                      <CardHeader>
                        <CardTitle className="text-lg flex items-center justify-between">
                          {platform.name}
                          <Badge className="bg-blue-100 text-blue-800 border-blue-300">Low Code</Badge>
                        </CardTitle>
                        <CardDescription className="text-sm">{platform.description}</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2">
                          <p className="text-sm font-semibold text-gray-700">Key Use Cases:</p>
                          <ul className="text-sm text-gray-600 space-y-1">
                            {platform.useCases.slice(0, 3).map((useCase, idx) => (
                              <li key={idx}>• {useCase}</li>
                            ))}
                            {platform.useCases.length > 3 && (
                              <li className="text-[#FF9900] font-semibold">+ {platform.useCases.length - 3} more...</li>
                            )}
                          </ul>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* High Code Platforms */}
            <Card className="border-2 border-[#FF9900]">
              <CardHeader className="bg-gradient-to-r from-[#FF9900] to-[#EC7211] text-white">
                <div className="flex items-center gap-3">
                  <Code className="h-8 w-8 text-white" />
                  <div>
                    <CardTitle className="text-2xl">High Code Platforms (4)</CardTitle>
                    <CardDescription className="text-gray-100">
                      Custom development with full control and security review required
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                <Alert className="mb-6 border-orange-500 bg-orange-50">
                  <Info className="h-5 w-5 text-orange-600" />
                  <AlertDescription className="text-gray-800 ml-2">
                    <strong>Important:</strong> High Code platforms require comprehensive security review and developer-implemented data controls.
                  </AlertDescription>
                </Alert>

                <div className="grid md:grid-cols-2 gap-4">
                  {Object.values(highCodePlatforms).map((platform) => (
                    <Card 
                      key={platform.id} 
                      className="border hover:border-[#FF9900] transition-colors cursor-pointer"
                      onClick={() => setSelectedPlatform(platform)}
                    >
                      <CardHeader>
                        <CardTitle className="text-lg flex items-center justify-between">
                          {platform.name}
                          <Badge className="bg-orange-100 text-orange-800 border-orange-300">High Code</Badge>
                        </CardTitle>
                        <CardDescription className="text-sm">{platform.description}</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2">
                          <p className="text-sm font-semibold text-gray-700">Key Use Cases:</p>
                          <ul className="text-sm text-gray-600 space-y-1">
                            {platform.useCases.map((useCase, idx) => (
                              <li key={idx}>• {useCase}</li>
                            ))}
                          </ul>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Platform Detail Modal */}
            {selectedPlatform && (
              <Card className="border-2 border-[#FF9900] bg-blue-50">
                <CardHeader className="bg-gradient-to-r from-[#232F3E] to-[#37475A] text-white">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-2xl">{selectedPlatform.name}</CardTitle>
                    <button 
                      onClick={() => setSelectedPlatform(null)}
                      className="text-white hover:text-[#FF9900] transition-colors text-2xl font-bold"
                    >
                      ✕
                    </button>
                  </div>
                  <CardDescription className="text-gray-200">{selectedPlatform.description}</CardDescription>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="space-y-4">
                    <div>
                      <h3 className="font-semibold text-lg mb-2 text-gray-900">All Use Cases:</h3>
                      <ul className="grid md:grid-cols-2 gap-2 text-gray-700">
                        {selectedPlatform.useCases.map((useCase, idx) => (
                          <li key={idx} className="flex items-start gap-2">
                            <CheckCircle className="h-4 w-4 text-green-600 mt-1 flex-shrink-0" />
                            <span className="text-sm">{useCase}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="border-t pt-4">
                      <h3 className="font-semibold text-lg mb-2 text-gray-900">Restrictions:</h3>
                      <p className="text-gray-700 text-sm bg-yellow-50 border-l-4 border-yellow-500 p-3 rounded">
                        {selectedPlatform.restrictions}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Data Classifications Tab */}
          <TabsContent value="data-classifications">
            <Card className="border-2 border-[#232F3E]">
              <CardHeader className="bg-gradient-to-r from-[#232F3E] to-[#37475A] text-white">
                <div className="flex items-center gap-3">
                  <Shield className="h-8 w-8 text-[#FF9900]" />
                  <div>
                    <CardTitle className="text-2xl">Data Classification Levels</CardTitle>
                    <CardDescription className="text-gray-200">
                      Five-tier data classification system
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                <Alert className="mb-6 border-blue-500 bg-blue-50">
                  <Info className="h-5 w-5 text-blue-600" />
                  <AlertDescription className="text-gray-800 ml-2">
                    <strong>Important:</strong> Data classification determines security requirements, access controls, and compliance obligations. Choose the highest classification level for any data your agent will access.
                  </AlertDescription>
                </Alert>

                <div className="space-y-4">
                  {dataClassifications.map((classification) => (
                    <Card key={classification.id} className={`border-2 ${classification.borderColor}`}>
                      <CardHeader className={`${classification.bgColor} border-b-2 ${classification.borderColor}`}>
                        <div className="flex items-center justify-between">
                          <CardTitle className="text-lg">{classification.name}</CardTitle>
                          <Badge className={`${getClassificationColor(classification.id)}`}>
                            {classification.riskLevel.toUpperCase()} RISK
                          </Badge>
                        </div>
                        <CardDescription className={`${classification.textColor} mt-2`}>
                          {classification.description}
                        </CardDescription>
                        <p className={`text-sm italic mt-2 ${classification.textColor}`}>
                          {classification.note}
                        </p>
                      </CardHeader>
                      <CardContent className="p-4 space-y-4">
                        <div>
                          <p className="font-semibold text-sm text-gray-900 mb-2">Examples:</p>
                          <ul className="space-y-1">
                            {classification.examples.map((example, idx) => (
                              <li key={idx} className="text-sm text-gray-700 flex items-start gap-2">
                                <span className="text-[#FF9900] font-bold">•</span>
                                <span>{example}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                        <div className="border-t pt-3">
                          <p className="font-semibold text-sm text-gray-900 mb-2">Requirements:</p>
                          <ul className="space-y-1">
                            {classification.requirements.map((req, idx) => (
                              <li key={idx} className="text-sm text-gray-700 flex items-start gap-2">
                                <CheckCircle className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                                <span>{req}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Data Types Tab */}
          <TabsContent value="data-types">
            <Card className="border-2 border-[#232F3E]">
              <CardHeader className="bg-gradient-to-r from-[#232F3E] to-[#37475A] text-white">
                <div className="flex items-center gap-3">
                  <Database className="h-8 w-8 text-[#FF9900]" />
                  <div>
                    <CardTitle className="text-2xl">Data Type Categories</CardTitle>
                    <CardDescription className="text-gray-200">
                      10 categories of data with classification levels and platform compatibility
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                <div className="grid md:grid-cols-2 gap-4">
                  {dataTypes.map((dataType) => {
                    const classification = dataClassifications.find(c => c.id === dataType.classification);
                    return (
                      <Card 
                        key={dataType.id} 
                        className={`border-2 ${classification?.borderColor} cursor-pointer hover:shadow-lg transition-shadow`}
                        onClick={() => setSelectedDataType(dataType)}
                      >
                        <CardHeader className={classification?.bgColor}>
                          <div className="flex items-center justify-between">
                            <CardTitle className="text-base">{dataType.name}</CardTitle>
                            <Badge className={getClassificationColor(dataType.classification)}>
                              {classification?.name.split(' ')[0].toUpperCase()}
                            </Badge>
                          </div>
                          <CardDescription className="text-sm text-gray-700">
                            {dataType.description}
                          </CardDescription>
                        </CardHeader>
                        <CardContent className="p-4">
                          <div className="space-y-2">
                            <p className="text-xs font-semibold text-gray-600">
                              Allowed on {dataType.allowedPlatforms.length} platforms
                            </p>
                            {dataType.allowedPlatforms.length === 0 && (
                              <p className="text-xs text-red-600 font-semibold">
                                ⚠️ Generally not allowed - special approval required
                              </p>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>

                {/* Selected Data Type Detail */}
                {selectedDataType && (
                  <Card className="mt-6 border-2 border-[#FF9900]">
                    <CardHeader className="bg-gradient-to-r from-[#FF9900] to-[#EC7211] text-white">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-xl">{selectedDataType.name}</CardTitle>
                        <button 
                          onClick={() => setSelectedDataType(null)}
                          className="text-white hover:text-gray-200 transition-colors text-xl font-bold"
                        >
                          ✕
                        </button>
                      </div>
                      <CardDescription className="text-white">
                        {selectedDataType.description}
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="p-6 space-y-4">
                      <div>
                        <h4 className="font-semibold text-gray-900 mb-2">Classification Level:</h4>
                        <Badge className={`${getClassificationColor(selectedDataType.classification)} text-sm`}>
                          {dataClassifications.find(c => c.id === selectedDataType.classification)?.name}
                        </Badge>
                      </div>

                      <div>
                        <h4 className="font-semibold text-gray-900 mb-2">Examples:</h4>
                        <ul className="space-y-1">
                          {selectedDataType.examples.map((example, idx) => (
                            <li key={idx} className="text-sm text-gray-700 flex items-start gap-2">
                              <span className="text-[#FF9900] font-bold">•</span>
                              <span>{example}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div>
                        <h4 className="font-semibold text-gray-900 mb-2">Allowed Platforms:</h4>
                        {selectedDataType.allowedPlatforms.length > 0 ? (
                          <div className="flex flex-wrap gap-2">
                            {selectedDataType.allowedPlatforms.map((platformId) => {
                              const platform = [...Object.values(lowCodePlatforms), ...Object.values(highCodePlatforms)]
                                .find(p => p.id === platformId);
                              return (
                                <Badge key={platformId} className="bg-green-100 text-green-800">
                                  {platform?.name || platformId}
                                </Badge>
                              );
                            })}
                          </div>
                        ) : (
                          <p className="text-sm text-red-600 font-semibold">
                            ⚠️ Not allowed on any platform without special approval
                          </p>
                        )}
                      </div>

                      <div className="border-t pt-4">
                        <h4 className="font-semibold text-gray-900 mb-2">Restrictions & Requirements:</h4>
                        <p className="text-sm text-gray-700 bg-yellow-50 border-l-4 border-yellow-500 p-3 rounded">
                          {selectedDataType.restrictions}
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Tool Classifications Tab */}
          <TabsContent value="tools">
            <Card className="border-2 border-[#232F3E]">
              <CardHeader className="bg-gradient-to-r from-[#232F3E] to-[#37475A] text-white">
                <CardTitle className="text-2xl">Tool Classification Reference</CardTitle>
                <CardDescription className="text-gray-200">
                  Maximum data classification levels for common tools
                </CardDescription>
              </CardHeader>
              <CardContent className="p-6">
                <Alert className="mb-6 border-orange-500 bg-orange-50">
                  <Info className="h-5 w-5 text-orange-600" />
                  <AlertDescription className="text-gray-800 ml-2">
                    <strong>Important:</strong> These classifications represent the MAXIMUM level of data that can be stored in each tool when properly configured. Always verify configuration and permissions before storing sensitive data.
                  </AlertDescription>
                </Alert>

                <div className="overflow-x-auto">
                  <table className="w-full border-collapse bg-white rounded-lg overflow-hidden shadow-sm">
                    <thead>
                      <tr className="bg-gray-100">
                        <th className="text-left p-4 font-semibold text-gray-900 border-b-2">Tool</th>
                        <th className="text-left p-4 font-semibold text-gray-900 border-b-2">Maximum Classification Level</th>
                        <th className="text-center p-4 font-semibold text-gray-900 border-b-2">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {toolClassifications.map((item, index) => (
                        <tr key={index} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                          <td className="p-4 border-b border-gray-200 font-medium text-gray-900">
                            {item.tool}
                          </td>
                          <td className="p-4 border-b border-gray-200 text-gray-700">
                            {item.classification}
                          </td>
                          <td className="p-4 border-b border-gray-200 text-center">
                            <Badge className={
                              item.color === 'orange' ? 'bg-orange-100 text-orange-800' :
                              item.color === 'blue' ? 'bg-blue-100 text-blue-800' :
                              'bg-gray-100 text-gray-800'
                            }>
                              {item.color === 'orange' ? 'HC' : 'C'}
                            </Badge>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                <div className="mt-6 grid md:grid-cols-2 gap-4">
                  <Card className="border-2 border-orange-200 bg-orange-50">
                    <CardHeader>
                      <CardTitle className="text-base text-orange-900">Highly Confidential (HC)</CardTitle>
                    </CardHeader>
                    <CardContent className="text-sm text-gray-700">
                      <p className="mb-2">Tools that can store Highly Confidential data when properly configured:</p>
                      <ul className="space-y-1">
                        <li>• Requires permission restrictions</li>
                        <li>• Encryption required</li>
                        <li>• Access controls must be configured</li>
                        <li>• Audit logging enabled</li>
                      </ul>
                    </CardContent>
                  </Card>

                  <Card className="border-2 border-blue-200 bg-blue-50">
                    <CardHeader>
                      <CardTitle className="text-base text-blue-900">Confidential (C)</CardTitle>
                    </CardHeader>
                    <CardContent className="text-sm text-gray-700">
                      <p className="mb-2">Tools limited to Confidential data:</p>
                      <ul className="space-y-1">
                        <li>• Do NOT store Highly Confidential data</li>
                        <li>• Standard access controls</li>
                        <li>• Internal use only</li>
                        <li>• Basic security requirements</li>
                      </ul>
                    </CardContent>
                  </Card>
                </div>

                <Alert className="mt-6 border-red-500 bg-red-50">
                  <XCircle className="h-5 w-5 text-red-600" />
                  <AlertDescription className="text-red-800 ml-2">
                    <strong>⚠️ Critical Data Warning:</strong> NONE of these tools are approved for storing Critical (RED) data such as credentials, government IDs, or sensitive customer PII. Critical data requires specialized secure storage solutions with additional security controls.
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          </TabsContent>

          {/* SaferAI Scoring Tab */}
          <TabsContent value="scoring">
            <Card className="border-2 border-[#232F3E]">
              <CardHeader className="bg-gradient-to-r from-[#232F3E] to-[#37475A] text-white">
                <div className="flex items-center gap-3">
                  <Calculator className="h-8 w-8 text-[#FF9900]" />
                  <div>
                    <CardTitle className="text-2xl">SaferAI Scoring Mechanism</CardTitle>
                    <CardDescription className="text-gray-200">
                      How risk scores are calculated and interpreted
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-6 space-y-6">
                {/* Overview */}
                <Alert className="border-blue-500 bg-blue-50">
                  <Info className="h-5 w-5 text-blue-600" />
                  <AlertDescription className="text-gray-800 ml-2">
                    SaferAI uses a quantitative risk scoring system to evaluate AI agent security across multiple dimensions. Higher scores indicate higher security risk and stricter requirements. Both Concept and Product Reviews use the same 40-point scale.
                  </AlertDescription>
                </Alert>

                {/* Concept Review Scoring */}
                <Card className="border-2 border-green-300">
                  <CardHeader className="bg-green-50">
                    <CardTitle className="text-xl text-green-900">Concept Review Scoring (Max: 40 points)</CardTitle>
                    <CardDescription className="text-green-700">
                      Risk assessment during the planning phase
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="p-6 space-y-4">
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-3">8 Assessment Categories:</h4>
                      <div className="space-y-2">
                        {scoringMechanism.concept.categories.map((category, idx) => (
                          <div key={idx} className="flex items-start justify-between p-3 bg-white rounded border">
                            <div className="flex-1">
                              <p className="font-medium text-gray-900">{category.name}</p>
                              <p className="text-sm text-gray-600">{category.description}</p>
                            </div>
                            <div className="text-right ml-4">
                              <p className="font-bold text-gray-900">{category.maxPoints} pts</p>
                              <p className="text-xs text-gray-500">{category.weight}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="border-t pt-4">
                      <h4 className="font-semibold text-gray-900 mb-3">Risk Zones:</h4>
                      <div className="space-y-2">
                        {scoringMechanism.concept.zones.map((zone, idx) => (
                          <div key={idx} className={`p-4 rounded border-2 ${
                            zone.color === 'green' ? 'border-green-500 bg-green-50' :
                            zone.color === 'yellow' ? 'border-yellow-500 bg-yellow-50' :
                            'border-red-500 bg-red-50'
                          }`}>
                            <div className="flex items-center justify-between mb-2">
                              <h5 className="font-bold text-gray-900">{zone.name}</h5>
                              <Badge className={
                                zone.color === 'green' ? 'bg-green-100 text-green-800' :
                                zone.color === 'yellow' ? 'bg-yellow-100 text-yellow-800' :
                                'bg-red-100 text-red-800'
                              }>
                                {zone.range} points
                              </Badge>
                            </div>
                            <p className="text-sm text-gray-700 mb-1"><strong>Status:</strong> {zone.status}</p>
                            <p className="text-sm text-gray-700"><strong>Action:</strong> {zone.action}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Product Review Scoring */}
                <Card className="border-2 border-purple-300">
                  <CardHeader className="bg-purple-50">
                    <CardTitle className="text-xl text-purple-900">Product Review Scoring (Max: 40 points)</CardTitle>
                    <CardDescription className="text-purple-700">
                      Risk assessment for deployed products using the same scale
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="p-6 space-y-4">
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-3">Same 8 Assessment Categories:</h4>
                      <div className="space-y-2">
                        {scoringMechanism.product.categories.map((category, idx) => (
                          <div key={idx} className="flex items-start justify-between p-3 bg-white rounded border">
                            <div className="flex-1">
                              <p className="font-medium text-gray-900">{category.name}</p>
                              <p className="text-sm text-gray-600">{category.description}</p>
                            </div>
                            <div className="text-right ml-4">
                              <p className="font-bold text-gray-900">{category.maxPoints} pts</p>
                              <p className="text-xs text-gray-500">{category.weight}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <Alert className="border-purple-500 bg-purple-50">
                      <Info className="h-5 w-5 text-purple-600" />
                      <AlertDescription className="text-purple-900 ml-2">
                        <strong>Optional Security Analysis:</strong> Product Review can include automated security scans that provide detailed vulnerability reports. These findings inform the risk assessment and recommendations but don't add extra points to the 40-point scale.
                        <div className="mt-2 space-y-1">
                          {scoringMechanism.product.additionalAnalysis.map((analysis, idx) => (
                            <div key={idx} className="text-sm">
                              <strong>• {analysis.name}:</strong> {analysis.description}
                            </div>
                          ))}
                        </div>
                      </AlertDescription>
                    </Alert>

                    <div className="border-t pt-4">
                      <h4 className="font-semibold text-gray-900 mb-3">Risk Zones:</h4>
                      <div className="space-y-2">
                        {scoringMechanism.product.zones.map((zone, idx) => (
                          <div key={idx} className={`p-4 rounded border-2 ${
                            zone.color === 'green' ? 'border-green-500 bg-green-50' :
                            zone.color === 'yellow' ? 'border-yellow-500 bg-yellow-50' :
                            'border-red-500 bg-red-50'
                          }`}>
                            <div className="flex items-center justify-between mb-2">
                              <h5 className="font-bold text-gray-900">{zone.name}</h5>
                              <Badge className={
                                zone.color === 'green' ? 'bg-green-100 text-green-800' :
                                zone.color === 'yellow' ? 'bg-yellow-100 text-yellow-800' :
                                'bg-red-100 text-red-800'
                              }>
                                {zone.range} points
                              </Badge>
                            </div>
                            <p className="text-sm text-gray-700 mb-1"><strong>Status:</strong> {zone.status}</p>
                            <p className="text-sm text-gray-700"><strong>Action:</strong> {zone.action}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Scoring Methodology */}
                <Card className="border-2 border-blue-300">
                  <CardHeader className="bg-blue-50">
                    <CardTitle className="text-xl text-blue-900">Scoring Methodology</CardTitle>
                  </CardHeader>
                  <CardContent className="p-6 space-y-4">
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2">How Scores Are Calculated:</h4>
                      <ul className="space-y-2">
                        {scoringMechanism.scoring.methodology.map((item, idx) => (
                          <li key={idx} className="flex items-start gap-2 text-sm text-gray-700">
                            <span className="text-blue-600 font-bold mt-1">•</span>
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="border-t pt-4">
                      <h4 className="font-semibold text-gray-900 mb-2">Interpreting Scores:</h4>
                      <ul className="space-y-2">
                        {scoringMechanism.scoring.interpretation.map((item, idx) => (
                          <li key={idx} className="flex items-start gap-2 text-sm text-gray-700">
                            <CheckCircle className="h-4 w-4 text-green-600 mt-1 flex-shrink-0" />
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </CardContent>
                </Card>

                {/* Example Scenarios */}
                <Card className="border-2 border-gray-300">
                  <CardHeader className="bg-gray-50">
                    <CardTitle className="text-xl text-gray-900">Example Scoring Scenarios</CardTitle>
                  </CardHeader>
                  <CardContent className="p-6">
                    <div className="space-y-4">
                      <div className="p-4 border-l-4 border-green-500 bg-green-50 rounded">
                        <h5 className="font-bold text-green-900 mb-2">Low Risk Example (Score: 12/40)</h5>
                        <p className="text-sm text-gray-700 mb-2">
                          Internal documentation chatbot using only public docs, structured inputs, team-only outputs, comprehensive logging
                        </p>
                        <p className="text-sm text-green-800"><strong>Result:</strong> Green Zone - Ready to build/deploy</p>
                      </div>

                      <div className="p-4 border-l-4 border-yellow-500 bg-yellow-50 rounded">
                        <h5 className="font-bold text-yellow-900 mb-2">Medium Risk Example (Score: 24/40)</h5>
                        <p className="text-sm text-gray-700 mb-2">
                          Customer support assistant accessing support case data, free-text prompts, semi-automated responses, cross-org visibility
                        </p>
                        <p className="text-sm text-yellow-800"><strong>Result:</strong> Amber Zone - Design with care/address issues, SWAT consultation recommended</p>
                      </div>

                      <div className="p-4 border-l-4 border-red-500 bg-red-50 rounded">
                        <h5 className="font-bold text-red-900 mb-2">High Risk Example (Score: 35/40)</h5>
                        <p className="text-sm text-gray-700 mb-2">
                          Customer-facing agent with PII access, elevated permissions, external integrations, fully automated outputs, minimal logging
                        </p>
                        <p className="text-sm text-red-800"><strong>Result:</strong> Red Zone - Needs rework/deployment blocked, mandatory SWAT review, security certification required</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Best Practices */}
                <Alert className="border-[#FF9900] bg-orange-50">
                  <Shield className="h-5 w-5 text-[#FF9900]" />
                  <AlertDescription className="text-gray-800 ml-2">
                    <strong>💡 Best Practice:</strong> Aim to keep your risk score as low as possible by implementing proper security controls, limiting data access, adding human review checkpoints, and maintaining comprehensive logging. Even if you're in the green zone, continuously monitor and improve your security posture.
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default Mechanism;