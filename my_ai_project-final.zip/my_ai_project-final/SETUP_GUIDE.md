# SaferAI - Complete Setup & Installation Guide

## Project Structure

```
my_ai_project-final/
├── public/                          # Static assets
│   └── favicon.ico                  # Site icon
├── src/                             # Source code
│   ├── pages/                       # Page components
│   │   ├── Home.jsx
│   │   ├── ConceptReview.jsx
│   │   ├── ProductReview.jsx
│   │   ├── Mechanism.jsx
│   │   ├── GuidanceBot.jsx
│   │   ├── PreFlightCheck.jsx
│   │   └── Login.jsx
│   ├── components/ui/               # UI components (Radix UI)
│   │   ├── button.jsx
│   │   ├── card.jsx
│   │   ├── input.jsx
│   │   ├── textarea.jsx
│   │   ├── select.jsx
│   │   └── ... (other UI components)
│   ├── services/                    # API services
│   │   └── api.js                   # SaferAI API client
│   ├── lib/                         # Utility libraries
│   │   └── pdfGenerator.js          # PDF generation
│   ├── App.jsx                      # Main app component
│   ├── main.jsx                     # React entry point
│   ├── index.css                    # Global styles
│   ├── App.css                      # App-specific styles
│   ├── amplifyConfig.js             # AWS Amplify configuration
│   ├── utils.js                     # Utility functions
│   ├── use-mobile.js                # Mobile detection hook
│   ├── tooltips.js                  # Tooltip utilities
│   └── compatibilityMatrix.js       # Compatibility data
├── index.html                       # HTML entry point
├── vite.config.js                   # Vite configuration
├── package.json                     # Dependencies
├── .env                             # Environment variables
└── README.md                        # Project documentation
```

## Installation Steps

### 1. Extract the Project

```bash
unzip my_ai_project-final.zip
cd my_ai_project-final
```

### 2. Install Dependencies

Using npm:
```bash
npm install
```

Using pnpm (recommended):
```bash
pnpm install
```

Using yarn:
```bash
yarn install
```

### 3. Configure Environment Variables

Create or update the `.env` file in the project root:

```env
VITE_USE_MOCK_API=false
VITE_API_BASE_URL=https://0wji356jgl.execute-api.ap-south-1.amazonaws.com/prod
```

**Note:** For local development and testing, you can set `VITE_USE_MOCK_API=true` to use mock data instead of calling the real API.

### 4. Start the Development Server

```bash
npm run dev
```

The application will be available at: **http://localhost:5173**

## Key Files & Their Purposes

| File | Purpose |
|------|---------|
| `src/main.jsx` | React entry point - configures Amplify |
| `src/App.jsx` | Main app component with routing |
| `src/amplifyConfig.js` | AWS Cognito authentication config |
| `src/services/api.js` | API client with token management |
| `src/lib/pdfGenerator.js` | PDF report generation |
| `src/pages/ProductReview.jsx` | Main product review page |
| `src/pages/ConceptReview.jsx` | Concept review page |
| `index.html` | HTML template |
| `vite.config.js` | Vite bundler configuration |

## AWS Amplify Configuration

The app uses AWS Cognito for authentication. Configuration is in `src/amplifyConfig.js`:

```javascript
Auth: {
  region: 'ap-south-1',
  userPoolId: 'ap-south-1_tJYrDS5NW',
  userPoolWebClientId: '2643jfjr4492gpr6t5lbnoqnp9',
  oauth: {
    domain: 'ap-south-1tjyrds5nw.auth.ap-south-1.amazoncognito.com',
    scope: ['openid', 'email', 'profile', 'aws.cognito.signin.user.admin'],
    redirectSignIn: window.location.origin + '/auth/callback',
    redirectSignOut: window.location.origin,
    responseType: 'code',
  },
  mandatorySignIn: true,
}
```

## API Gateway Integration

The app communicates with AWS API Gateway at:
```
https://0wji356jgl.execute-api.ap-south-1.amazonaws.com/prod
```

### Endpoints:
- **POST /analyze-prompts** - Analyze prompts for security issues
- **POST /analyze-code** - Analyze code for vulnerabilities

### Token Exchange:
1. User authenticates via AWS Cognito
2. Amplify stores the ID token
3. API service (`src/services/api.js`) automatically adds token to requests
4. API Gateway validates token with Cognito Authorizer
5. Lambda function processes the request

## Troubleshooting

### Issue: Import errors for components

**Error:** `Failed to resolve import`

**Solution:** Ensure all imports use relative paths:
```javascript
// ✅ Correct
import { Button } from './components/ui/button.jsx';

// ❌ Wrong
import { Button } from '@/components/ui/button.jsx';
```

### Issue: Favicon not loading

**Error:** `GET http://localhost:5173/favicon.ico 404`

**Solution:** The favicon is in the `public/` directory. Vite automatically serves it. If the error persists, check that `public/favicon.ico` exists.

### Issue: 401 Unauthorized from API

**Error:** `❌ Unauthorized - token may be expired or invalid`

**Solution:**
1. Ensure you're logged in (check the Amplify UI)
2. Check browser console for token errors
3. Verify API Gateway has Cognito authorizer configured
4. Check that CORS headers include `Authorization`

### Issue: Blank page or app not loading

**Error:** White screen, no errors in console

**Solution:**
1. Clear browser cache: `Ctrl+Shift+Delete`
2. Restart dev server: `npm run dev`
3. Check browser console for JavaScript errors
4. Verify all dependencies are installed: `npm install`

## Development Commands

```bash
# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview

# Run linter
npm run lint
```

## Production Deployment

### Build for Production

```bash
npm run build
```

This creates an optimized build in the `dist/` directory.

### Deploy to AWS S3 + CloudFront

1. Build the project: `npm run build`
2. Upload `dist/` contents to S3 bucket
3. Configure CloudFront distribution
4. Update Cognito redirect URIs to production domain

### Update Amplify Configuration for Production

In `src/amplifyConfig.js`, update redirect URIs:

```javascript
oauth: {
  // ...
  redirectSignIn: 'https://yourdomain.com/auth/callback',
  redirectSignOut: 'https://yourdomain.com',
  // ...
}
```

## Testing with Mock API

To test without calling the real API, set in `.env`:

```env
VITE_USE_MOCK_API=true
```

The app will return mock data for:
- `/analyze-prompts` - Mock prompt security analysis
- `/analyze-code` - Mock code vulnerability analysis

## Browser Support

- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

## Performance Optimization

The app uses:
- **Vite** for fast development and optimized builds
- **React 19** for efficient rendering
- **TailwindCSS** for optimized styling
- **pdf-lib** for client-side PDF generation
- **TensorFlow.js** for local ML analysis

## Security Notes

1. **Never commit `.env` with real credentials**
2. **API tokens are stored securely in Amplify Auth**
3. **All API requests include Bearer token authentication**
4. **CORS is configured on API Gateway**
5. **Cognito Authorizer validates all API requests**

## Support Resources

- [Vite Documentation](https://vitejs.dev/)
- [React Documentation](https://react.dev/)
- [AWS Amplify Auth](https://docs.amplify.aws/javascript/build-a-backend/auth/)
- [TailwindCSS](https://tailwindcss.com/)
- [Radix UI](https://www.radix-ui.com/)

## Next Steps

1. **Install dependencies:** `npm install`
2. **Start dev server:** `npm run dev`
3. **Login with AWS Cognito credentials**
4. **Test the application**
5. **Review TOKEN_EXCHANGE_GUIDE.md for API details**

---

**Version:** 1.0.0  
**Last Updated:** December 3, 2025  
**Status:** Production Ready
