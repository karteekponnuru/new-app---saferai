# SAFER-AI

**Security Assessment Framework for Evaluating Risk in AI Agents**

SAFER-AI is Amazon's Seller Support TSE governance framework designed to make AI development safe, compliant, and accountable. It standardizes how every AI agent—whether low-code or high-code—is reviewed before and after development through two checkpoints: Concept Review and Product Review.

## Features

- **Home Page**: Interactive guidance bot to help developers understand what's safe to build
- **Mechanism Page**: Detailed explanation of how SaferAI evaluates AI agents with risk vectors and compatibility matrices
- **Concept Review**: Pre-development assessment form to identify risks early
- **Product Review**: Post-development validation to ensure compliance with original concept

## Tech Stack

- React 18
- Vite
- React Router DOM
- Tailwind CSS
- shadcn/ui components
- Lucide icons

## Installation

1. Install dependencies:
```bash
pnpm install
```

## Development

Start the development server:
```bash
pnpm run dev
```

The app will be available at `http://localhost:5173`

## Build

Create a production build:
```bash
pnpm run build
```

The build output will be in the `dist` directory.

## Preview Production Build

Preview the production build locally:
```bash
pnpm run preview
```

## Project Structure

```
safer-ai/
├── src/
│   ├── pages/
│   │   ├── Home.jsx           # Home page with guidance bot
│   │   ├── Mechanism.jsx      # Mechanism explanation page
│   │   ├── ConceptReview.jsx  # Concept review form
│   │   └── ProductReview.jsx  # Product review form
│   ├── components/
│   │   └── ui/                # shadcn/ui components
│   ├── App.jsx                # Main app with routing
│   ├── App.css                # Global styles
│   └── main.jsx               # Entry point
├── public/                    # Static assets
├── index.html                 # HTML template
└── package.json               # Dependencies
```

## Key Features

### Home Page
- Three entry cards: Getting Started, Have Questions, Ready to Build
- Interactive guidance bot with conversational flow
- Risk assessment based on use case, data type, and platform
- Automatic routing to SWAT consultation when needed

### Mechanism Page
- Evaluation flow visualization
- Eight risk vectors explained
- Risk zones (Green, Amber, Red)
- Platform & data compatibility matrix
- Real-world examples

### Concept Review
- Comprehensive pre-development assessment
- Platform and data type selection
- Risk scoring algorithm
- PDF report generation (placeholder)
- SWAT consultation link for high-risk projects

### Product Review
- Three-step review process
- Concept PDF upload comparison
- Prompt security analysis
- Detailed questionnaire across 8 categories
- Final risk scoring and recommendations

## Design System

### Colors
- **Amazon Blue**: `#232F3E` (headers, primary text)
- **Amazon Orange**: `#FF9900` (CTAs, highlights)
- **Green Zone**: `#D1E7DD` (safe to build)
- **Amber Zone**: `#FFF3CD` (needs review)
- **Red Zone**: `#F8D7DA` (requires SWAT)

### Typography
- Font: Amazon Ember (system fallback)
- Clean, professional styling
- Clear hierarchy

## License

© Amazon Seller Support TSE

## Notes

- This is a demonstration application
- PDF generation functionality is placeholder (alerts in production would generate actual PDFs)
- Prompt analysis connects to Lambda API endpoint (currently simulated)
- SWAT consultation links point to Asana project templates

