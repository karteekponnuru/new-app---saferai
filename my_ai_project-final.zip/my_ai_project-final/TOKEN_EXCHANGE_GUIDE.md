# Token Exchange & API Gateway Integration Guide

## Overview

This guide explains how the token exchange works between your SaferAI React application and the AWS API Gateway, specifically for the `/analyze-prompts` and `/analyze-code` endpoints.

## Token Exchange Flow

```
┌─────────────────┐
│   React App     │
│  (Product      │
│   Review)      │
└────────┬────────┘
         │
         │ 1. User authenticates via AWS Cognito
         │
    ┌────▼─────────────────────┐
    │  AWS Cognito User Pool   │
    │  (ap-south-1)            │
    └────┬─────────────────────┘
         │
         │ 2. Returns ID Token + Access Token
         │
    ┌────▼──────────────────────┐
    │  Amplify Auth Module      │
    │  (Stores tokens in memory)│
    └────┬──────────────────────┘
         │
         │ 3. API Service extracts ID Token
         │
    ┌────▼──────────────────────────────┐
    │  api.js (SaferAIApi)              │
    │  - Intercepts requests            │
    │  - Adds Bearer token to headers   │
    └────┬──────────────────────────────┘
         │
         │ 4. POST /analyze-prompts
         │    Headers: Authorization: Bearer <ID_TOKEN>
         │
    ┌────▼─────────────────────────────┐
    │  API Gateway                      │
    │  (0wji356jgl.execute-api...)      │
    │  - Validates token with Cognito   │
    │  - Authorizer checks permissions  │
    └────┬─────────────────────────────┘
         │
         │ 5. Invokes Lambda function
         │
    ┌────▼──────────────────┐
    │  Lambda Function      │
    │  (analyze-prompts)    │
    └──────────────────────┘
```

## Key Components

### 1. Amplify Configuration (`amplifyConfig.js`)

```javascript
Auth: {
  region: 'ap-south-1',
  userPoolId: 'ap-south-1_tJYrDS5NW',
  userPoolWebClientId: '2643jfjr4492gpr6t5lbnoqnp9',
  oauth: {
    domain: 'ap-south-1tjyrds5nw.auth.ap-south-1.amazoncognito.com',
    scope: ['openid', 'email', 'profile', 'aws.cognito.signin.user.admin'],
    redirectSignIn: window.location.origin + '/auth/callback',
    redirectSignOut: window.location.origin,
    responseType: 'code',
  },
  mandatorySignIn: true,
}
```

**What it does:**
- Connects your app to AWS Cognito User Pool in `ap-south-1` region
- Configures OAuth flow with proper redirect URIs
- Enables automatic token refresh

### 2. API Service (`api.js`)

The `SaferAIApi` class handles all API communication:

```javascript
// Request Interceptor - Adds token to every request
this.client.interceptors.request.use(async (config) => {
  const session = await Auth.currentSession();
  const idToken = session.getIdToken().getJwtToken();
  config.headers.Authorization = `Bearer ${idToken}`;
  return config;
});

// Response Interceptor - Handles 401 errors
this.client.interceptors.response.use(
  (response) => response,
  async (error) => {
    if (error.response?.status === 401) {
      // Try to refresh token and retry
      const session = await Auth.currentSession();
      const newIdToken = session.getIdToken().getJwtToken();
      error.config.headers.Authorization = `Bearer ${newIdToken}`;
      return this.client.request(error.config);
    }
  }
);
```

**What it does:**
- Automatically extracts ID token from Amplify Auth
- Adds token to Authorization header: `Bearer <TOKEN>`
- Handles token refresh on 401 errors
- Provides detailed logging for debugging

### 3. App Integration (`App.jsx`)

```javascript
import { withAuthenticator } from '@aws-amplify/ui-react';
import Amplify from '@aws-amplify/core';
import cognitoAuthConfig from './amplifyConfig.js';

Amplify.configure(cognitoAuthConfig);

function App({ signOut, user }) {
  // user object contains authenticated user info
  // API service automatically uses tokens from Amplify
}

export default withAuthenticator(App);
```

**What it does:**
- `withAuthenticator` HOC provides login UI and auth context
- Amplify is configured at app level
- All child components can access tokens via Amplify Auth

## Troubleshooting 401 Unauthorized Errors

### Issue 1: Token Not Being Sent

**Symptoms:**
- Console shows: `⚠️ No ID token available`
- API returns 401

**Solution:**
```javascript
// Check if user is authenticated
const session = await Auth.currentSession();
console.log('Session:', session);
console.log('ID Token:', session.getIdToken().getJwtToken());
```

**Fix:**
- Ensure user is logged in via `withAuthenticator`
- Check browser console for auth errors
- Verify Cognito configuration in `amplifyConfig.js`

### Issue 2: Token Expired

**Symptoms:**
- First request succeeds, subsequent requests fail with 401
- Console shows: `🔄 Attempting to refresh token...`

**Solution:**
The API service automatically handles token refresh. If refresh fails:
1. User is redirected to login
2. Check Cognito session configuration
3. Verify `automaticSilentRenew` is enabled

### Issue 3: API Gateway Authorizer Rejection

**Symptoms:**
- Token is sent (console shows ✅)
- API returns 401 or 403

**Solution:**
Check API Gateway Cognito Authorizer settings:
```
1. Go to API Gateway → Authorizers
2. Verify Cognito User Pool is selected
3. Check Identity Source: `method.request.header.Authorization`
4. Verify Token Validation Expression: `^Bearer [-0-9a-zA-z\.]*$`
5. Check Identity Validation Expression: `aud`
```

### Issue 4: CORS Errors

**Symptoms:**
- Browser console shows CORS error
- Request is blocked before reaching API

**Solution:**
API Gateway CORS configuration:
```
1. Go to API Gateway → Resources → Enable CORS
2. Add headers: Authorization, Content-Type
3. Allowed methods: POST, GET, OPTIONS
4. Allowed origins: http://localhost:5173 (dev), your domain (prod)
```

## Environment-Specific Configuration

### Local Development (localhost:5173)

```javascript
// amplifyConfig.js
redirectSignIn: 'http://localhost:5173/auth/callback',
redirectSignOut: 'http://localhost:5173',
```

### Production Deployment

```javascript
// amplifyConfig.js
redirectSignIn: 'https://yourdomain.com/auth/callback',
redirectSignOut: 'https://yourdomain.com',
```

## Debugging Checklist

- [ ] User is logged in (check `withAuthenticator` UI)
- [ ] Console shows `✅ Token added to request`
- [ ] Token is not expired (check `Auth.currentSession()`)
- [ ] API Gateway has Cognito authorizer configured
- [ ] API Gateway CORS allows Authorization header
- [ ] Cognito User Pool ID matches `amplifyConfig.js`
- [ ] API endpoint URL is correct: `https://0wji356jgl.execute-api.ap-south-1.amazonaws.com/prod`

## Testing Token Exchange

### Browser Console Test

```javascript
// In browser console
import { Auth } from '@aws-amplify/auth';

// Get current session
const session = await Auth.currentSession();
console.log('ID Token:', session.getIdToken().getJwtToken());

// Decode token (for inspection)
const token = session.getIdToken().getJwtToken();
const parts = token.split('.');
const payload = JSON.parse(atob(parts[1]));
console.log('Token Payload:', payload);
```

### API Test with Token

```javascript
// Test API call with token
const session = await Auth.currentSession();
const token = session.getIdToken().getJwtToken();

const response = await fetch(
  'https://0wji356jgl.execute-api.ap-south-1.amazonaws.com/prod/analyze-prompts',
  {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      prompt: 'test prompt',
      platform: 'test'
    })
  }
);

console.log('Response:', await response.json());
```

## Common Error Messages

| Error | Cause | Solution |
|-------|-------|----------|
| `401 Unauthorized` | Invalid/missing token | Check token extraction in api.js |
| `403 Forbidden` | User lacks permissions | Check Cognito groups/roles |
| `CORS error` | Missing CORS headers | Enable CORS in API Gateway |
| `Invalid token` | Token format incorrect | Verify Bearer token format |
| `Token expired` | Session timeout | Implement token refresh |

## Files Modified for Token Exchange

1. **amplifyConfig.js** - Cognito configuration
2. **api.js** - Token extraction and API requests
3. **App.jsx** - Amplify setup and auth context
4. **main.jsx** - Root Amplify configuration
5. **ProductReview.jsx** - Uses saferAIApi for /analyze-prompts and /analyze-code

## Next Steps

1. **Test locally** with mock API first (`VITE_USE_MOCK_API=true`)
2. **Verify token flow** using browser console
3. **Check API Gateway logs** for authorization errors
4. **Enable CloudWatch logs** on API Gateway for debugging
5. **Test with real API** after verifying token exchange

## Support Resources

- [AWS Amplify Auth Documentation](https://docs.amplify.aws/javascript/build-a-backend/auth/)
- [API Gateway Cognito Authorizer](https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway-use-lambda-authorizer.html)
- [JWT Token Structure](https://tools.ietf.org/html/rfc7519)
