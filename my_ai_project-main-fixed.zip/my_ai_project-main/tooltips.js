/**
 * SaferAI Contextual Help and Tooltips
 * Provides guidance, examples, and explanations for each field
 */

export const TOOLTIPS = {
  projectName: {
    title: 'Project Name',
    content: 'A unique, descriptive name for your AI agent or automation',
    example: 'AutoSummarizer for Ops Reports, Ticket Classifier Bot',
    why: 'Helps identify and track your project through the review process'
  },
  
  developer: {
    title: 'Developer Name',
    content: 'Your full name as the primary developer or project owner',
    example: 'John Doe, Jane Smith',
    why: 'Establishes accountability and point of contact'
  },
  
  organization: {
    title: 'Organization',
    content: 'Your team, department, or organizational unit',
    example: 'SPS CT SWAT, AWS Support Engineering, Seller Services',
    why: 'Helps route reviews and track organizational patterns'
  },
  
  loginId: {
    title: 'Login ID / Email',
    content: 'Your Amazon email address or login ID',
    example: 'jdoe@amazon.com',
    why: 'Used for notifications and follow-up communications'
  },
  
  goal: {
    title: 'Goal / Problem Statement',
    content: 'Describe what problem you\'re solving and the expected outcome',
    example: 'Reduce manual effort in summarizing daily support reports by 80%',
    why: 'Helps reviewers understand business value and risk context',
    tips: 'Be specific about the problem, not just the solution'
  },
  
  devType: {
    title: 'Type of Development',
    content: 'The nature of your AI project',
    options: {
      'GenAI Agent': 'Conversational AI bot or assistant',
      'Workflow Automation': 'Automated process or task',
      'Extension': 'Enhancement to existing tool',
      'Script': 'Standalone automation script',
      'Integration': 'Connecting multiple systems'
    },
    why: 'Different types have different risk profiles'
  },
  
  stage: {
    title: 'Development Stage',
    content: 'Current maturity level of your project',
    options: {
      'Idea': 'Concept phase, not yet built',
      'Prototype': 'Early working version, testing feasibility',
      'Pilot': 'Limited deployment, testing with real users',
      'Production': 'Fully deployed and operational'
    },
    why: 'Earlier stages have more flexibility to adjust design'
  },
  
  platform: {
    title: 'Primary Platform',
    content: 'The AI platform or tool you\'re using to build your agent',
    why: 'Each platform has different capabilities and data access restrictions',
    note: 'Platform choice affects what data types you can use'
  },
  
  dataCategory: {
    title: 'Data Category',
    content: 'The type of data your agent will access or process',
    why: 'Data sensitivity is the primary risk factor in AI projects',
    note: 'We\'ll help you identify the right category through simple questions'
  },
  
  intendedOutput: {
    title: 'Intended Output',
    content: 'What your agent will generate or produce',
    examples: ['Summary', 'Email', 'Ticket Update', 'Report', 'Dashboard', 'Notification'],
    why: 'Output type affects visibility and potential data exposure'
  },
  
  expectedIntegrations: {
    title: 'Expected Integrations',
    content: 'External tools or systems your agent will connect to',
    examples: ['Slack', 'Sheets', 'Quip', 'Email', 'None', 'Internal APIs only'],
    why: 'External integrations increase risk of data exposure',
    note: 'Some platforms only support specific integrations'
  },
  
  teamSize: {
    title: 'Team Size / Roles',
    content: 'Who is involved in building and maintaining this project',
    example: '2 developers, 1 reviewer, 1 product manager',
    why: 'Helps understand project scope and support needs'
  },
  
  otherDetails: {
    title: 'Other Details',
    content: 'Any additional context that might be relevant',
    example: 'May expand to handle multilingual data, Currently English-only',
    why: 'Helps reviewers understand future plans and edge cases'
  },
  
  asrTicket: {
    title: 'ASR Ticket Number',
    content: 'Your Amazon Security Review ticket number (if applicable)',
    example: 'ASR-12345',
    why: 'Links your Product Review to existing security assessments',
    note: 'Leave blank if you don\'t have an ASR ticket yet'
  },
  
  conceptReviewId: {
    title: 'Concept Review Reference',
    content: 'Reference to your approved Concept Review',
    why: 'Allows comparison between planned and built features',
    note: 'Upload PDF or enter the review ID'
  }
};

export const PREFLIGHT_HELP = {
  title: 'Quick Pre-flight Check',
  subtitle: 'Answer these 3 quick questions to help us route your review appropriately',
  why: 'This saves time by identifying high-risk scenarios early',
  questions: [
    {
      id: 'customerData',
      question: 'Will your agent access customer data, PII, or personal information?',
      help: 'This includes customer names, emails, addresses, payment info, or any personally identifiable information',
      examples: {
        yes: 'Customer emails, chat transcripts, account details',
        no: 'Internal metrics, public data, sample datasets'
      }
    },
    {
      id: 'elevatedAccess',
      question: 'Does your agent need admin, elevated, or privileged permissions?',
      help: 'This includes system admin access, ability to modify data, or access to restricted systems',
      examples: {
        yes: 'Admin dashboards, database write access, system configuration',
        no: 'Read-only access, public APIs, standard user permissions'
      }
    },
    {
      id: 'externalIntegration',
      question: 'Will your agent integrate with external (non-Amazon) services?',
      help: 'This includes third-party APIs, external databases, or services outside Amazon infrastructure',
      examples: {
        yes: 'Public Slack workspace, Google Sheets, external APIs',
        no: 'Internal Slack, Amazon systems only, no external connections'
      }
    }
  ]
};

export const DATA_MAPPING_HELP = {
  title: 'Data Category Identification',
  subtitle: 'Answer these questions to help us identify your data category',
  why: 'We use simple questions instead of technical terms to avoid confusion',
  
  questions: [
    {
      id: 'securityData',
      question: 'Does your agent access security logs, vulnerability data, or credentials?',
      category: 'Highly Sensitive Security Data',
      riskLevel: 'critical',
      help: 'This is the most restricted data type',
      examples: 'Security incident logs, vulnerability reports, authentication tokens'
    },
    {
      id: 'customerContent',
      question: 'Will it read or process customer messages, emails, or support communications?',
      category: 'Customer Content',
      riskLevel: 'critical',
      help: 'Direct customer communications require special handling',
      examples: 'Customer emails, chat transcripts, message content, support tickets'
    },
    {
      id: 'awsSupport',
      question: 'Does it use AWS Support case data or ticket information?',
      category: 'AWS Support Data',
      riskLevel: 'high',
      help: 'Support data contains technical details and may include customer context',
      examples: 'Support case metadata, ticket summaries, technical issues'
    },
    {
      id: 'customerAccount',
      question: 'Does it access customer account information (names, emails, account IDs)?',
      category: 'Customer Account Info',
      riskLevel: 'medium',
      help: 'Account metadata without message content',
      examples: 'Account IDs, subscription status, contact information'
    },
    {
      id: 'partnerData',
      question: 'Does it use partner or seller business data?',
      category: 'Business Partner Data',
      riskLevel: 'medium',
      help: 'Partner and seller information',
      examples: 'Seller metrics, partner agreements, business performance data'
    },
    {
      id: 'internalOnly',
      question: 'Only internal Amazon employee documents and data?',
      category: 'Internal / Employee Docs',
      riskLevel: 'low',
      help: 'Internal operational data',
      examples: 'Meeting notes, internal wikis, employee resources'
    },
    {
      id: 'publicOnly',
      question: 'Public or sample data only?',
      category: 'Public / Sample Data',
      riskLevel: 'low',
      help: 'Lowest risk category',
      examples: 'Public documentation, sample datasets, mock data'
    }
  ]
};

export const RISK_ZONE_HELP = {
  green: {
    title: 'Green Zone – Ready to Build',
    meaning: 'Your concept aligns with policy and approved use cases',
    action: 'You can proceed to development',
    tips: [
      'Document your implementation plan',
      'Set up proper logging and monitoring',
      'Plan for Product Review after completion',
      'Follow platform-specific best practices'
    ]
  },
  amber: {
    title: 'Amber Zone – Design with Care',
    meaning: 'Some parameters need validation before scaling',
    action: 'Review and adjust before full deployment',
    tips: [
      'Review data sources and ensure proper classification',
      'Validate integration security measures',
      'Add monitoring and logging',
      'Consider human review checkpoints',
      'Resubmit after adjustments'
    ]
  },
  red: {
    title: 'Red Zone – Needs Rework',
    meaning: 'Your concept involves restricted data or high-risk operations',
    action: 'SWAT consultation required',
    tips: [
      'Prepare detailed documentation',
      'Schedule SWAT consultation',
      'Review alternative approaches',
      'Consider using approved data types',
      'Do not proceed without SWAT approval'
    ]
  }
};

export const COMPARISON_HELP = {
  title: 'Concept vs Product Comparison',
  subtitle: 'This shows what changed between your original concept and final product',
  why: 'Changes in platform, data, or scope can affect risk level',
  indicators: {
    'No Change': 'Everything matches your original concept',
    'Changed': 'This parameter was modified during development',
    'Broadened': 'Scope or access increased from original plan',
    'Expanded': 'Additional features or capabilities added',
    'Reduced': 'Scope decreased from original plan'
  }
};

/**
 * Get tooltip content for a field
 * @param {string} fieldName - Field identifier
 * @returns {object} Tooltip content
 */
export function getTooltip(fieldName) {
  return TOOLTIPS[fieldName] || { title: fieldName, content: 'No help available' };
}

/**
 * Get help text for preflight questions
 * @returns {object} Preflight help content
 */
export function getPreflightHelp() {
  return PREFLIGHT_HELP;
}

/**
 * Get help text for data mapping questions
 * @returns {object} Data mapping help content
 */
export function getDataMappingHelp() {
  return DATA_MAPPING_HELP;
}

/**
 * Get risk zone explanation
 * @param {string} zone - Risk zone (green, amber, red)
 * @returns {object} Risk zone help content
 */
export function getRiskZoneHelp(zone) {
  return RISK_ZONE_HELP[zone] || RISK_ZONE_HELP.green;
}

