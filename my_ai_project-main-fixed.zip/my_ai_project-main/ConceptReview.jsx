import { Button } from '@/components/ui/button.jsx';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Label } from '@/components/ui/label.jsx';
import { Textarea } from '@/components/ui/textarea.jsx';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group.jsx';
import { Alert, AlertDescription } from '@/components/ui/alert.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';
import { CheckCircle2, AlertTriangle, XCircle, Download, ExternalLink, ArrowRight, ArrowLeft, Loader2, HelpCircle, ChevronDown, ChevronUp, Info } from 'lucide-react';
import { generateSaferAIPDF } from '@/lib/pdfGenerator.js';
import saferAIApi from '@/services/api';
import { useState } from 'react'; 
import { useAuth } from 'react-oidc-context';

const platforms = [
  { value: 'party-rock', label: 'Party Rock', description: 'Educational tool for building apps with generative AI' },
  { value: 'cedric', label: 'Cedric', description: 'General purpose AI chatbot' },
  { value: 'amazon-q-internal', label: 'Amazon Q Internal', description: 'Generative AI–powered assistant' },
  { value: 'mentor', label: 'Mentor', description: 'RAG-enabled chat platform' },
  { value: 'field-advisor', label: 'Field Advisor', description: 'AI-powered assistant for AWS Field' },
  { value: 'aza', label: 'AZA (A to Z Assistant)', description: 'Intelligent assistant for Amazonians' },
  { value: 'matome', label: 'Matome', description: 'Generative AI assistant in Quip' },
  { value: 'bedrockbot', label: 'BedrockBot', description: 'Bedrock Bot Slack App' },
  { value: 'loki', label: 'Loki', description: 'Technical validation review tool' },
  { value: 'clue', label: 'Clue', description: 'Flexible search and content generation application' },
  { value: 'powerchat', label: 'PowerChat', description: 'AI assistant browser extension' },
  { value: 'support-genie', label: 'Support Genie', description: 'AI assistant for Command Center' },
  { value: 'aws-assessment-tool', label: 'AWS Assessment Tool', description: 'Customer facing survey tool' },
  { value: 'genai-photobooth', label: 'GenAI Photobooth', description: 'GenAI-powered photo filters' },
  { value: 'q-developer-cli', label: 'Q Developer CLI', description: 'Conversational assistant for AWS applications' },
  { value: 'amazon-quicksuite', label: 'Amazon QuickSuite', description: 'Unified AI agents workspace' },
  { value: 'other', label: 'Other', description: 'Custom platform' }
];

const devTypes = [
  { value: 'low-code', label: 'Low Code' },
  { value: 'high-code', label: 'High Code' },
  { value: 'no-code', label: 'No Code' },
  { value: 'hybrid', label: 'Hybrid' }
];

const dataClassifications = [
  {
    value: 'public',
    label: 'Public Data',
    description: 'Information intended for public view (e.g., product listings, press releases)',
    note: "'Public' does not mean 'casual' - requires proper consideration and approval",
    riskLevel: 'low',
    color: 'text-green-700',
    bgColor: 'bg-green-50',
    borderColor: 'border-green-200'
  },
  {
    value: 'confidential',
    label: 'Confidential Data',
    description: 'Sensitive information that would cause minimal risk if exposed',
    note: 'Base level for non-public information',
    riskLevel: 'low',
    color: 'text-blue-700',
    bgColor: 'bg-blue-50',
    borderColor: 'border-blue-200'
  },
  {
    value: 'highly-confidential',
    label: 'Highly Confidential Data',
    description: 'Requires stronger protection than Confidential data',
    note: 'Orange level in Anvil. Unique to customers/vendors (e.g., contract details, payment information)',
    riskLevel: 'medium',
    color: 'text-orange-700',
    bgColor: 'bg-orange-50',
    borderColor: 'border-orange-200',
    examples: ['Contract details', 'Payment information', 'Vendor agreements']
  },
  {
    value: 'restricted',
    label: 'Restricted Data',
    description: 'Information that could significantly impact Amazon\'s competitive position if exposed',
    note: 'Should not be shared externally under any circumstances',
    riskLevel: 'high',
    color: 'text-amber-700',
    bgColor: 'bg-amber-50',
    borderColor: 'border-amber-200',
    examples: ['Business metrics', 'Customer behavior patterns', 'Financial decision algorithms']
  },
  {
    value: 'critical',
    label: 'Critical Data',
    description: 'Highest level of protection - RED applications in Anvil',
    note: '⚠️ Requires security certifier engagement during design phase',
    riskLevel: 'critical',
    color: 'text-red-700',
    bgColor: 'bg-red-50',
    borderColor: 'border-red-200',
    examples: ['Government IDs', 'Credentials', 'Sensitive customer PII', 'Authentication tokens']
  }
];

const toolClassifications = [
  { tool: 'Sharepoint', classification: 'Up to Highly Confidential (if configured correctly)' },
  { tool: 'Shared ANT drive', classification: 'Confidential' },
  { tool: 'Drive', classification: 'Highly Confidential with permission restrictions' },
  { tool: 'Workdocs', classification: 'Highly Confidential with permission restrictions' },
  { tool: 'Quip', classification: 'Highly Confidential with permission restrictions' },
  { tool: 'Trawler', classification: 'Confidential' },
  { tool: 'Wiki', classification: 'Confidential (Do NOT store Highly Confidential data)' },
  { tool: 'Internal Email/Outlook', classification: 'Highly Confidential (with warning prefix and permissions)' },
  { tool: 'TT/SIM/T-corp', classification: 'Highly Confidential with permission restrictions' },
  { tool: 'Chime', classification: 'Up to Highly Confidential (internal use only)' },
  { tool: 'Slack', classification: 'Up to Highly Confidential (private channels only)' },
  { tool: 'Tableau A3', classification: 'Highly Confidential' },
  { tool: 'Playbook', classification: 'Confidential' }
];

// Progress Bar Component
const ProgressBar = ({ currentStep, totalSteps }) => {
  const progress = (currentStep / totalSteps) * 100;
  const stepLabels = ['Pre-Flight', 'Project Details', 'Risk Assessment', 'Results'];

  return (
    <div className="mb-8">
      <div className="flex justify-between items-center mb-2">
        {stepLabels.map((label, idx) => (
          <div key={idx} className="flex flex-col items-center flex-1">
            <div className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold transition-all ${
              idx < currentStep ? 'bg-green-500 text-white' :
              idx === currentStep ? 'bg-[#FF9900] text-white shadow-lg scale-110' :
              'bg-gray-300 text-gray-600'
            }`}>
              {idx < currentStep ? '✓' : idx + 1}
            </div>
            <span className={`text-xs mt-2 font-medium ${idx === currentStep ? 'text-[#FF9900]' : 'text-gray-600'}`}>
              {label}
            </span>
          </div>
        ))}
      </div>
      <div className="w-full bg-gray-200 rounded-full h-2.5">
        <div
          className="bg-[#FF9900] h-2.5 rounded-full transition-all duration-500 ease-out"
          style={{ width: `${progress}%` }}
        />
      </div>
      <div className="flex justify-between mt-2">
        <span className="text-xs text-gray-500">Step {currentStep + 1} of {totalSteps + 1}</span>
        <span className="text-xs font-semibold text-[#FF9900]">{Math.round(progress)}% Complete</span>
      </div>
    </div>
  );
};

// Enhanced Pre-Flight Check Component
const EnhancedPreFlightCheck = ({ onComplete }) => {
  const [answers, setAnswers] = useState({
    customer_data: null,
    external_output: null,
    elevated_access: null,
    ufs_access: null,
    tool_access: null
  });

  const questions = [
    {
      id: 'customer_data',
      question: 'Will your agent process or access customer data?',
      options: [
        { value: 'yes', label: 'Yes', isWarning: true },
        { value: 'no', label: 'No' }
      ],
      warningMessage: '⚠️ Customer data access requires additional security reviews and compliance measures. You must engage with security teams early in the design phase.'
    },
    {
      id: 'external_output',
      question: 'Will outputs be shared outside your immediate team?',
      options: [
        { value: 'yes', label: 'Yes', isWarning: true },
        { value: 'no', label: 'No' }
      ],
      warningMessage: '⚠️ External sharing requires output validation, approval workflows, and monitoring mechanisms to prevent data leakage.'
    },
    {
      id: 'elevated_access',
      question: 'Will your agent need elevated system permissions or admin access?',
      options: [
        { value: 'yes', label: 'Yes', isWarning: true },
        { value: 'no', label: 'No' }
      ],
      warningMessage: '⚠️ Elevated permissions significantly increase security risk. You must implement strict access controls and comprehensive audit logging.'
    },
    {
      id: 'ufs_access',
      question: 'Does your agent need UFS (Unfettered Search) Access?',
      options: [
        { value: 'yes', label: 'Yes', isWarning: true },
        { value: 'no', label: 'No' }
      ],
      warningMessage: '⚠️ UFS access requires SWAT consultation. This is a critical permission issue that must be reviewed before proceeding with development.'
    },
    {
      id: 'tool_access',
      question: 'Does your agent need access to any of these tools?',
      options: [
        { value: 'bulk-tools', label: 'Bulk Tools', isWarning: true },
        { value: 'base-tenant', label: 'Base Tenant Access', isWarning: true },
        { value: 'none', label: 'None of these' }
      ],
      warningMessage: '⚠️ Access to Bulk Tools or Base Tenant requires special permissions and SWAT review due to the scope of data access.'
    }
  ];

  const handleAnswer = (questionId, value) => {
    setAnswers(prev => ({ ...prev, [questionId]: value }));
  };

  const handleContinue = () => {
    const warnings = [];
    questions.forEach(q => {
      const answer = answers[q.id];
      const selectedOption = q.options.find(opt => opt.value === answer);
      if (selectedOption?.isWarning) {
        warnings.push({
          question: q.question,
          answer: selectedOption.label,
          warning: q.warningMessage
        });
      }
    });

    onComplete({ answers, warnings });
  };

  const allAnswered = Object.values(answers).every(a => a !== null);
  const answeredCount = Object.values(answers).filter(a => a !== null).length;

  return (
    <Card className="border-2 border-[#232F3E] max-w-4xl mx-auto shadow-lg">
      <CardHeader className="bg-gradient-to-r from-[#232F3E] to-[#37475A] text-white">
        <CardTitle className="text-2xl">Pre-Flight Check</CardTitle>
        <CardDescription className="text-gray-200">
          Answer these 5 critical questions to identify potential data handling restrictions
        </CardDescription>
      </CardHeader>
      <CardContent className="p-6 space-y-6">
        {/* Mini Progress */}
        <div className="bg-blue-50 border-l-4 border-blue-500 p-4 rounded">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-semibold text-blue-900">Question Progress</span>
            <span className="text-sm font-bold text-blue-600">{answeredCount}/5 answered</span>
          </div>
          <div className="w-full bg-blue-200 rounded-full h-2">
            <div
              className="bg-blue-600 h-2 rounded-full transition-all duration-300"
              style={{ width: `${(answeredCount / 5) * 100}%` }}
            />
          </div>
        </div>

        {questions.map((question, index) => {
          const answer = answers[question.id];
          const selectedOption = question.options.find(opt => opt.value === answer);
          const showWarning = selectedOption?.isWarning;
          const isAnswered = answer !== null;

          return (
            <div key={question.id} className={`space-y-3 p-4 rounded-lg border-2 transition-all ${
              isAnswered ? 'border-green-300 bg-green-50' : 'border-gray-200 bg-white'
            }`}>
              <div className="flex items-start gap-3">
                <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${
                  isAnswered ? 'bg-green-500 text-white' : 'bg-gray-300 text-gray-600'
                }`}>
                  {isAnswered ? '✓' : index + 1}
                </div>
                <Label className="text-base font-semibold text-gray-900 flex-1">
                  {question.question}
                </Label>
              </div>
              <RadioGroup value={answer || ''} onValueChange={(value) => handleAnswer(question.id, value)}>
                <div className="space-y-2 ml-11">
                  {question.options.map((option) => (
                    <div
                      key={option.value}
                      className={`flex items-center space-x-3 p-3 rounded-lg border-2 transition-all ${
                        answer === option.value
                          ? 'border-[#FF9900] bg-orange-50 shadow-sm'
                          : 'border-gray-200 hover:border-[#FF9900] hover:bg-gray-50'
                      }`}
                    >
                      <RadioGroupItem value={option.value} id={`${question.id}-${option.value}`} />
                      <Label htmlFor={`${question.id}-${option.value}`} className="flex-1 cursor-pointer font-medium">
                        {option.label}
                      </Label>
                    </div>
                  ))}
                </div>
              </RadioGroup>
              {showWarning && (
                <Alert className="border-[#FF9900] bg-orange-50 mt-3 ml-11">
                  <AlertTriangle className="h-5 w-5 text-[#FF9900]" />
                  <AlertDescription className="text-gray-800 ml-2">
                    {question.warningMessage}
                  </AlertDescription>
                </Alert>
              )}
            </div>
          );
        })}

        <div className="pt-6 border-t">
          <Button
            onClick={handleContinue}
            disabled={!allAnswered}
            className="w-full bg-[#FF9900] hover:bg-[#EC7211] text-white disabled:bg-gray-300 disabled:cursor-not-allowed py-6 text-lg font-semibold"
          >
            {allAnswered ? (
              <>
                Continue to Project Details
                <ArrowRight className="ml-2 h-5 w-5" />
              </>
            ) : (
              <>
                Answer All Questions ({answeredCount}/5)
              </>
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

// Tool Classification Reference Component
const ToolClassificationReference = () => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  const filteredTools = toolClassifications.filter(tool =>
    tool.tool.toLowerCase().includes(searchTerm.toLowerCase()) ||
    tool.classification.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <Card className="border-2 border-blue-200 bg-blue-50">
      <CardHeader 
        className="cursor-pointer hover:bg-blue-100 transition-colors"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Info className="h-5 w-5 text-blue-600" />
            <CardTitle className="text-lg text-blue-900">Tool Classification Reference</CardTitle>
          </div>
          {isExpanded ? (
            <ChevronUp className="h-5 w-5 text-blue-600" />
          ) : (
            <ChevronDown className="h-5 w-5 text-blue-600" />
          )}
        </div>
        <CardDescription className="text-blue-700">
          Reference guide for data classification levels across common tools
        </CardDescription>
      </CardHeader>
      {isExpanded && (
        <CardContent className="p-6 space-y-4">
          <div>
            <Label htmlFor="tool-search" className="text-sm text-gray-700">Search Tools</Label>
            <Input
              id="tool-search"
              placeholder="Search by tool name or classification..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="mt-1"
            />
          </div>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse bg-white rounded-lg overflow-hidden shadow-sm">
              <thead>
                <tr className="bg-gray-100">
                  <th className="text-left p-3 font-semibold text-gray-900 border-b">Tool</th>
                  <th className="text-left p-3 font-semibold text-gray-900 border-b">Level of Classification</th>
                </tr>
              </thead>
              <tbody>
                {filteredTools.map((item, index) => (
                  <tr key={index} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                    <td className="p-3 border-b border-gray-200 font-medium text-gray-900">{item.tool}</td>
                    <td className="p-3 border-b border-gray-200 text-gray-700">{item.classification}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            {filteredTools.length === 0 && (
              <div className="text-center py-6 text-gray-500">
                No tools found matching "{searchTerm}"
              </div>
            )}
          </div>
        </CardContent>
      )}
    </Card>
  );
};

// Data Classification Selector Component
const DataClassificationSelector = ({ value, onChange }) => {
  const [showDetails, setShowDetails] = useState(false);
  const selectedClassification = dataClassifications.find(dc => dc.value === value);

  return (
    <div className="space-y-4">
      <div>
        <div className="flex items-center gap-2 mb-2">
          <Label htmlFor="dataCategory">Data Classification *</Label>
          <button
            type="button"
            onClick={() => setShowDetails(!showDetails)}
            className="text-blue-600 hover:text-blue-800"
          >
            <HelpCircle className="h-4 w-4" />
          </button>
        </div>
        <Select value={value} onValueChange={onChange}>
          <SelectTrigger id="dataCategory">
            <SelectValue placeholder="Select data classification level" />
          </SelectTrigger>
          <SelectContent>
            {dataClassifications.map((classification) => (
              <SelectItem key={classification.value} value={classification.value}>
                <div className="flex flex-col py-1">
                  <span className={`font-semibold ${classification.color}`}>
                    {classification.label}
                  </span>
                  <span className="text-xs text-gray-500">{classification.description}</span>
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {selectedClassification && (
        <Alert className={`${selectedClassification.borderColor} ${selectedClassification.bgColor} border-2`}>
          <Info className={`h-5 w-5 ${selectedClassification.color}`} />
          <AlertDescription className="ml-2">
            <div className="space-y-2">
              <p className={`font-semibold ${selectedClassification.color}`}>
                {selectedClassification.label}
              </p>
              <p className="text-gray-700 text-sm">
                {selectedClassification.description}
              </p>
              <p className="text-gray-600 text-sm italic">
                {selectedClassification.note}
              </p>
              {selectedClassification.examples && (
                <div className="mt-2">
                  <p className="text-sm font-semibold text-gray-700">Examples:</p>
                  <ul className="list-disc list-inside text-sm text-gray-600 ml-2">
                    {selectedClassification.examples.map((example, idx) => (
                      <li key={idx}>{example}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </AlertDescription>
        </Alert>
      )}

      {showDetails && (
        <Card className="border-blue-200 bg-blue-50">
          <CardHeader>
            <CardTitle className="text-base text-blue-900">Data Classification Guide</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {dataClassifications.map((classification) => (
              <div key={classification.value} className="bg-white p-3 rounded border border-gray-200">
                <p className={`font-semibold ${classification.color}`}>{classification.label}</p>
                <p className="text-sm text-gray-700 mt-1">{classification.description}</p>
                <p className="text-xs text-gray-600 italic mt-1">{classification.note}</p>
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  );
};

// Main ConceptReview Component
const ConceptReview = () => {
  const auth = useAuth();
  const [currentStep, setCurrentStep] = useState(0);
  const [preFlightResults, setPreFlightResults] = useState(null);
  const [isGeneratingPDF, setIsGeneratingPDF] = useState(false);
  const [pdfError, setPdfError] = useState(null);
  const [pdfSuccess, setPdfSuccess] = useState(false);
  
  const [formData, setFormData] = useState({
    projectName: '',
    developer: '',
    org: '',
    loginId: '',
    date: new Date().toISOString().split('T')[0],
    goal: '',
    devType: '',
    stage: 'concept',
    platform: '',
    customPlatform: '',
    dataCategory: '',
    intendedOutput: '',
    expectedIntegrations: '',
    teamSize: '',
    otherDetails: ''
  });
 
  const [answers, setAnswers] = useState({});
  const [riskScore, setRiskScore] = useState(0);
  const [normalizedScore, setNormalizedScore] = useState(0);
  const [riskZone, setRiskZone] = useState('');
  const [showGuidance, setShowGuidance] = useState(true);
  const [expandedGuidance, setExpandedGuidance] = useState({});

  const questions = [
    {
      category: 'A. Data Sensitivity',
      description: 'Understanding what data your agent accesses helps determine required security controls',
      items: [
        {
          id: 'data_type',
          question: 'What type of data will your agent use?',
          guidance: {
            title: 'Why this matters',
            content: 'Data sensitivity directly impacts security requirements. Higher sensitivity data requires stronger controls, logging, and review processes. This is often the primary factor in determining your overall risk level.',
            helpText: 'Choose the HIGHEST classification level of any data your agent will access. When in doubt, choose the more restrictive option and consult with your security team.'
          },
          options: [
            { text: 'Public/mock data', score: 0, description: 'No real data, demos only' },
            { text: 'Internal business data', score: 1, description: 'General company information' },
            { text: 'Business/Partner data', score: 2, description: 'Shared with business partners' },
            { text: 'AWS Support data', score: 3, description: 'Customer support cases and tickets' },
            { text: 'Customer/PII data', score: 5, description: 'Personal identifiable information' }
          ]
        },
        {
          id: 'customer_data',
          question: 'Does your idea process or derive insights from customer-linked data?',
          guidance: {
            title: 'Why this matters',
            content: 'Customer data processing has the highest compliance requirements. Any mishandling could lead to privacy violations, regulatory penalties, and loss of customer trust.',
            helpText: 'If your agent touches any data that can be traced back to a specific customer (even indirectly), answer "Yes". This includes aggregated data if it can be de-anonymized.'
          },
          options: [
            { text: 'No - no customer data involved', score: 0, description: 'Completely isolated from customer data' },
            { text: 'Possibly - indirect customer data', score: 3, description: 'May process aggregated or anonymized data' },
            { text: 'Yes - direct customer data access', score: 5, description: 'Processes identifiable customer information' }
          ]
        }
      ]
    },
    {
      category: 'B. Access Permissions',
      description: 'The level of system access determines potential impact if compromised',
      items: [
        {
          id: 'access_level',
          question: 'What kind of access will your solution need?',
          guidance: {
            title: 'Why this matters',
            content: 'Higher access levels mean greater potential for damage if your agent is compromised or behaves unexpectedly. Write access can modify data, while elevated access can affect entire systems.',
            helpText: 'Consider what your agent needs to DO, not just what it needs to SEE. If it will ever create, update, or delete data, that\'s write access.'
          },
          options: [
            { text: 'None - fully sandboxed', score: 0, description: 'No system access required' },
            { text: 'Basic read access', score: 2, description: 'Can view data only' },
            { text: 'Write/update access', score: 3, description: 'Can modify existing data' },
            { text: 'Elevated/system access', score: 5, description: 'Admin or system-level permissions' }
          ]
        },
        {
          id: 'api_interaction',
          question: 'Will it interact with dashboards, APIs, or case data?',
          guidance: {
            title: 'Why this matters',
            content: 'API interactions can expose data to external systems or create dependencies on third-party services. Cross-tenant access multiplies security complexity.',
            helpText: 'Internal APIs are those within your AWS organization. External includes any third-party services, customer-facing APIs, or cross-organizational integrations.'
          },
          options: [
            { text: 'No - standalone operation', score: 0, description: 'No external interactions' },
            { text: 'Internal only', score: 2, description: 'Within our AWS organization' },
            { text: 'External or cross-tenant', score: 4, description: 'Third-party or customer systems' }
          ]
        }
      ]
    },
    {
      category: 'C. Output Safety',
      description: 'Where outputs go determines the blast radius of potential issues',
      items: [
        {
          id: 'output_visibility',
          question: 'Where will the outputs be visible?',
          guidance: {
            title: 'Why this matters',
            content: 'Public or external outputs require the highest level of review and validation. Incorrect or sensitive information reaching customers or the public can cause significant reputational and legal damage.',
            helpText: 'Consider not just the immediate output, but where it might be forwarded or shared. Team-only means strictly within your direct team with no forwarding capability.'
          },
          options: [
            { text: 'Team-only', score: 1, description: 'Restricted to immediate team members' },
            { text: 'Cross-org', score: 3, description: 'Shared across multiple teams/orgs' },
            { text: 'Public/External', score: 5, description: 'Visible to customers or public' }
          ]
        },
        {
          id: 'auto_generated',
          question: 'Are outputs auto-generated without human review?',
          guidance: {
            title: 'Why this matters',
            content: 'Automated outputs bypass human judgment, which can catch AI errors, hallucinations, or inappropriate content. External automated outputs are especially risky.',
            helpText: 'Human review means a person must actively approve each output before it\'s shared. "Auto-generated with monitoring" still counts as automated.'
          },
          options: [
            { text: 'No - all outputs reviewed', score: 0, description: 'Human approval required for every output' },
            { text: 'Yes - automated internal use', score: 3, description: 'Automated but stays internal' },
            { text: 'Yes, and shared externally', score: 5, description: 'Automated outputs go to customers/public' }
          ]
        }
      ]
    },
    {
      category: 'D. Prompt Security',
      description: 'User input is a primary attack vector for AI systems',
      items: [
        {
          id: 'free_text_prompts',
          question: 'Will users enter free text prompts?',
          guidance: {
            title: 'Why this matters',
            content: 'Free text input opens your agent to prompt injection attacks, where malicious users try to override your instructions or extract sensitive information.',
            helpText: 'Structured inputs (dropdowns, buttons, forms) are safer than free text. "Partially" means some structured inputs but also allowing some free text.'
          },
          options: [
            { text: 'No - structured inputs only', score: 0, description: 'Predefined options, no free text' },
            { text: 'Partially - limited free text', score: 2, description: 'Some free text with constraints' },
            { text: 'Yes - fully open prompts', score: 4, description: 'Users can type anything' }
          ]
        },
        {
          id: 'prompt_exposure',
          question: 'Could prompts expose internal data or credentials?',
          guidance: {
            title: 'Why this matters',
            content: 'If users can craft prompts that reveal your system prompts, internal data, or credentials, attackers can exploit this to extract sensitive information or manipulate the system.',
            helpText: 'Consider: Can users ask "what are your instructions?" or "ignore previous instructions"? Can they query for data they shouldn\'t access?'
          },
          options: [
            { text: 'No - fully isolated', score: 0, description: 'No risk of data exposure via prompts' },
            { text: 'Possibly - some risk', score: 3, description: 'Theoretical vulnerability exists' },
            { text: 'Likely - high exposure risk', score: 5, description: 'Clear pathways for data extraction' }
          ]
        }
      ]
    },
    {
      category: 'E. External Integrations',
      description: 'Third-party integrations introduce additional security considerations',
      items: [
        {
          id: 'external_services',
          question: 'Are there integrations with non-AWS services?',
          guidance: {
            title: 'Why this matters',
            content: 'External services may have different security standards, can be compromised independently, and create data residency concerns. Each integration is a potential vulnerability.',
            helpText: 'Internal APIs are those managed by AWS. Slack, Google Sheets, email systems, etc. are external even if we use them internally.'
          },
          options: [
            { text: 'None - AWS services only', score: 0, description: 'Fully within AWS ecosystem' },
            { text: 'Internal APIs only', score: 2, description: 'Other AWS internal services' },
            { text: 'Third-party services', score: 4, description: 'Slack, Sheets, Email, etc.' }
          ]
        },
        {
          id: 'external_data',
          question: 'Does your idea send or store data externally?',
          guidance: {
            title: 'Why this matters',
            content: 'Data leaving AWS infrastructure raises compliance, sovereignty, and control issues. You lose visibility into how that data is handled, stored, or potentially shared.',
            helpText: 'This includes temporary storage, logs, or caches in external systems. Even "occasionally" requires strict controls.'
          },
          options: [
            { text: 'No - all data stays internal', score: 0, description: 'Data never leaves AWS' },
            { text: 'Occasionally - limited external storage', score: 2, description: 'Some data sent externally' },
            { text: 'Yes - regular external data flow', score: 5, description: 'Primary data storage external' }
          ]
        }
      ]
    },
    {
      category: 'F. Business Impact',
      description: 'The potential damage from failures determines required safeguards',
      items: [
        {
          id: 'automation_level',
          question: 'How automated is the workflow?',
          guidance: {
            title: 'Why this matters',
            content: 'Full automation means errors can propagate quickly and at scale before anyone notices. Manual checkpoints provide opportunities to catch and correct issues.',
            helpText: 'Manual review means a human must take action at each step. Semi-automated might auto-process but flag anomalies for review.'
          },
          options: [
            { text: 'Manual review at each step', score: 0, description: 'Human approval required throughout' },
            { text: 'Semi-automated with checkpoints', score: 2, description: 'Some automatic steps, key reviews manual' },
            { text: 'Fully automated end-to-end', score: 4, description: 'No human intervention required' }
          ]
        },
        {
          id: 'impact_scope',
          question: 'What is the potential impact if something goes wrong?',
          guidance: {
            title: 'Why this matters',
            content: 'Impact scope determines the urgency of security measures and the level of testing required. Customer-facing failures can cause immediate reputational and financial damage.',
            helpText: 'Consider worst-case scenarios: wrong information sent to customers, data leaks, service disruptions. What\'s the blast radius?'
          },
          options: [
            { text: 'Low - team-level only', score: 1, description: 'Affects only immediate team productivity' },
            { text: 'Medium - organization-level', score: 3, description: 'Could disrupt multiple teams/departments' },
            { text: 'High - customer-facing', score: 5, description: 'Direct impact on customers or public' }
          ]
        }
      ]
    },
    {
      category: 'G. Governance & Logging',
      description: 'Proper logging and compliance enable accountability and incident response',
      items: [
        {
          id: 'logging',
          question: 'Will usage be logged and auditable?',
          guidance: {
            title: 'Why this matters',
            content: 'Comprehensive logging is essential for security investigations, compliance audits, and understanding system behavior. Without logs, you can\'t detect or investigate security incidents.',
            helpText: 'Comprehensive means logging all inputs, outputs, user actions, and system decisions with timestamps. Partial means some logging but gaps exist.'
          },
          options: [
            { text: 'Yes, comprehensive logging', score: 0, description: 'Full audit trail of all actions' },
            { text: 'Partial logging', score: 2, description: 'Some events logged, not complete' },
            { text: 'No/Minimal logging', score: 4, description: 'Little to no audit capability' }
          ]
        },
        {
          id: 'compliance',
          question: 'Have you reviewed compliance requirements?',
          guidance: {
            title: 'Why this matters',
            content: 'Compliance requirements aren\'t optional. Violations can result in legal penalties, failed audits, and project shutdowns. Early review prevents costly redesigns.',
            helpText: 'This includes GDPR, data residency, industry regulations, and internal AWS policies. "Fully documented" means written compliance analysis exists.'
          },
          options: [
            { text: 'Yes, fully documented', score: 0, description: 'Complete compliance review done' },
            { text: 'Partially - aware of requirements', score: 2, description: 'Know what applies, not fully documented' },
            { text: 'Not yet - to be determined', score: 3, description: 'Compliance review pending' }
          ]
        }
      ]
    },
    {
      category: 'H. Monitoring & Review',
      description: 'Ongoing monitoring ensures your agent continues to behave correctly',
      items: [
        {
          id: 'output_monitoring',
          question: 'Will outputs be continuously monitored?',
          guidance: {
            title: 'Why this matters',
            content: 'AI behavior can drift over time or in response to new inputs. Continuous monitoring catches quality degradation, security issues, or unexpected behavior before they cause damage.',
            helpText: 'Automated monitoring means real-time alerts on anomalies. Manual spot checks are periodic human reviews. No monitoring means issues are only discovered when reported.'
          },
          options: [
            { text: 'Yes, automated monitoring', score: 0, description: 'Real-time output quality checks' },
            { text: 'Manual spot checks', score: 2, description: 'Periodic human review of outputs' },
            { text: 'No monitoring', score: 4, description: 'Reactive only, no proactive checks' }
          ]
        },
        {
          id: 'incident_response',
          question: 'Is there an incident response plan?',
          guidance: {
            title: 'Why this matters',
            content: 'When (not if) something goes wrong, a documented response plan ensures fast, coordinated action to minimize damage. Without a plan, incidents escalate while teams scramble to coordinate.',
            helpText: 'A documented plan includes: who to contact, how to shut down the agent, how to assess damage, communication protocols, and recovery steps.'
          },
          options: [
            { text: 'Yes, documented plan', score: 0, description: 'Written IR procedures exist' },
            { text: 'Informal plan', score: 2, description: 'Team knows what to do, not written' },
            { text: 'No plan', score: 3, description: 'Would need to figure out in crisis' }
          ]
        }
      ]
    }
  ];

  const handlePreFlightComplete = (results) => {
    setPreFlightResults(results);
    setCurrentStep(1);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleAnswerChange = (questionId, value) => {
    setAnswers(prev => ({ ...prev, [questionId]: value }));
  };

  const toggleGuidanceExpansion = (questionId) => {
    setExpandedGuidance(prev => ({
      ...prev,
      [questionId]: !prev[questionId]
    }));
  };

  const calculateProgress = () => {
    const totalQuestions = questions.reduce((acc, cat) => acc + cat.items.length, 0);
    const answeredQuestions = Object.keys(answers).length;
    return Math.round((answeredQuestions / totalQuestions) * 100);
  };

  const calculateCategoryScores = () => {
    const categoryScores = questions.map(category => {
      let total = 0;
      let maxPossible = 0;
      category.items.forEach(item => {
        const answer = answers[item.id];
        if (answer !== undefined) {
          total += answer;
        }
        maxPossible += Math.max(...item.options.map(opt => opt.score));
      });
      return {
        name: category.category,
        score: total,
        maxPossible,
        percentage: maxPossible > 0 ? Math.round((total / maxPossible) * 100) : 0
      };
    });
    return categoryScores;
  };

  const getHighRiskQuestions = () => {
    const highRiskItems = [];
    questions.forEach(category => {
      category.items.forEach(item => {
        const answer = answers[item.id];
        if (answer !== undefined && answer >= 4) {
          const selectedOption = item.options.find(opt => opt.score === answer);
          highRiskItems.push({
            category: category.category,
            question: item.question,
            answer: selectedOption?.text,
            score: answer
          });
        }
      });
    });
    return highRiskItems;
  };

  const calculateRiskScore = () => {
    let total = 0;
    questions.forEach(category => {
      category.items.forEach(item => {
        const answer = answers[item.id];
        if (answer !== undefined) {
          total += answer;
        }
      });
    });
    
    const normalized = total;
    setRiskScore(total);
    setNormalizedScore(normalized);
    
    // Risk zones for concept (40-point scale)
    if (normalized <= 15) {
      setRiskZone('green');
    } else if (normalized <= 28) {
      setRiskZone('amber');
    } else {
      setRiskZone('red');
    }
    
    setCurrentStep(3);
  };

  const getRiskZoneInfo = () => {
    switch (riskZone) {
      case 'green':
        return {
          title: 'Green Zone - Ready to Build',
          description: 'Your project has low security risk. You can proceed with development.',
          icon: <CheckCircle2 className="h-16 w-16 text-green-600" />,
          color: 'green',
          bgColor: 'bg-green-50',
          borderColor: 'border-green-500',
          textColor: 'text-green-700'
        };
      case 'amber':
        return {
          title: 'Amber Zone - Design with Care',
          description: 'Your project has moderate risk. Review security controls and implement additional safeguards.',
          icon: <AlertTriangle className="h-16 w-16 text-yellow-600" />,
          color: 'yellow',
          bgColor: 'bg-yellow-50',
          borderColor: 'border-yellow-500',
          textColor: 'text-yellow-700'
        };
      case 'red':
        return {
          title: 'Red Zone - Needs Rework',
          description: 'Your project has high security risk. Consider redesigning or implementing comprehensive security measures.',
          icon: <XCircle className="h-16 w-16 text-red-600" />,
          color: 'red',
          bgColor: 'bg-red-50',
          borderColor: 'border-red-500',
          textColor: 'text-red-700'
        };
      default:
        return null;
    }
  };

  const getRecommendations = () => {
    if (riskZone === 'green') {
      return {
        security: [
          'Implement comprehensive logging from day one',
          'Set up automated monitoring for output quality',
          'Document your data handling procedures',
          'Establish clear usage guidelines for your team',
          'Plan for regular security reviews as usage grows'
        ],
        prompts: [
          'Use specific, well-scoped prompts with clear objectives',
          'Include output format specifications in your prompts',
          'Test prompts with edge cases and unusual inputs',
          'Document your prompt templates for consistency',
          'Establish a prompt review process for quality'
        ],
        deployment: [
          'Start with limited user group for initial testing',
          'Gather feedback early and iterate quickly',
          'Plan for gradual rollout with monitoring',
          'Create user documentation and training materials',
          'Set up feedback channels for continuous improvement'
        ]
      };
    } else if (riskZone === 'amber') {
      return {
        security: [
          '⚠️ Implement input validation and sanitization',
          '⚠️ Add human review checkpoints for sensitive outputs',
          '⚠️ Conduct security testing before wider release',
          'Consider data masking for sensitive information',
          'Implement rate limiting and abuse prevention',
          'Set up comprehensive audit logging',
          'Create incident response procedures',
          'Establish escalation paths for security concerns'
        ],
        prompts: [
          'Use system prompts to enforce strict boundaries',
          'Implement prompt injection detection mechanisms',
          'Test extensively with adversarial inputs',
          'Document prohibited use cases explicitly',
          'Create prompt templates that limit risk exposure',
          'Implement output filtering and validation',
          'Monitor for prompt patterns that indicate misuse'
        ],
        deployment: [
          '⚠️ Require SWAT consultation before production',
          'Implement staged rollout with monitoring at each phase',
          'Create detailed incident response plan',
          'Set up real-time alerting for anomalies',
          'Conduct security training for all team members',
          'Establish regular security review cadence',
          'Document all security controls and procedures'
        ]
      };
    } else {
      return {
        security: [
          '🛑 MANDATORY: Consult SWAT team before proceeding',
          '🛑 Complete full security review and threat modeling',
          '🛑 Implement multi-layer security controls',
          '🛑 Consider redesigning to reduce risk scope',
          'Evaluate if use case justifies the risk level',
          'Implement comprehensive audit logging with retention',
          'Set up real-time security monitoring with 24/7 coverage',
          'Conduct penetration testing before any deployment',
          'Establish security incident response team',
          'Implement kill-switch capability for emergency shutdown',
          'Require security certification before production'
        ],
        prompts: [
          '🛑 Restrict prompt capabilities significantly',
          'Implement strict content filtering on all outputs',
          'Use pre-approved prompt templates only',
          'Conduct red team testing for prompt injection',
          'Implement multiple layers of prompt validation',
          'Monitor all prompt interactions in real-time',
          'Establish prompt review board for changes',
          'Document all prompt security controls',
          'Test for data exfiltration vulnerabilities'
        ],
        deployment: [
          '🛑 Do not deploy without security certification',
          '🛑 Require security training for all team members',
          'Implement phased rollout with security gates',
          'Establish 24/7 monitoring and on-call rotation',
          'Create comprehensive incident response playbook',
          'Conduct regular security drills and exercises',
          'Set up automated security scanning and alerts',
          'Require security approval for all changes',
          'Plan for independent security audit'
        ]
      };
    }
  };

  const promptGuidance = {
    title: 'Writing Secure & Effective Prompts',
    sections: [
      {
        title: 'Prompt Structure Best Practices',
        icon: '📝',
        tips: [
          'Be specific about desired output format (JSON, markdown, etc.)',
          'Include explicit constraints and boundaries',
          'Specify what NOT to do (negative examples)',
          'Use role-based prompting for consistency',
          'Break complex tasks into smaller, manageable steps'
        ]
      },
      {
        title: 'Security Considerations',
        icon: '🔒',
        tips: [
          'Never include credentials or secrets in prompts',
          'Sanitize user inputs before passing to AI',
          'Use system prompts to enforce security policies',
          'Test for prompt injection vulnerabilities',
          'Implement output validation before use',
          'Log all prompts for security audit'
        ]
      },
      {
        title: 'Data Handling in Prompts',
        icon: '🗄️',
        tips: [
          'Clearly specify data retention requirements',
          'Mask sensitive data when possible',
          'Specify what data should NOT be included in responses',
          'Document data lineage and transformations',
          'Implement data classification checks',
          'Use data anonymization where appropriate'
        ]
      },
      {
        title: 'Testing & Validation',
        icon: '🧪',
        tips: [
          'Test with edge cases and boundary conditions',
          'Validate outputs against expected formats',
          'Test for hallucinations and incorrect information',
          'Use adversarial testing to find vulnerabilities',
          'Monitor output quality over time',
          'Establish quality metrics and thresholds'
        ]
      }
    ]
  };

  const handleDownloadPDF = async () => {
    setIsGeneratingPDF(true);
    setPdfError(null);
    setPdfSuccess(false);

    try {
      console.log('Starting PDF generation...');
      
      const reportData = {
        type: 'concept',
        formData: {
          ...formData,
          platform: formData.platform === 'other' ? formData.customPlatform : 
                   platforms.find(p => p.value === formData.platform)?.label || formData.platform
        },
        answers,
        questions,
        riskScore,
        normalizedScore,
        riskZone,
        preFlightResults,
        categoryScores: calculateCategoryScores(),
        highRiskQuestions: getHighRiskQuestions(),
        recommendations: getRecommendations()
      };

      console.log('Report data:', reportData);

      const result = await generateSaferAIPDF(reportData);
      
      console.log('PDF generation result:', result);

      if (result.success) {
        setPdfSuccess(true);
        setTimeout(() => setPdfSuccess(false), 5000);
      } else {
        setPdfError(result.error || 'Failed to generate PDF');
      }
    } catch (error) {
      console.error('PDF generation error:', error);
      setPdfError(error.message || 'An unexpected error occurred while generating the PDF');
    } finally {
      setIsGeneratingPDF(false);
    }
  };

  const handleSWATSubmission = () => {
    window.open('https://forms.asana.com/?k=o8G85IpJ3BbhhKI4oo_IGw&d=8442528107068', '_blank');
  };

  // Footer Component
  const Footer = () => (
    <footer className="mt-12 py-6 border-t border-gray-200 bg-white">
      <div className="max-w-7xl mx-auto px-6 text-center">
        <p className="text-gray-600 text-sm">
          © GNSS - Security Workspace and Access Team
        </p>
      </div>
    </footer>
  );

  // Step 0: Pre-Flight Check
  if (currentStep === 0) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col">
        <div className="flex-grow py-12 px-6">
          <div className="max-w-7xl mx-auto">
            <ProgressBar currentStep={0} totalSteps={3} />
            <div className="text-center mb-8">
              <h1 className="text-4xl font-bold text-gray-900 mb-3">Concept Review - Pre-Flight Check</h1>
              <p className="text-xl text-gray-600">
                Answer 5 critical questions to identify potential data handling restrictions and permissions issues
              </p>
            </div>
            <EnhancedPreFlightCheck onComplete={handlePreFlightComplete} />
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  // Step 1: Project Details
  if (currentStep === 1) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col">
        <div className="flex-grow py-12 px-6">
          <div className="max-w-4xl mx-auto">
            <ProgressBar currentStep={1} totalSteps={3} />
            <div className="mb-8">
              <h1 className="text-4xl font-bold text-gray-900 mb-3">Concept Review - Project Details</h1>
              <p className="text-xl text-gray-600">Step 1 of 2: Provide basic information about your AI agent project</p>
            </div>

            {preFlightResults && preFlightResults.warnings.length > 0 && (
              <Alert className="mb-6 border-[#FF9900] bg-orange-50">
                <AlertTriangle className="h-5 w-5 text-[#FF9900]" />
                <AlertDescription className="text-gray-800 ml-2">
                  <strong>Pre-Flight Warnings Detected:</strong> {preFlightResults.warnings.length} critical issue(s) identified. 
                  These will be included in your final report and require attention.
                </AlertDescription>
              </Alert>
            )}

            <Card className="border-2 border-[#232F3E] mb-6 shadow-lg">
              <CardHeader className="bg-gradient-to-r from-[#232F3E] to-[#37475A] text-white">
                <CardTitle className="text-2xl">Project Information</CardTitle>
                <CardDescription className="text-gray-200">
                  Fill in the details about your AI agent concept
                </CardDescription>
              </CardHeader>
              <CardContent className="p-6 space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="projectName">Project Name *</Label>
                    <Input
                      id="projectName"
                      name="projectName"
                      value={formData.projectName}
                      onChange={handleInputChange}
                      placeholder="e.g., Customer Support AI Assistant"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="developer">Developer Name *</Label>
                    <Input
                      id="developer"
                      name="developer"
                      value={formData.developer}
                      onChange={handleInputChange}
                      placeholder="Your name"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="org">Organization/Team *</Label>
                    <Input
                      id="org"
                      name="org"
                      value={formData.org}
                      onChange={handleInputChange}
                      placeholder="e.g., RISC, SEPO"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="loginId">Login ID</Label>
                    <Input
                      id="loginId"
                      name="loginId"
                      value={formData.loginId}
                      onChange={handleInputChange}
                      placeholder="Your Amazon login ID"
                    />
                  </div>
                  <div>
                    <Label htmlFor="platform">Platform *</Label>
                    <Select value={formData.platform} onValueChange={(value) => handleSelectChange('platform', value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a platform" />
                      </SelectTrigger>
                      <SelectContent>
                        {platforms.map((platform) => (
                          <SelectItem key={platform.value} value={platform.value}>
                            <div className="flex flex-col">
                              <span className="font-semibold">{platform.label}</span>
                              <span className="text-xs text-gray-500">{platform.description}</span>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  {formData.platform === 'other' && (
                    <div>
                      <Label htmlFor="customPlatform">Custom Platform Name *</Label>
                      <Input
                        id="customPlatform"
                        name="customPlatform"
                        value={formData.customPlatform}
                        onChange={handleInputChange}
                        placeholder="Enter platform name"
                        required
                      />
                    </div>
                  )}
                  <div>
                    <Label htmlFor="devType">Development Type *</Label>
                    <Select value={formData.devType} onValueChange={(value) => handleSelectChange('devType', value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select development type" />
                      </SelectTrigger>
                      <SelectContent>
                        {devTypes.map((type) => (
                          <SelectItem key={type.value} value={type.value}>
                            {type.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <Label htmlFor="goal">Project Goal/Description *</Label>
                  <Textarea
                    id="goal"
                    name="goal"
                    value={formData.goal}
                    onChange={handleInputChange}
                    placeholder="Describe what your AI agent will do and what problem it solves"
                    rows={4}
                    required
                  />
                  <p className="text-xs text-gray-500 mt-1">{formData.goal.length} characters</p>
                </div>

                <DataClassificationSelector
                  value={formData.dataCategory}
                  onChange={(value) => handleSelectChange('dataCategory', value)}
                />

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="teamSize">Team Size</Label>
                    <Input
                      id="teamSize"
                      name="teamSize"
                      value={formData.teamSize}
                      onChange={handleInputChange}
                      placeholder="Number of developers"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="intendedOutput">Intended Output</Label>
                  <Textarea
                    id="intendedOutput"
                    name="intendedOutput"
                    value={formData.intendedOutput}
                    onChange={handleInputChange}
                    placeholder="What will the AI agent produce or generate?"
                    rows={3}
                  />
                </div>

                <div>
                  <Label htmlFor="expectedIntegrations">Expected Integrations</Label>
                  <Textarea
                    id="expectedIntegrations"
                    name="expectedIntegrations"
                    value={formData.expectedIntegrations}
                    onChange={handleInputChange}
                    placeholder="List any external services or APIs you plan to integrate"
                    rows={3}
                  />
                </div>

                <div>
                  <Label htmlFor="otherDetails">Additional Details</Label>
                  <Textarea
                    id="otherDetails"
                    name="otherDetails"
                    value={formData.otherDetails}
                    onChange={handleInputChange}
                    placeholder="Any other relevant information"
                    rows={3}
                  />
                </div>

                <div className="flex justify-between pt-6 border-t">
                  <Button
                    variant="outline"
                    onClick={() => setCurrentStep(0)}
                    className="border-gray-300"
                  >
                    <ArrowLeft className="mr-2 h-4 w-4" />
                    Back to Pre-Flight
                  </Button>
                  <Button
                    onClick={() => setCurrentStep(2)}
                    disabled={
                      !formData.projectName || 
                      !formData.developer || 
                      !formData.org || 
                      !formData.platform || 
                      (formData.platform === 'other' && !formData.customPlatform) ||
                      !formData.devType || 
                      !formData.goal || 
                      !formData.dataCategory
                    }
                    className="bg-[#FF9900] hover:bg-[#EC7211] text-white disabled:bg-gray-300"
                  >
                    Continue to Risk Assessment
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>

            <ToolClassificationReference />
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  // Step 2: Risk Assessment
  if (currentStep === 2) {
    const allAnswered = questions.every(category => 
      category.items.every(item => answers[item.id] !== undefined)
    );
    const progress = calculateProgress();

    return (
      <div className="min-h-screen bg-gray-50 flex flex-col">
        <div className="flex-grow py-12 px-6">
          <div className="max-w-5xl mx-auto">
            <ProgressBar currentStep={2} totalSteps={3} />
            <div className="mb-8">
              <h1 className="text-4xl font-bold text-gray-900 mb-3">Concept Review - Risk Assessment</h1>
              <p className="text-xl text-gray-600">Step 2 of 2: Answer 16 questions across 8 security categories</p>
            </div>

            {/* Progress Bar */}
            <Card className="border-2 border-[#FF9900] mb-6 shadow-lg">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-semibold text-gray-700">Assessment Progress</span>
                  <span className="text-sm font-semibold text-[#FF9900]">{progress}% Complete</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-3">
                  <div
                    className="bg-[#FF9900] h-3 rounded-full transition-all duration-300"
                    style={{ width: `${progress}%` }}
                  />
                </div>
                <p className="text-xs text-gray-600 mt-2">
                  {Object.keys(answers).length} of {questions.reduce((acc, cat) => acc + cat.items.length, 0)} questions answered
                </p>
              </CardContent>
            </Card>

            {/* Guidance Toggle */}
            <Card className="border-2 border-blue-200 bg-blue-50 mb-6">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <HelpCircle className="h-5 w-5 text-blue-600" />
                    <span className="font-semibold text-blue-900">Question Guidance</span>
                  </div>
                  <button
                    onClick={() => setShowGuidance(!showGuidance)}
                    className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                      showGuidance
                        ? 'bg-blue-600 text-white'
                        : 'bg-white text-blue-600 border border-blue-300'
                    }`}
                  >
                    {showGuidance ? 'Hide Guidance' : 'Show Guidance'}
                  </button>
                </div>
                <p className="text-sm text-blue-700 mt-2">
                  {showGuidance 
                    ? 'Guidance is shown for each question to help you make informed choices'
                    : 'Enable guidance to see detailed explanations for each question'}
                </p>
              </CardContent>
            </Card>

            <Card className="border-2 border-[#232F3E] shadow-lg">
              <CardHeader className="bg-gradient-to-r from-[#232F3E] to-[#37475A] text-white">
                <CardTitle className="text-2xl">Security Risk Questions</CardTitle>
                <CardDescription className="text-gray-200">
                  Select the option that best describes your project concept (Max Score: 40 points)
                </CardDescription>
              </CardHeader>
              <CardContent className="p-6 space-y-8">
                {questions.map((category, catIndex) => (
                  <div key={catIndex} className="space-y-6">
                    <div className="border-l-4 border-[#FF9900] pl-4 bg-orange-50 py-3 rounded-r">
                      <h3 className="text-xl font-bold text-gray-900">
                        {category.category}
                      </h3>
                      <p className="text-sm text-gray-600 mt-1">{category.description}</p>
                    </div>
                    
                    {category.items.map((item) => {
                      const isAnswered = answers[item.id] !== undefined;
                      const isExpanded = expandedGuidance[item.id];
                      
                      return (
                        <div 
                          key={item.id} 
                          className={`bg-white border-2 rounded-lg p-5 shadow-sm transition-all ${
                            isAnswered ? 'border-green-300 bg-green-50' : 'border-gray-200'
                          }`}
                        >
                          <div className="flex items-start justify-between gap-4 mb-4">
                            <Label className="text-base font-semibold text-gray-900 flex-1">
                              {item.question}
                              {isAnswered && (
                                <CheckCircle2 className="inline-block ml-2 h-5 w-5 text-green-600" />
                              )}
                            </Label>
                            {showGuidance && (
                              <button
                                onClick={() => toggleGuidanceExpansion(item.id)}
                                className="flex-shrink-0 p-2 hover:bg-gray-100 rounded-full transition-colors"
                                title="Show guidance"
                              >
                                <HelpCircle className={`h-5 w-5 ${isExpanded ? 'text-[#FF9900]' : 'text-gray-400'}`} />
                              </button>
                            )}
                          </div>

                          {showGuidance && isExpanded && (
                            <Alert className="mb-4 border-blue-200 bg-blue-50">
                              <Info className="h-5 w-5 text-blue-600" />
                              <AlertDescription className="ml-2">
                                <p className="font-semibold text-blue-900 mb-2">{item.guidance.title}</p>
                                <p className="text-sm text-gray-700 mb-2">{item.guidance.content}</p>
                                <p className="text-sm text-blue-800 italic">💡 {item.guidance.helpText}</p>
                              </AlertDescription>
                            </Alert>
                          )}

                          <RadioGroup
                            value={answers[item.id]?.toString()}
                            onValueChange={(value) => handleAnswerChange(item.id, parseInt(value))}
                          >
                            <div className="space-y-3">
                              {item.options.map((option, optIndex) => (
                                <div 
                                  key={optIndex} 
                                  className={`flex items-start space-x-3 p-4 rounded-lg border-2 transition-all ${
                                    answers[item.id] === option.score
                                      ? 'border-[#FF9900] bg-orange-50 shadow-sm'
                                      : 'border-gray-200 hover:border-[#FF9900] hover:bg-gray-50'
                                  }`}
                                >
                                  <RadioGroupItem 
                                    value={option.score.toString()} 
                                    id={`${item.id}-${optIndex}`}
                                    className="mt-1"
                                  />
                                  <div className="flex-1">
                                    <Label 
                                      htmlFor={`${item.id}-${optIndex}`} 
                                      className="cursor-pointer font-medium text-gray-900 block"
                                    >
                                      {option.text}
                                    </Label>
                                    {option.description && (
                                      <p className="text-xs text-gray-600 mt-1">{option.description}</p>
                                    )}
                                    <span className="text-xs text-gray-500 font-semibold">{option.score} points</span>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </RadioGroup>
                        </div>
                      );
                    })}
                  </div>
                ))}

                <div className="flex justify-between pt-6 border-t">
                  <Button
                    variant="outline"
                    onClick={() => setCurrentStep(1)}
                    className="border-gray-300"
                  >
                    <ArrowLeft className="mr-2 h-4 w-4" />
                    Back to Project Details
                  </Button>
                  <Button
                    onClick={calculateRiskScore}
                    disabled={!allAnswered}
                    className="bg-[#FF9900] hover:bg-[#EC7211] text-white disabled:bg-gray-300 disabled:cursor-not-allowed"
                  >
                    {allAnswered ? (
                      <>
                        Calculate Risk Score
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </>
                    ) : (
                      <>
                        Answer All Questions ({Object.keys(answers).length}/{questions.reduce((acc, cat) => acc + cat.items.length, 0)})
                      </>
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  // Step 3: Results
  if (currentStep === 3) {
    const zoneInfo = getRiskZoneInfo();
    const categoryScores = calculateCategoryScores();
    const highRiskQuestions = getHighRiskQuestions();
    const recommendations = getRecommendations();

    return (
      <div className="min-h-screen bg-gray-50 flex flex-col">
        <div className="flex-grow py-12 px-6">
          <div className="max-w-6xl mx-auto">
            <ProgressBar currentStep={3} totalSteps={3} />
            <div className="mb-8 text-center">
              <h1 className="text-4xl font-bold text-gray-900 mb-3">Concept Review - Assessment Results</h1>
              <p className="text-xl text-gray-600">Your security risk assessment is complete</p>
            </div>

            {/* Risk Zone Card */}
            <Card className={`border-4 ${zoneInfo.borderColor} ${zoneInfo.bgColor} mb-6 shadow-lg`}>
              <CardContent className="p-8">
                <div className="flex items-center gap-6 mb-6">
                  {zoneInfo.icon}
                  <div className="flex-1">
                    <h2 className="text-3xl font-bold text-gray-900 mb-2">{zoneInfo.title}</h2>
                    <p className="text-lg text-gray-700">{zoneInfo.description}</p>
                  </div>
                </div>
                <div className="grid md:grid-cols-3 gap-4 bg-white p-6 rounded-lg shadow-sm">
                  <div className="text-center">
                    <p className="text-sm text-gray-600 mb-1">Risk Score</p>
                    <p className="text-4xl font-bold text-gray-900">{normalizedScore}</p>
                    <p className="text-xs text-gray-500">out of 40</p>
                  </div>
                  <div className="text-center">
                    <p className="text-sm text-gray-600 mb-1">Risk Level</p>
                    <p className={`text-4xl font-bold ${zoneInfo.textColor}`}>
                      {zoneInfo.color === 'green' ? 'Low' : zoneInfo.color === 'yellow' ? 'Medium' : 'High'}
                    </p>
                    <p className="text-xs text-gray-500">{zoneInfo.color.toUpperCase()} zone</p>
                  </div>
                  <div className="text-center">
                    <p className="text-sm text-gray-600 mb-1">High Risk Items</p>
                    <p className="text-4xl font-bold text-gray-900">{highRiskQuestions.length}</p>
                    <p className="text-xs text-gray-500">requiring attention</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Deployment Readiness */}
            <Card className={`border-2 mb-6 shadow-lg ${
              riskZone === 'green' ? 'border-green-500 bg-green-50' :
              riskZone === 'amber' ? 'border-yellow-500 bg-yellow-50' :
              'border-red-500 bg-red-50'
            }`}>
              <CardHeader>
                <CardTitle className={`text-2xl ${
                  riskZone === 'green' ? 'text-green-800' :
                  riskZone === 'amber' ? 'text-yellow-800' :
                  'text-red-800'
                }`}>
                  Development Readiness Assessment
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="bg-white p-4 rounded-lg border-2 border-gray-200">
                  {riskZone === 'green' && (
                    <>
                      <div className="flex items-center gap-3 mb-4">
                        <CheckCircle2 className="h-8 w-8 text-green-600" />
                        <div>
                          <p className="text-lg font-bold text-green-800">✓ Ready to Begin Development</p>
                          <p className="text-sm text-gray-700">Your concept meets security requirements to proceed</p>
                        </div>
                      </div>
                      <div className="space-y-2 text-sm text-gray-700">
                        <p>• Concept security review passed</p>
                        <p>• Risk level acceptable for development</p>
                        <p>• Recommended: Plan security controls during design</p>
                        <p>• Next: Begin implementation with security best practices</p>
                      </div>
                    </>
                  )}
                  {riskZone === 'amber' && (
                    <>
                      <div className="flex items-center gap-3 mb-4">
                        <AlertTriangle className="h-8 w-8 text-yellow-600" />
                        <div>
                          <p className="text-lg font-bold text-yellow-800">⚠️ Proceed with Caution</p>
                          <p className="text-sm text-gray-700">Address identified concerns during design phase</p>
                        </div>
                      </div>
                      <div className="space-y-2 text-sm text-gray-700">
                        <p>• {highRiskQuestions.length} moderate risk areas identified</p>
                        <p>• Design additional security controls</p>
                        <p>• Consider SWAT consultation for guidance</p>
                        <p>• Next: Create detailed security implementation plan</p>
                      </div>
                    </>
                  )}
                  {riskZone === 'red' && (
                    <>
                      <div className="flex items-center gap-3 mb-4">
                        <XCircle className="h-8 w-8 text-red-600" />
                        <div>
                          <p className="text-lg font-bold text-red-800">🛑 Concept Needs Revision</p>
                          <p className="text-sm text-gray-700">Redesign required before proceeding with development</p>
                        </div>
                      </div>
                      <div className="space-y-2 text-sm text-gray-700">
                        <p>• {highRiskQuestions.length} critical security concerns</p>
                        <p>• Mandatory SWAT consultation required</p>
                        <p>• Concept redesign strongly recommended</p>
                        <p>• Next: Schedule security architecture review</p>
                      </div>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Risk Breakdown by Category */}
            <Card className="border-2 border-[#232F3E] mb-6 shadow-lg">
              <CardHeader className="bg-gradient-to-r from-[#232F3E] to-[#37475A] text-white">
                <CardTitle className="text-2xl">Risk Breakdown by Category</CardTitle>
                <CardDescription className="text-gray-200">
                  See how your project scores across different security dimensions
                </CardDescription>
              </CardHeader>
              <CardContent className="p-6 space-y-4">
                {categoryScores.map((category, idx) => (
                  <div key={idx} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-gray-900">{category.name}</span>
                      <span className="text-sm text-gray-600">
                        {category.score} / {category.maxPossible} points ({category.percentage}%)
                      </span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-3">
                      <div
                        className={`h-3 rounded-full transition-all ${
                          category.percentage <= 40 ? 'bg-green-500' :
                          category.percentage <= 70 ? 'bg-yellow-500' :
                          'bg-red-500'
                        }`}
                        style={{ width: `${category.percentage}%` }}
                      />
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* High-Risk Areas */}
            {highRiskQuestions.length > 0 && (
              <Card className="border-2 border-red-500 bg-red-50 mb-6 shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-red-900">
                    <AlertTriangle className="h-6 w-6" />
                    High-Risk Areas Requiring Attention ({highRiskQuestions.length})
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-6 space-y-3">
                  {highRiskQuestions.map((item, idx) => (
                    <div key={idx} className="bg-white border-l-4 border-red-500 p-4 rounded shadow-sm">
                      <p className="text-sm font-semibold text-gray-600">{item.category}</p>
                      <p className="font-semibold text-gray-900 mt-1">{item.question}</p>
                      <p className="text-red-700 text-sm mt-1">
                        Your answer: <span className="font-medium">{item.answer}</span> (Risk score: {item.score})
                      </p>
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}

            {/* Pre-Flight Warnings */}
            {preFlightResults && preFlightResults.warnings.length > 0 && (
              <Card className="border-2 border-[#FF9900] mb-6 shadow-lg">
                <CardHeader className="bg-orange-50">
                  <CardTitle className="flex items-center gap-2 text-[#FF9900]">
                    <AlertTriangle className="h-6 w-6" />
                    Pre-Flight Warnings ({preFlightResults.warnings.length})
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="space-y-3">
                    {preFlightResults.warnings.map((warning, idx) => (
                      <div key={idx} className="bg-white border-l-4 border-[#FF9900] p-4 rounded shadow-sm">
                        <p className="font-semibold text-gray-900 mb-1">{warning.question}</p>
                        <p className="text-gray-700 text-sm">{warning.warning}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Recommendations */}
            <Card className="border-2 border-[#232F3E] mb-6 shadow-lg">
              <CardHeader className="bg-gradient-to-r from-[#232F3E] to-[#37475A] text-white">
                <CardTitle className="text-2xl">Tailored Recommendations</CardTitle>
                <CardDescription className="text-gray-200">
                  Security, prompt engineering, and deployment guidance for your risk level
                </CardDescription>
              </CardHeader>
              <CardContent className="p-6 space-y-6">
                {/* Security Recommendations */}
                <div>
                  <h3 className="text-xl font-bold text-gray-900 mb-3 flex items-center gap-2">
                    🔒 Security Controls
                  </h3>
                  <ul className="space-y-2">
                    {recommendations.security.map((rec, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-gray-700">
                        <span className="text-[#FF9900] font-bold mt-1">•</span>
                        <span>{rec}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Prompt Engineering */}
                <div className="border-t pt-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-3 flex items-center gap-2">
                    💬 Prompt Engineering
                  </h3>
                  <ul className="space-y-2">
                    {recommendations.prompts.map((rec, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-gray-700">
                        <span className="text-[#FF9900] font-bold mt-1">•</span>
                        <span>{rec}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Deployment */}
                <div className="border-t pt-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-3 flex items-center gap-2">
                    🚀 Deployment Strategy
                  </h3>
                  <ul className="space-y-2">
                    {recommendations.deployment.map((rec, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-gray-700">
                        <span className="text-[#FF9900] font-bold mt-1">•</span>
                        <span>{rec}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </CardContent>
            </Card>

            {/* Prompt Engineering Best Practices */}
            <Card className="border-2 border-blue-500 bg-blue-50 mb-6 shadow-lg">
              <CardHeader>
                <CardTitle className="text-2xl text-blue-900">{promptGuidance.title}</CardTitle>
                <CardDescription className="text-blue-700">
                  Essential guidance for creating secure and effective AI prompts
                </CardDescription>
              </CardHeader>
              <CardContent className="p-6 space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  {promptGuidance.sections.map((section, idx) => (
                    <div key={idx} className="bg-white p-5 rounded-lg border border-blue-200 shadow-sm">
                      <h4 className="text-lg font-bold text-gray-900 mb-3 flex items-center gap-2">
                        <span className="text-2xl">{section.icon}</span>
                        {section.title}
                      </h4>
                      <ul className="space-y-2">
                        {section.tips.map((tip, tipIdx) => (
                          <li key={tipIdx} className="flex items-start gap-2 text-sm text-gray-700">
                            <span className="text-blue-600 font-bold mt-1">✓</span>
                            <span>{tip}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Action Checklist */}
            <Card className="border-2 border-green-500 bg-green-50 mb-6 shadow-lg">
              <CardHeader>
                <CardTitle className="text-2xl text-green-900">Action Checklist</CardTitle>
                <CardDescription className="text-green-700">
                  Complete these steps before beginning development
                </CardDescription>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-3">
                  {[
                    'Download and review complete PDF report',
                    'Share assessment results with team and stakeholders',
                    riskZone !== 'green' ? 'Schedule SWAT consultation (required for amber/red zones)' : 'Consider SWAT consultation for complex scenarios',
                    'Document security controls and implementation plan',
                    'Set up monitoring and logging infrastructure',
                    'Create incident response plan and procedures',
                    'Conduct security training for team members',
                    'Plan phased rollout with security checkpoints',
                    'Establish regular security review cadence',
                    'Create user documentation and usage guidelines'
                  ].map((item, idx) => (
                    <div key={idx} className="flex items-start gap-3 bg-white p-3 rounded border border-green-200 shadow-sm hover:shadow-md transition-shadow">
                      <input 
                        type="checkbox" 
                        className="mt-1 h-5 w-5 text-green-600 rounded border-gray-300 focus:ring-green-500"
                      />
                      <label className="text-gray-700 cursor-pointer flex-1">{item}</label>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Summary Statistics */}
            <Card className="border-2 border-blue-300 bg-blue-50 mb-6 shadow-lg">
              <CardHeader>
                <CardTitle className="text-xl text-blue-900">Assessment Summary</CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="grid md:grid-cols-4 gap-4">
                  <div className="bg-white p-4 rounded-lg text-center shadow-sm">
                    <p className="text-sm text-gray-600 mb-1">Total Questions</p>
                    <p className="text-3xl font-bold text-blue-600">
                      {questions.reduce((acc, cat) => acc + cat.items.length, 0)}
                    </p>
                    <p className="text-xs text-gray-500">answered</p>
                  </div>
                  <div className="bg-white p-4 rounded-lg text-center shadow-sm">
                    <p className="text-sm text-gray-600 mb-1">Categories</p>
                    <p className="text-3xl font-bold text-purple-600">8</p>
                    <p className="text-xs text-gray-500">assessed</p>
                  </div>
                  <div className="bg-white p-4 rounded-lg text-center shadow-sm">
                    <p className="text-sm text-gray-600 mb-1">Pre-Flight Checks</p>
                    <p className="text-3xl font-bold text-amber-600">5</p>
                    <p className="text-xs text-gray-500">completed</p>
                  </div>
                  <div className="bg-white p-4 rounded-lg text-center shadow-sm">
                    <p className="text-sm text-gray-600 mb-1">Warnings</p>
                    <p className="text-3xl font-bold text-orange-600">
                      {(preFlightResults?.warnings?.length || 0) + highRiskQuestions.length}
                    </p>
                    <p className="text-xs text-gray-500">total</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Actions */}
            <Card className="border-2 border-[#232F3E] shadow-lg">
              <CardHeader className="bg-gradient-to-r from-[#232F3E] to-[#37475A] text-white">
                <CardTitle className="text-2xl">Next Steps</CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-4">
                {/* PDF Generation Status Messages */}
                {pdfSuccess && (
                  <Alert className="border-green-500 bg-green-50">
                    <CheckCircle2 className="h-5 w-5 text-green-600" />
                    <AlertDescription className="text-green-800 ml-2">
                      <strong>Success!</strong> PDF report has been downloaded successfully.
                    </AlertDescription>
                  </Alert>
                )}

                {pdfError && (
                  <Alert className="border-red-500 bg-red-50">
                    <XCircle className="h-5 w-5 text-red-600" />
                    <AlertDescription className="text-red-800 ml-2">
                      <strong>Error:</strong> {pdfError}
                      <br />
                      <span className="text-sm">Please check the browser console for more details.</span>
                    </AlertDescription>
                  </Alert>
                )}

                <div className="grid md:grid-cols-2 gap-4">
                  <Button
                    onClick={handleDownloadPDF}
                    disabled={isGeneratingPDF}
                    className="bg-[#FF9900] hover:bg-[#EC7211] text-white h-auto py-4 disabled:bg-gray-400 disabled:cursor-not-allowed shadow-lg hover:shadow-xl transition-all"
                  >
                    {isGeneratingPDF ? (
                      <>
                        <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                        <div className="text-left">
                          <div className="font-semibold">Generating PDF...</div>
                          <div className="text-xs opacity-90">Please wait</div>
                        </div>
                      </>
                    ) : (
                      <>
                        <Download className="mr-2 h-5 w-5" />
                        <div className="text-left">
                          <div className="font-semibold">Download PDF Report</div>
                          <div className="text-xs opacity-90">Complete assessment with recommendations</div>
                        </div>
                      </>
                    )}
                  </Button>
                  <Button
  onClick={() => window.open('https://form.asana.com/?k=o8G85lpJ3BbhhKl4oo_lGw&d=8442528107068', '_blank')}
  variant="outline"
  className="border-2 border-[#232F3E] text-[#232F3E] hover:bg-[#232F3E] hover:text-white h-auto py-4"
>
  <ExternalLink className="mr-2 h-5 w-5" />
  <div className="text-left">
    <div className="font-semibold">Submit to SWAT Team</div>
    <div className="text-xs opacity-90">Get expert security review</div>
  </div>
</Button>
                </div>

                {/* Resource Links */}
                <div className="border-t pt-6">
  <h4 className="font-semibold text-gray-900 mb-3">Additional Resources</h4>
  <div className="grid md:grid-cols-2 gap-3">
    <a 
      href="https://w.amazon.com/bin/view/Main/Search?q=Security+Best+Practices" 
      target="_blank"
      rel="noopener noreferrer"
      className="flex items-center gap-2 text-blue-600 hover:text-blue-800 text-sm"
    >
      <ExternalLink className="h-4 w-4" />
      Security Best Practices Documentation
    </a>
    <a 
      href="https://w.amazon.com/bin/view/Users/behrepav/Quip/PROMPT_ENGINEERING_GUIDE/" 
      target="_blank"
      rel="noopener noreferrer"
      className="flex items-center gap-2 text-blue-600 hover:text-blue-800 text-sm"
    >
      <ExternalLink className="h-4 w-4" />
      Prompt Engineering Guide
    </a>
    <a 
      href="https://w.amazon.com/index.php/Infosec/Data_Classification" 
      target="_blank"
      rel="noopener noreferrer"
      className="flex items-center gap-2 text-blue-600 hover:text-blue-800 text-sm"
    >
      <ExternalLink className="h-4 w-4" />
      Data Classification Guidelines
    </a>
    <a 
      href="https://w.amazon.com/bin/view/InfoSec/Application_Security/AppSTAR/Appsec_AI/When_is_a_GenAI_ASR_Profile_required_/" 
      target="_blank"
      rel="noopener noreferrer"
      className="flex items-center gap-2 text-blue-600 hover:text-blue-800 text-sm"
    >
      <ExternalLink className="h-4 w-4" />
      ASR Security Requirements
    </a>
    <a 
      href="https://owasp.org/www-project-top-10-for-large-language-model-applications/" 
      target="_blank"
      rel="noopener noreferrer"
      className="flex items-center gap-2 text-blue-600 hover:text-blue-800 text-sm"
    >
      <ExternalLink className="h-4 w-4" />
      OWASP LLM Top 10
    </a>
    <a 
      href="https://www.tensorflow.org/responsible_ai/privacy/guide" 
      target="_blank"
      rel="noopener noreferrer"
      className="flex items-center gap-2 text-blue-600 hover:text-blue-800 text-sm"
    >
      <ExternalLink className="h-4 w-4" />
      TensorFlow.js Security Models
    </a>
  </div>
</div>

                <Button
                  onClick={() => {
                    setCurrentStep(0);
                    setAnswers({});
                    setFormData({
                      projectName: '',
                      developer: '',
                      org: '',
                      loginId: '',
                      date: new Date().toISOString().split('T')[0],
                      goal: '',
                      devType: '',
                      stage: 'concept',
                      platform: '',
                      customPlatform: '',
                      dataCategory: '',
                      intendedOutput: '',
                      expectedIntegrations: '',
                      teamSize: '',
                      otherDetails: ''
                    });
                    setPreFlightResults(null);
                    setPdfError(null);
                    setPdfSuccess(false);
                    setRiskScore(0);
                    setNormalizedScore(0);
                    setRiskZone('');
                    setExpandedGuidance({});
                  }}
                  variant="outline"
                  className="w-full border-gray-300 mt-4 hover:bg-gray-50"
                >
                  Start New Assessment
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return null;
};

export default ConceptReview;