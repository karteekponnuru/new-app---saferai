// @ts-nocheck
import nlp from 'compromise';

interface Vulnerability {
  type: string;
  severity: 'Critical' | 'High' | 'Medium' | 'Low';
  description: string;
  recommendation: string;
}

interface AnalysisResult {
  vulnerabilities: Vulnerability[];
  risk_score: number;
  summary: string;
  recommendations: string[];
}

export class PromptAnalyzer {
  private securityPatterns = {
    injection: [
      /ignore\s+(previous|above|all)\s+(instructions?|prompts?|rules?)/gi,
      /forget\s+(everything|all|previous)/gi,
      /system\s*:\s*you\s+are\s+now/gi,
      /\[SYSTEM\]/gi,
      /\<\|im_start\|\>/gi,
      /\<\|im_end\|\>/gi,
    ],
    pii: [
      /\b\d{3}-\d{2}-\d{4}\b/g, // SSN
      /\b\d{16}\b/g, // Credit card
      /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/g, // Email
      /\b\d{3}[-.]?\d{3}[-.]?\d{4}\b/g, // Phone
    ],
    secrets: [
      /api[_-]?key\s*[:=]\s*['"]?[a-zA-Z0-9]{20,}['"]?/gi,
      /password\s*[:=]\s*['"][^'"]+['"]/gi,
      /token\s*[:=]\s*['"]?[a-zA-Z0-9]{20,}['"]?/gi,
      /secret\s*[:=]\s*['"][^'"]+['"]/gi,
    ],
    jailbreak: [
      /do\s+anything\s+now/gi,
      /DAN\s+mode/gi,
      /evil\s+mode/gi,
      /developer\s+mode/gi,
      /bypass\s+(safety|filter|restriction)/gi,
    ],
  };

  analyze(promptText: string): AnalysisResult {
    const vulnerabilities: Vulnerability[] = [];
    const doc = nlp(promptText);

    // Check for prompt injection
    const injectionMatches = this.checkPatterns(promptText, this.securityPatterns.injection);
    if (injectionMatches.length > 0) {
      vulnerabilities.push({
        type: 'Prompt Injection Risk',
        severity: 'High',
        description: `Detected ${injectionMatches.length} potential prompt injection pattern(s). The prompt contains phrases that attempt to override system instructions.`,
        recommendation: 'Use clear delimiters between system and user content. Validate and sanitize user input before processing.',
      });
    }

    // Check for PII exposure
    const piiMatches = this.checkPatterns(promptText, this.securityPatterns.pii);
    if (piiMatches.length > 0) {
      vulnerabilities.push({
        type: 'PII Exposure Risk',
        severity: 'Critical',
        description: `Found ${piiMatches.length} potential PII pattern(s) including emails, phone numbers, or identification numbers.`,
        recommendation: 'Implement PII detection and filtering. Never include sensitive personal information in prompts.',
      });
    }

    // Check for hardcoded secrets
    const secretMatches = this.checkPatterns(promptText, this.securityPatterns.secrets);
    if (secretMatches.length > 0) {
      vulnerabilities.push({
        type: 'Hardcoded Secrets',
        severity: 'Critical',
        description: `Detected ${secretMatches.length} potential hardcoded secret(s) or API key(s) in the prompt.`,
        recommendation: 'Remove all hardcoded credentials. Use environment variables or secure secret management.',
      });
    }

    // Check for jailbreak attempts
    const jailbreakMatches = this.checkPatterns(promptText, this.securityPatterns.jailbreak);
    if (jailbreakMatches.length > 0) {
      vulnerabilities.push({
        type: 'Jailbreak Attempt',
        severity: 'High',
        description: `Found ${jailbreakMatches.length} potential jailbreak pattern(s) attempting to bypass safety restrictions.`,
        recommendation: 'Implement content filtering and output validation. Monitor for adversarial prompts.',
      });
    }

    // Analyze prompt structure
    const sentences = doc.sentences().out('array');
    if (sentences.length > 20) {
      vulnerabilities.push({
        type: 'Overly Complex Prompt',
        severity: 'Medium',
        description: 'Prompt contains many sentences which may lead to unclear instructions or unintended behavior.',
        recommendation: 'Simplify prompt structure. Break complex tasks into smaller, clearer instructions.',
      });
    }

    // Check for ambiguous language
    const ambiguousWords = doc.match('(maybe|perhaps|possibly|might|could)').out('array');
    if (ambiguousWords.length > 3) {
      vulnerabilities.push({
        type: 'Ambiguous Instructions',
        severity: 'Low',
        description: `Found ${ambiguousWords.length} ambiguous terms that may lead to inconsistent AI behavior.`,
        recommendation: 'Use clear, direct language. Replace ambiguous terms with specific instructions.',
      });
    }

    // Calculate risk score (1-5)
    const riskScore = this.calculateRiskScore(vulnerabilities);

    // Generate summary
    const summary = this.generateSummary(vulnerabilities);

    // Generate recommendations
    const recommendations = this.generateRecommendations(vulnerabilities);

    return {
      vulnerabilities,
      risk_score: riskScore,
      summary,
      recommendations,
    };
  }

  private checkPatterns(text: string, patterns: RegExp[]): string[] {
    const matches: string[] = [];
    patterns.forEach((pattern) => {
      const found = text.match(pattern);
      if (found) {
        matches.push(...found);
      }
    });
    return matches;
  }

  private calculateRiskScore(vulnerabilities: Vulnerability[]): number {
    if (vulnerabilities.length === 0) return 1;

    const severityScores = {
      Critical: 5,
      High: 4,
      Medium: 3,
      Low: 2,
    };

    const maxScore = Math.max(
      ...vulnerabilities.map((v) => severityScores[v.severity])
    );

    return Math.min(5, maxScore);
  }

  private generateSummary(vulnerabilities: Vulnerability[]): string {
    if (vulnerabilities.length === 0) {
      return 'No significant security issues detected. Prompt appears safe.';
    }

    const counts = {
      Critical: vulnerabilities.filter((v) => v.severity === 'Critical').length,
      High: vulnerabilities.filter((v) => v.severity === 'High').length,
      Medium: vulnerabilities.filter((v) => v.severity === 'Medium').length,
      Low: vulnerabilities.filter((v) => v.severity === 'Low').length,
    };

    const parts: string[] = [];
    if (counts.Critical > 0) parts.push(`${counts.Critical} critical`);
    if (counts.High > 0) parts.push(`${counts.High} high`);
    if (counts.Medium > 0) parts.push(`${counts.Medium} medium`);
    if (counts.Low > 0) parts.push(`${counts.Low} low`);

    return `Found ${vulnerabilities.length} security issue(s): ${parts.join(', ')} severity`;
  }

  private generateRecommendations(vulnerabilities: Vulnerability[]): string[] {
    const recommendations = new Set<string>();

    recommendations.add('Implement input validation and sanitization');
    recommendations.add('Use clear delimiters between system and user content');
    recommendations.add('Add output validation guardrails');
    recommendations.add('Monitor and log all prompt interactions');

    vulnerabilities.forEach((v) => {
      if (v.type.includes('PII')) {
        recommendations.add('Implement PII detection and filtering');
        recommendations.add('Use data anonymization techniques');
      }
      if (v.type.includes('Injection')) {
        recommendations.add('Test for prompt injection vulnerabilities');
        recommendations.add('Implement prompt firewall or content filtering');
      }
      if (v.type.includes('Secret')) {
        recommendations.add('Use environment variables for credentials');
        recommendations.add('Implement secret scanning in CI/CD');
      }
    });

    return Array.from(recommendations);
  }
}

export const promptAnalyzer = new PromptAnalyzer();
