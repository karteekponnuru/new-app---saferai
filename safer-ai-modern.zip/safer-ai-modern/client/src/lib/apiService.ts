import axios, { AxiosInstance } from 'axios';
import { fetchAuthSession } from '@aws-amplify/auth';

const API_BASE_URL = 'https://0wji356jgl.execute-api.ap-south-1.amazonaws.com/prod';

class SaferAIApiService {
  private client: AxiosInstance;

  constructor() {
    this.client = axios.create({
      baseURL: API_BASE_URL,
      headers: {
        'Content-Type': 'application/json',
      },
      timeout: 30000,
    });

    // Request interceptor to add auth token
    this.client.interceptors.request.use(
      async (config) => {
        try {
          const session = await fetchAuthSession();
          const idToken = session.tokens?.idToken?.toString();
          
          if (idToken) {
            config.headers.Authorization = `Bearer ${idToken}`;
            console.log('✅ Token added to request:', config.url);
          } else {
            console.warn('⚠️ No ID token available');
          }
        } catch (error) {
          console.error('❌ Error getting auth token:', error);
        }
        return config;
      },
      (error) => {
        return Promise.reject(error);
      }
    );

    // Response interceptor for error handling
    this.client.interceptors.response.use(
      (response) => response,
      async (error) => {
        if (error.response?.status === 401) {
          console.error('❌ Unauthorized - token may be expired');
          
          // Try to refresh token
          try {
            console.log('🔄 Attempting to refresh token...');
            const session = await fetchAuthSession({ forceRefresh: true });
            const newIdToken = session.tokens?.idToken?.toString();
            
            if (newIdToken && error.config) {
              console.log('✅ Token refreshed, retrying request');
              error.config.headers.Authorization = `Bearer ${newIdToken}`;
              return this.client.request(error.config);
            }
          } catch (refreshError) {
            console.error('❌ Token refresh failed:', refreshError);
          }
        }
        
        return Promise.reject(error);
      }
    );
  }

  async analyzePrompts(data: {
    prompt: string;
    platform: string;
    devType: string;
    dataCategory: string;
    goal: string;
    intendedUse: string;
  }) {
    try {
      console.log('📤 Sending prompt analysis request');
      const response = await this.client.post('/analyze-prompts', data);
      console.log('📥 Received prompt analysis response');
      
      let result = response.data;
      if (typeof result.body === 'string') {
        result = JSON.parse(result.body);
      }
      
      return result;
    } catch (error) {
      console.error('❌ Error analyzing prompts:', error);
      throw error;
    }
  }

  async analyzeCode(data: {
    code: string;
    platform: string;
    devType: string;
    dataCategory: string;
    goal: string;
    intendedUse: string;
    language: string;
    awsServices: string;
  }) {
    try {
      console.log('📤 Sending code analysis request');
      const response = await this.client.post('/analyze-code', data);
      console.log('📥 Received code analysis response');
      
      let result = response.data;
      if (typeof result.body === 'string') {
        result = JSON.parse(result.body);
      }
      
      return result;
    } catch (error) {
      console.error('❌ Error analyzing code:', error);
      throw error;
    }
  }
}

export const apiService = new SaferAIApiService();
