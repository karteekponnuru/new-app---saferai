interface Vulnerability {
  type: string;
  severity: 'Critical' | 'High' | 'Medium' | 'Low';
  line?: number;
  description: string;
  recommendation: string;
}

interface AnalysisResult {
  vulnerabilities: Vulnerability[];
  risk_score: number;
  summary: string;
  recommendations: string[];
}

export class CodeAnalyzer {
  private securityPatterns = {
    sqlInjection: [
      /execute\s*\(\s*["'].*\+.*["']\s*\)/gi,
      /query\s*\(\s*["'].*\+.*["']\s*\)/gi,
      /SELECT.*FROM.*WHERE.*\+/gi,
      /INSERT.*INTO.*VALUES.*\+/gi,
    ],
    hardcodedSecrets: [
      /api[_-]?key\s*=\s*["'][a-zA-Z0-9]{20,}["']/gi,
      /password\s*=\s*["'][^"']+["']/gi,
      /secret\s*=\s*["'][^"']+["']/gi,
      /token\s*=\s*["'][a-zA-Z0-9]{20,}["']/gi,
      /aws_access_key_id\s*=\s*["'][^"']+["']/gi,
    ],
    xss: [
      /innerHTML\s*=\s*/gi,
      /document\.write\s*\(/gi,
      /eval\s*\(/gi,
      /dangerouslySetInnerHTML/gi,
    ],
    insecureDeserialization: [
      /pickle\.loads/gi,
      /yaml\.load\s*\(/gi,
      /JSON\.parse\s*\(\s*[^)]*request/gi,
      /unserialize\s*\(/gi,
    ],
    commandInjection: [
      /exec\s*\(\s*[^)]*input/gi,
      /system\s*\(\s*[^)]*input/gi,
      /shell_exec\s*\(/gi,
      /subprocess\.(call|run|Popen)\s*\([^)]*input/gi,
    ],
    pathTraversal: [
      /\.\.\/\.\.\//g,
      /open\s*\(\s*[^)]*input.*["']\s*\)/gi,
      /readFile\s*\(\s*[^)]*req\./gi,
    ],
  };

  analyze(code: string): AnalysisResult {
    const vulnerabilities: Vulnerability[] = [];
    const lines = code.split('\n');

    // Check for SQL injection
    const sqlMatches = this.findPatternMatches(code, lines, this.securityPatterns.sqlInjection);
    if (sqlMatches.length > 0) {
      sqlMatches.forEach((match) => {
        vulnerabilities.push({
          type: 'SQL Injection Risk',
          severity: 'High',
          line: match.line,
          description: 'User input appears to be concatenated directly into SQL query',
          recommendation: 'Use parameterized queries or prepared statements',
        });
      });
    }

    // Check for hardcoded secrets
    const secretMatches = this.findPatternMatches(code, lines, this.securityPatterns.hardcodedSecrets);
    if (secretMatches.length > 0) {
      secretMatches.forEach((match) => {
        vulnerabilities.push({
          type: 'Hardcoded Credentials',
          severity: 'Critical',
          line: match.line,
          description: 'API key or password found in source code',
          recommendation: 'Move credentials to environment variables or secure secret management',
        });
      });
    }

    // Check for XSS vulnerabilities
    const xssMatches = this.findPatternMatches(code, lines, this.securityPatterns.xss);
    if (xssMatches.length > 0) {
      xssMatches.forEach((match) => {
        vulnerabilities.push({
          type: 'Cross-Site Scripting (XSS)',
          severity: 'High',
          line: match.line,
          description: 'Potentially unsafe HTML rendering detected',
          recommendation: 'Sanitize user input and use safe rendering methods',
        });
      });
    }

    // Check for insecure deserialization
    const deserializationMatches = this.findPatternMatches(code, lines, this.securityPatterns.insecureDeserialization);
    if (deserializationMatches.length > 0) {
      deserializationMatches.forEach((match) => {
        vulnerabilities.push({
          type: 'Insecure Deserialization',
          severity: 'High',
          line: match.line,
          description: 'Unsafe deserialization of untrusted data',
          recommendation: 'Validate and sanitize data before deserialization',
        });
      });
    }

    // Check for command injection
    const commandMatches = this.findPatternMatches(code, lines, this.securityPatterns.commandInjection);
    if (commandMatches.length > 0) {
      commandMatches.forEach((match) => {
        vulnerabilities.push({
          type: 'Command Injection',
          severity: 'Critical',
          line: match.line,
          description: 'User input passed directly to system command',
          recommendation: 'Use safe APIs and validate/sanitize all user input',
        });
      });
    }

    // Check for path traversal
    const pathMatches = this.findPatternMatches(code, lines, this.securityPatterns.pathTraversal);
    if (pathMatches.length > 0) {
      pathMatches.forEach((match) => {
        vulnerabilities.push({
          type: 'Path Traversal',
          severity: 'Medium',
          line: match.line,
          description: 'Potential directory traversal vulnerability',
          recommendation: 'Validate file paths and use safe path joining methods',
        });
      });
    }

    // Check for missing input validation
    if (code.includes('request') || code.includes('input') || code.includes('req.')) {
      const hasValidation = /validate|sanitize|check|verify/gi.test(code);
      if (!hasValidation) {
        vulnerabilities.push({
          type: 'Missing Input Validation',
          severity: 'Medium',
          description: 'No validation detected on user-supplied data',
          recommendation: 'Implement input validation and sanitization',
        });
      }
    }

    // Calculate risk score
    const riskScore = this.calculateRiskScore(vulnerabilities);

    // Generate summary
    const summary = this.generateSummary(vulnerabilities);

    // Generate recommendations
    const recommendations = this.generateRecommendations(vulnerabilities);

    return {
      vulnerabilities,
      risk_score: riskScore,
      summary,
      recommendations,
    };
  }

  private findPatternMatches(
    code: string,
    lines: string[],
    patterns: RegExp[]
  ): Array<{ line: number; match: string }> {
    const matches: Array<{ line: number; match: string }> = [];

    patterns.forEach((pattern) => {
      lines.forEach((line, index) => {
        const found = line.match(pattern);
        if (found) {
          matches.push({
            line: index + 1,
            match: found[0],
          });
        }
      });
    });

    return matches;
  }

  private calculateRiskScore(vulnerabilities: Vulnerability[]): number {
    if (vulnerabilities.length === 0) return 1;

    const severityScores = {
      Critical: 5,
      High: 4,
      Medium: 3,
      Low: 2,
    };

    const maxScore = Math.max(
      ...vulnerabilities.map((v) => severityScores[v.severity])
    );

    return Math.min(5, maxScore);
  }

  private generateSummary(vulnerabilities: Vulnerability[]): string {
    if (vulnerabilities.length === 0) {
      return 'No significant security issues detected. Code appears safe.';
    }

    const counts = {
      Critical: vulnerabilities.filter((v) => v.severity === 'Critical').length,
      High: vulnerabilities.filter((v) => v.severity === 'High').length,
      Medium: vulnerabilities.filter((v) => v.severity === 'Medium').length,
      Low: vulnerabilities.filter((v) => v.severity === 'Low').length,
    };

    const parts: string[] = [];
    if (counts.Critical > 0) parts.push(`${counts.Critical} critical`);
    if (counts.High > 0) parts.push(`${counts.High} high`);
    if (counts.Medium > 0) parts.push(`${counts.Medium} medium`);
    if (counts.Low > 0) parts.push(`${counts.Low} low`);

    return `Found ${vulnerabilities.length} security issue(s): ${parts.join(', ')} severity`;
  }

  private generateRecommendations(vulnerabilities: Vulnerability[]): string[] {
    const recommendations = new Set<string>();

    recommendations.add('Implement comprehensive input validation');
    recommendations.add('Use parameterized queries for database operations');
    recommendations.add('Add security headers to API responses');
    recommendations.add('Implement proper error handling');

    vulnerabilities.forEach((v) => {
      if (v.type.includes('SQL')) {
        recommendations.add('Use ORM or prepared statements');
      }
      if (v.type.includes('XSS')) {
        recommendations.add('Implement Content Security Policy');
      }
      if (v.type.includes('Credentials')) {
        recommendations.add('Use secure secret management service');
      }
      if (v.type.includes('Command')) {
        recommendations.add('Avoid system commands with user input');
      }
    });

    return Array.from(recommendations);
  }
}

export const codeAnalyzer = new CodeAnalyzer();
