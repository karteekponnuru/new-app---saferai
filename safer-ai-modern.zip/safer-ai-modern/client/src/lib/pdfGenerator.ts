import { jsPDF } from 'jspdf';

interface AnalysisResult {
  vulnerabilities: Array<{
    type: string;
    severity: string;
    line?: number;
    description: string;
    recommendation: string;
  }>;
  risk_score: number;
  summary: string;
  recommendations: string[];
}

interface ProjectInfo {
  platform: string;
  devType: string;
  dataCategory: string;
  goal: string;
  analysisType: 'prompt' | 'code';
  content: string;
}

export class PDFGenerator {
  private doc: jsPDF;
  private yPosition: number;
  private pageHeight: number;
  private margin: number;
  private lineHeight: number;

  constructor() {
    this.doc = new jsPDF();
    this.yPosition = 20;
    this.pageHeight = this.doc.internal.pageSize.height;
    this.margin = 20;
    this.lineHeight = 7;
  }

  private checkPageBreak(requiredSpace: number = 20) {
    if (this.yPosition + requiredSpace > this.pageHeight - this.margin) {
      this.doc.addPage();
      this.yPosition = this.margin;
    }
  }

  private addText(text: string, fontSize: number = 11, isBold: boolean = false) {
    this.doc.setFontSize(fontSize);
    this.doc.setFont('helvetica', isBold ? 'bold' : 'normal');
    
    const maxWidth = this.doc.internal.pageSize.width - 2 * this.margin;
    const lines = this.doc.splitTextToSize(text, maxWidth);
    
    lines.forEach((line: string) => {
      this.checkPageBreak();
      this.doc.text(line, this.margin, this.yPosition);
      this.yPosition += this.lineHeight;
    });
  }

  private addHeading(text: string, level: number = 1) {
    this.yPosition += 5; // Add spacing before heading
    this.checkPageBreak(15);
    
    const fontSize = level === 1 ? 16 : level === 2 ? 14 : 12;
    this.doc.setFontSize(fontSize);
    this.doc.setFont('helvetica', 'bold');
    this.doc.text(text, this.margin, this.yPosition);
    this.yPosition += this.lineHeight + 3;
  }

  private addSeparator() {
    this.checkPageBreak(10);
    this.doc.setDrawColor(200, 200, 200);
    this.doc.line(
      this.margin,
      this.yPosition,
      this.doc.internal.pageSize.width - this.margin,
      this.yPosition
    );
    this.yPosition += 8;
  }

  generateReport(
    projectInfo: ProjectInfo,
    result: AnalysisResult
  ): Blob {
    // Header
    this.doc.setFillColor(255, 153, 0); // Amazon Orange
    this.doc.rect(0, 0, this.doc.internal.pageSize.width, 30, 'F');
    
    this.doc.setTextColor(255, 255, 255);
    this.doc.setFontSize(20);
    this.doc.setFont('helvetica', 'bold');
    this.doc.text('SaferAI Security Report', this.margin, 20);
    
    this.doc.setTextColor(0, 0, 0);
    this.yPosition = 45;

    // Project Information
    this.addHeading('Project Information', 1);
    this.addText(`Platform: ${projectInfo.platform}`, 11, true);
    this.addText(`Development Type: ${projectInfo.devType}`, 11, true);
    this.addText(`Data Category: ${projectInfo.dataCategory}`, 11, true);
    this.addText(`Goal: ${projectInfo.goal || 'Not specified'}`, 11, true);
    this.addText(`Analysis Type: ${projectInfo.analysisType === 'prompt' ? 'Prompt Analysis' : 'Code Analysis'}`, 11, true);
    
    this.yPosition += 5;
    this.addSeparator();

    // Risk Score
    this.addHeading('Risk Assessment', 1);
    
    // Risk score box
    const riskColor = this.getRiskColor(result.risk_score);
    this.doc.setFillColor(riskColor.r, riskColor.g, riskColor.b);
    this.doc.roundedRect(this.margin, this.yPosition, 60, 20, 3, 3, 'F');
    
    this.doc.setTextColor(255, 255, 255);
    this.doc.setFontSize(14);
    this.doc.setFont('helvetica', 'bold');
    this.doc.text(`Risk Score: ${result.risk_score}/5`, this.margin + 5, this.yPosition + 13);
    
    this.doc.setTextColor(0, 0, 0);
    this.yPosition += 30;

    // Summary
    this.addText(result.summary, 11, false);
    this.yPosition += 5;
    this.addSeparator();

    // Vulnerabilities
    if (result.vulnerabilities.length > 0) {
      this.addHeading('Vulnerabilities Detected', 1);
      
      result.vulnerabilities.forEach((vuln, index) => {
        this.checkPageBreak(40);
        
        // Vulnerability box
        this.doc.setDrawColor(200, 200, 200);
        this.doc.setLineWidth(0.5);
        this.doc.rect(this.margin, this.yPosition, this.doc.internal.pageSize.width - 2 * this.margin, 0);
        
        this.yPosition += 5;
        
        // Type and Severity
        this.doc.setFontSize(12);
        this.doc.setFont('helvetica', 'bold');
        this.doc.text(`${index + 1}. ${vuln.type}`, this.margin + 5, this.yPosition);
        
        const severityColor = this.getSeverityColor(vuln.severity);
        this.doc.setFillColor(severityColor.r, severityColor.g, severityColor.b);
        this.doc.roundedRect(
          this.doc.internal.pageSize.width - this.margin - 35,
          this.yPosition - 5,
          30,
          8,
          2,
          2,
          'F'
        );
        
        this.doc.setTextColor(255, 255, 255);
        this.doc.setFontSize(9);
        this.doc.text(
          vuln.severity,
          this.doc.internal.pageSize.width - this.margin - 30,
          this.yPosition
        );
        
        this.doc.setTextColor(0, 0, 0);
        this.yPosition += 8;
        
        // Line number if available
        if (vuln.line) {
          this.doc.setFontSize(10);
          this.doc.setFont('helvetica', 'italic');
          this.doc.text(`Line ${vuln.line}`, this.margin + 5, this.yPosition);
          this.yPosition += 6;
        }
        
        // Description
        this.doc.setFontSize(10);
        this.doc.setFont('helvetica', 'normal');
        const descLines = this.doc.splitTextToSize(
          vuln.description,
          this.doc.internal.pageSize.width - 2 * this.margin - 10
        );
        descLines.forEach((line: string) => {
          this.checkPageBreak();
          this.doc.text(line, this.margin + 5, this.yPosition);
          this.yPosition += 5;
        });
        
        this.yPosition += 3;
        
        // Recommendation
        this.doc.setFont('helvetica', 'bold');
        this.doc.text('Recommendation:', this.margin + 5, this.yPosition);
        this.yPosition += 5;
        
        this.doc.setFont('helvetica', 'normal');
        const recLines = this.doc.splitTextToSize(
          vuln.recommendation,
          this.doc.internal.pageSize.width - 2 * this.margin - 10
        );
        recLines.forEach((line: string) => {
          this.checkPageBreak();
          this.doc.text(line, this.margin + 5, this.yPosition);
          this.yPosition += 5;
        });
        
        this.yPosition += 8;
      });
      
      this.addSeparator();
    }

    // Recommendations
    if (result.recommendations.length > 0) {
      this.addHeading('General Recommendations', 1);
      
      result.recommendations.forEach((rec, index) => {
        this.checkPageBreak(10);
        this.doc.setFontSize(10);
        this.doc.setFont('helvetica', 'normal');
        
        // Bullet point
        this.doc.circle(this.margin + 2, this.yPosition - 1.5, 1, 'F');
        
        const recLines = this.doc.splitTextToSize(
          rec,
          this.doc.internal.pageSize.width - 2 * this.margin - 10
        );
        recLines.forEach((line: string, lineIndex: number) => {
          this.checkPageBreak();
          this.doc.text(line, this.margin + 8, this.yPosition);
          this.yPosition += 5;
        });
        
        this.yPosition += 2;
      });
    }

    // Footer
    const pageCount = this.doc.getNumberOfPages();
    for (let i = 1; i <= pageCount; i++) {
      this.doc.setPage(i);
      this.doc.setFontSize(9);
      this.doc.setTextColor(128, 128, 128);
      this.doc.text(
        `Page ${i} of ${pageCount}`,
        this.doc.internal.pageSize.width / 2,
        this.pageHeight - 10,
        { align: 'center' }
      );
      this.doc.text(
        `Generated by SaferAI - ${new Date().toLocaleDateString()}`,
        this.margin,
        this.pageHeight - 10
      );
    }

    return this.doc.output('blob');
  }

  private getRiskColor(score: number): { r: number; g: number; b: number } {
    if (score >= 4) return { r: 220, g: 38, b: 38 }; // Red
    if (score >= 3) return { r: 249, g: 115, b: 22 }; // Orange
    if (score >= 2) return { r: 234, g: 179, b: 8 }; // Yellow
    return { r: 34, g: 197, b: 94 }; // Green
  }

  private getSeverityColor(severity: string): { r: number; g: number; b: number } {
    const s = severity.toLowerCase();
    if (s === 'critical') return { r: 153, g: 27, b: 27 };
    if (s === 'high') return { r: 220, g: 38, b: 38 };
    if (s === 'medium') return { r: 249, g: 115, b: 22 };
    return { r: 234, g: 179, b: 8 };
  }
}

export function downloadPDF(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
