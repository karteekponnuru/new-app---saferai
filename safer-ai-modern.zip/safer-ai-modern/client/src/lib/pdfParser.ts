import * as pdfjsLib from 'pdfjs-dist';

// Configure PDF.js worker
pdfjsLib.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.js`;

export interface ConceptReviewData {
  projectName?: string;
  platform?: string;
  devType?: string;
  dataCategory?: string;
  goal?: string;
  description?: string;
  prompts?: string[];
  code?: string;
  risks?: string[];
}

export class PDFParser {
  async parsePDF(file: File): Promise<ConceptReviewData> {
    try {
      const arrayBuffer = await file.arrayBuffer();
      const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
      
      let fullText = '';
      
      // Extract text from all pages
      for (let i = 1; i <= pdf.numPages; i++) {
        const page = await pdf.getPage(i);
        const textContent = await page.getTextContent();
        const pageText = textContent.items
          .map((item: any) => item.str)
          .join(' ');
        fullText += pageText + '\n';
      }
      
      // Parse the extracted text
      return this.parseConceptReview(fullText);
    } catch (error) {
      console.error('Error parsing PDF:', error);
      throw new Error('Failed to parse PDF file');
    }
  }

  private parseConceptReview(text: string): ConceptReviewData {
    const data: ConceptReviewData = {
      prompts: [],
      risks: [],
    };

    // Extract project name
    const projectMatch = text.match(/Project\s*(?:Name)?[:\s]+([^\n]+)/i);
    if (projectMatch) {
      data.projectName = projectMatch[1].trim();
    }

    // Extract platform
    const platformMatch = text.match(/Platform[:\s]+(AWS|Azure|GCP|Google Cloud)/i);
    if (platformMatch) {
      data.platform = platformMatch[1].trim();
    }

    // Extract development type
    const devTypeMatch = text.match(/(?:Development\s*Type|Dev\s*Type)[:\s]+(GenAI|ML|Analytics|Machine Learning)/i);
    if (devTypeMatch) {
      data.devType = devTypeMatch[1].trim();
    }

    // Extract data category
    const dataCategoryMatch = text.match(/Data\s*Category[:\s]+(Public|Internal|Confidential|Private)/i);
    if (dataCategoryMatch) {
      data.dataCategory = dataCategoryMatch[1].trim();
    }

    // Extract goal
    const goalMatch = text.match(/(?:Goal|Purpose|Objective)[:\s]+([^\n]+)/i);
    if (goalMatch) {
      data.goal = goalMatch[1].trim();
    }

    // Extract description
    const descMatch = text.match(/Description[:\s]+([^\n]+(?:\n(?!(?:Platform|Goal|Risk))[^\n]+)*)/i);
    if (descMatch) {
      data.description = descMatch[1].trim();
    }

    // Extract prompts (look for sections with "Prompt" or code blocks)
    const promptPattern = /(?:Prompt|System Prompt|User Prompt)[:\s]+([^\n]+(?:\n(?!(?:Platform|Goal|Risk))[^\n]+)*)/gi;
    let promptMatch;
    while ((promptMatch = promptPattern.exec(text)) !== null) {
      const promptText = promptMatch[1].trim();
      if (promptText) {
        data.prompts?.push(promptText);
      }
    }

    // Extract code snippets
    const codeMatch = text.match(/(?:Code|Implementation|Source Code)[:\s]+([^\n]+(?:\n(?!(?:Platform|Goal|Risk))[^\n]+)*)/i);
    if (codeMatch) {
      data.code = codeMatch[1].trim();
    }

    // Extract risks
    const riskPattern = /(?:Risk|Concern|Issue)[:\s]+([^\n]+)/gi;
    let riskMatch;
    while ((riskMatch = riskPattern.exec(text)) !== null) {
      const riskText = riskMatch[1].trim();
      if (riskText) {
        data.risks?.push(riskText);
      }
    }

    return data;
  }

  // Alternative: Parse structured PDF with form fields
  async parseStructuredPDF(file: File): Promise<ConceptReviewData> {
    try {
      const arrayBuffer = await file.arrayBuffer();
      const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
      
      const data: ConceptReviewData = {
        prompts: [],
        risks: [],
      };

      // Try to extract form fields if available
      for (let i = 1; i <= pdf.numPages; i++) {
        const page = await pdf.getPage(i);
        const annotations = await page.getAnnotations();
        
        annotations.forEach((annotation: any) => {
          if (annotation.fieldType === 'Tx' && annotation.fieldValue) {
            const fieldName = annotation.fieldName?.toLowerCase() || '';
            const fieldValue = annotation.fieldValue;

            if (fieldName.includes('project')) {
              data.projectName = fieldValue;
            } else if (fieldName.includes('platform')) {
              data.platform = fieldValue;
            } else if (fieldName.includes('type')) {
              data.devType = fieldValue;
            } else if (fieldName.includes('category')) {
              data.dataCategory = fieldValue;
            } else if (fieldName.includes('goal')) {
              data.goal = fieldValue;
            } else if (fieldName.includes('prompt')) {
              data.prompts?.push(fieldValue);
            } else if (fieldName.includes('code')) {
              data.code = fieldValue;
            }
          }
        });
      }

      // If no form fields found, fall back to text parsing
      if (!data.projectName && !data.platform) {
        return this.parsePDF(file);
      }

      return data;
    } catch (error) {
      console.error('Error parsing structured PDF:', error);
      // Fall back to regular text parsing
      return this.parsePDF(file);
    }
  }
}

export const pdfParser = new PDFParser();
