import { Amplify } from '@aws-amplify/core';

const amplifyConfig = {
  Auth: {
    Cognito: {
      region: 'ap-south-1',
      userPoolId: 'ap-south-1_tJYrDS5NW',
      userPoolClientId: '2643jfjr4492gpr6t5lbnoqnp9',
      loginWith: {
        oauth: {
          domain: 'ap-south-1tjyrds5nw.auth.ap-south-1.amazoncognito.com',
          scopes: ['openid', 'email', 'profile', 'aws.cognito.signin.user.admin'],
          redirectSignIn: [typeof window !== 'undefined' ? window.location.origin : 'http://localhost:5173'],
          redirectSignOut: [typeof window !== 'undefined' ? window.location.origin : 'http://localhost:5173'],
          responseType: 'code' as const,
        },
      },
    },
  },
};

// Configure Amplify
Amplify.configure(amplifyConfig);

export default amplifyConfig;
