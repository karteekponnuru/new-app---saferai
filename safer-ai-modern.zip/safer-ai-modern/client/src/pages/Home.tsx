import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Shield, Code, FileText, CheckCircle2, AlertTriangle } from "lucide-react";
import { Link } from "wouter";
import { signOut, getCurrentUser } from '@aws-amplify/auth';
import { useState, useEffect } from "react";

export default function Home() {
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    checkUser();
  }, []);

  async function checkUser() {
    try {
      const currentUser = await getCurrentUser();
      setUser(currentUser);
    } catch (error) {
      console.log('No user signed in');
    } finally {
      setLoading(false);
    }
  }

  async function handleSignOut() {
    try {
      await signOut();
      setUser(null);
    } catch (error) {
      console.error('Error signing out:', error);
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/20">
      {/* Header */}
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <Shield className="h-6 w-6 text-primary" />
            <span className="text-xl font-bold">SaferAI</span>
          </div>
          <nav className="flex items-center gap-6">
            {user && (
              <>
                <Link href="/review">
                  <Button variant="ghost">Product Review</Button>
                </Link>
                <Button variant="outline" onClick={handleSignOut}>
                  Sign Out
                </Button>
              </>
            )}
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container py-24 space-y-8">
        <div className="text-center space-y-4 max-w-3xl mx-auto">
          <h1 className="text-5xl font-bold tracking-tight">
            Security Assessment Framework for{" "}
            <span className="text-primary">AI Agents</span>
          </h1>
          <p className="text-xl text-muted-foreground">
            Comprehensive security analysis for your AI prompts and code. Detect vulnerabilities,
            identify risks, and ensure compliance with industry standards.
          </p>
          <div className="flex gap-4 justify-center pt-4">
            {user ? (
              <Link href="/review">
                <Button size="lg" className="gap-2">
                  <Shield className="h-5 w-5" />
                  Start Analysis
                </Button>
              </Link>
            ) : (
              <p className="text-sm text-muted-foreground">
                Please sign in to access the analysis tools
              </p>
            )}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="container py-16">
        <div className="grid md:grid-cols-3 gap-6">
          <Card>
            <CardHeader>
              <FileText className="h-10 w-10 text-primary mb-2" />
              <CardTitle>Prompt Analysis</CardTitle>
              <CardDescription>
                Detect prompt injection, PII exposure, and jailbreak attempts
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-primary" />
                  Pattern matching
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-primary" />
                  NLP-based analysis
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-primary" />
                  Real-time feedback
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <Code className="h-10 w-10 text-primary mb-2" />
              <CardTitle>Code Analysis</CardTitle>
              <CardDescription>
                Identify security vulnerabilities and coding best practices
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-primary" />
                  SQL injection detection
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-primary" />
                  XSS vulnerability scan
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-primary" />
                  Secret detection
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <AlertTriangle className="h-10 w-10 text-primary mb-2" />
              <CardTitle>Risk Scoring</CardTitle>
              <CardDescription>
                Comprehensive risk assessment with actionable recommendations
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-primary" />
                  1-5 risk scale
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-primary" />
                  Detailed reports
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-primary" />
                  PDF export
                </li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t mt-24 py-8">
        <div className="container text-center text-sm text-muted-foreground">
          <p>SaferAI - Security Assessment Framework for Evaluating Risk in AI Agents</p>
          <p className="mt-2">© 2025 SaferAI. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
