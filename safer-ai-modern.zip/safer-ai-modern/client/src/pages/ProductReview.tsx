import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Shield, Code, AlertTriangle, CheckCircle2, Loader2, ArrowLeft, FileText, Upload } from "lucide-react";
import { Link } from "wouter";
import { apiService } from "@/lib/apiService";
import { promptAnalyzer } from "@/lib/promptAnalyzer";
import { codeAnalyzer } from "@/lib/codeAnalyzer";
import { PDFGenerator, downloadPDF } from "@/lib/pdfGenerator";
import { pdfParser, ConceptReviewData } from "@/lib/pdfParser";
import { toast } from "sonner";

interface AnalysisResult {
  vulnerabilities: Array<{
    type: string;
    severity: string;
    line?: number;
    description: string;
    recommendation: string;
  }>;
  risk_score: number;
  summary: string;
  recommendations: string[];
}

export default function ProductReview() {
  const [promptText, setPromptText] = useState("");
  const [codeText, setCodeText] = useState("");
  const [platform, setPlatform] = useState("AWS");
  const [devType, setDevType] = useState("GenAI");
  const [dataCategory, setDataCategory] = useState("Public");
  const [goal, setGoal] = useState("");
  
  const [promptAnalyzing, setPromptAnalyzing] = useState(false);
  const [codeAnalyzing, setCodeAnalyzing] = useState(false);
  
  const [promptResult, setPromptResult] = useState<AnalysisResult | null>(null);
  const [codeResult, setCodeResult] = useState<AnalysisResult | null>(null);
  const [uploadedPDF, setUploadedPDF] = useState<File | null>(null);

  async function handlePDFUpload(event: React.ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;

    if (file.type !== 'application/pdf') {
      toast.error('Please upload a PDF file');
      return;
    }

    setUploadedPDF(file);
    toast.info('Parsing PDF...');

    try {
      const data = await pdfParser.parsePDF(file);
      
      // Auto-fill form fields
      if (data.platform) setPlatform(data.platform);
      if (data.devType) setDevType(data.devType);
      if (data.dataCategory) setDataCategory(data.dataCategory);
      if (data.goal) setGoal(data.goal);
      if (data.prompts && data.prompts.length > 0) {
        setPromptText(data.prompts.join('\n\n'));
      }
      if (data.code) setCodeText(data.code);
      
      toast.success('PDF parsed successfully!');
    } catch (error) {
      console.error('PDF parsing error:', error);
      toast.error('Failed to parse PDF');
    }
  }

  function exportToPDF(analysisType: 'prompt' | 'code') {
    const result = analysisType === 'prompt' ? promptResult : codeResult;
    const content = analysisType === 'prompt' ? promptText : codeText;
    
    if (!result) {
      toast.error('No analysis results to export');
      return;
    }

    try {
      const generator = new PDFGenerator();
      const pdfBlob = generator.generateReport(
        {
          platform,
          devType,
          dataCategory,
          goal,
          analysisType,
          content,
        },
        result
      );
      
      const filename = `SaferAI-${analysisType}-analysis-${new Date().toISOString().split('T')[0]}.pdf`;
      downloadPDF(pdfBlob, filename);
      toast.success('PDF exported successfully!');
    } catch (error) {
      console.error('PDF export error:', error);
      toast.error('Failed to export PDF');
    }
  }

  async function analyzePrompt() {
    if (!promptText.trim()) {
      toast.error("Please enter a prompt to analyze");
      return;
    }

    setPromptAnalyzing(true);
    setPromptResult(null);

    try {
      console.log("🔄 Attempting API analysis...");
      const apiResult = await apiService.analyzePrompts({
        prompt: promptText,
        platform,
        devType,
        dataCategory,
        goal: goal || "Security analysis",
        intendedUse: goal || "Security analysis",
      });

      setPromptResult(apiResult);
      toast.success("Analysis complete (API)");
    } catch (apiError) {
      console.error("API analysis failed, using built-in analyzer:", apiError);
      toast.info("Using built-in analysis");
      
      const builtInResult = promptAnalyzer.analyze(promptText);
      setPromptResult(builtInResult);
    } finally {
      setPromptAnalyzing(false);
    }
  }

  async function analyzeCode() {
    if (!codeText.trim()) {
      toast.error("Please enter code to analyze");
      return;
    }

    setCodeAnalyzing(true);
    setCodeResult(null);

    try {
      console.log("🔄 Attempting API analysis...");
      const apiResult = await apiService.analyzeCode({
        code: codeText,
        platform,
        devType,
        dataCategory,
        goal: goal || "Security analysis",
        intendedUse: goal || "Security analysis",
        language: "Python",
        awsServices: "Bedrock, Lambda, API Gateway",
      });

      setCodeResult(apiResult);
      toast.success("Analysis complete (API)");
    } catch (apiError) {
      console.error("API analysis failed, using built-in analyzer:", apiError);
      toast.info("Using built-in analysis");
      
      const builtInResult = codeAnalyzer.analyze(codeText);
      setCodeResult(builtInResult);
    } finally {
      setCodeAnalyzing(false);
    }
  }

  function getRiskColor(score: number) {
    if (score >= 4) return "text-red-600";
    if (score >= 3) return "text-orange-600";
    if (score >= 2) return "text-yellow-600";
    return "text-green-600";
  }

  function getSeverityColor(severity: string) {
    const s = severity.toLowerCase();
    if (s === "critical") return "destructive";
    if (s === "high") return "destructive";
    if (s === "medium") return "default";
    return "secondary";
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <div className="flex items-center gap-2">
              <Shield className="h-6 w-6 text-primary" />
              <span className="text-xl font-bold">Product Review</span>
            </div>
          </div>
        </div>
      </header>

      <div className="container py-8 space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Upload className="h-5 w-5" />
              Upload Concept Review PDF
            </CardTitle>
            <CardDescription>Upload a concept review PDF to auto-fill project details</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-4">
              <input
                type="file"
                accept=".pdf"
                onChange={handlePDFUpload}
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm file:border-0 file:bg-transparent file:text-sm file:font-medium"
              />
              {uploadedPDF && (
                <Badge variant="secondary" className="flex-shrink-0">
                  {uploadedPDF.name}
                </Badge>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Project Configuration</CardTitle>
            <CardDescription>Configure your project settings for analysis</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-4 gap-4">
              <div className="space-y-2">
                <Label>Platform</Label>
                <Select value={platform} onValueChange={setPlatform}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="AWS">AWS</SelectItem>
                    <SelectItem value="Azure">Azure</SelectItem>
                    <SelectItem value="GCP">GCP</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Development Type</Label>
                <Select value={devType} onValueChange={setDevType}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="GenAI">GenAI</SelectItem>
                    <SelectItem value="ML">ML</SelectItem>
                    <SelectItem value="Analytics">Analytics</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Data Category</Label>
                <Select value={dataCategory} onValueChange={setDataCategory}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Public">Public</SelectItem>
                    <SelectItem value="Internal">Internal</SelectItem>
                    <SelectItem value="Confidential">Confidential</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Goal</Label>
                <input
                  type="text"
                  value={goal}
                  onChange={(e) => setGoal(e.target.value)}
                  placeholder="e.g., Customer support bot"
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="prompt" className="space-y-4">
          <TabsList className="grid w-full max-w-md grid-cols-2">
            <TabsTrigger value="prompt" className="gap-2">
              <Shield className="h-4 w-4" />
              Prompt Analysis
            </TabsTrigger>
            <TabsTrigger value="code" className="gap-2">
              <Code className="h-4 w-4" />
              Code Analysis
            </TabsTrigger>
          </TabsList>

          <TabsContent value="prompt" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Prompt Security Analysis</CardTitle>
                <CardDescription>
                  Analyze your AI prompts for security vulnerabilities and best practices
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Enter your prompt</Label>
                  <Textarea
                    value={promptText}
                    onChange={(e) => setPromptText(e.target.value)}
                    placeholder="Paste your AI prompt here..."
                    className="min-h-[200px] font-mono text-sm"
                  />
                </div>
                <div className="flex gap-2">
                  <Button
                    onClick={analyzePrompt}
                    disabled={promptAnalyzing}
                    className="flex-1"
                  >
                    {promptAnalyzing ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Analyzing...
                      </>
                    ) : (
                      <>
                        <Shield className="mr-2 h-4 w-4" />
                        Analyze Prompt
                      </>
                    )}
                  </Button>
                  {promptResult && (
                    <Button
                      onClick={() => exportToPDF('prompt')}
                      variant="outline"
                    >
                      <FileText className="mr-2 h-4 w-4" />
                      Export PDF
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>

            {promptResult && (
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle>Analysis Results</CardTitle>
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-muted-foreground">Risk Score:</span>
                      <span className={`text-2xl font-bold ${getRiskColor(promptResult.risk_score)}`}>
                        {promptResult.risk_score}/5
                      </span>
                    </div>
                  </div>
                  <CardDescription>{promptResult.summary}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {promptResult.vulnerabilities.length > 0 && (
                    <div className="space-y-3">
                      <h3 className="font-semibold flex items-center gap-2">
                        <AlertTriangle className="h-5 w-5 text-orange-600" />
                        Vulnerabilities Found
                      </h3>
                      {promptResult.vulnerabilities.map((vuln, idx) => (
                        <Alert key={idx}>
                          <AlertDescription className="space-y-2">
                            <div className="flex items-center justify-between">
                              <span className="font-semibold">{vuln.type}</span>
                              <Badge variant={getSeverityColor(vuln.severity) as any}>
                                {vuln.severity}
                              </Badge>
                            </div>
                            <p className="text-sm text-muted-foreground">{vuln.description}</p>
                            <p className="text-sm">
                              <strong>Recommendation:</strong> {vuln.recommendation}
                            </p>
                          </AlertDescription>
                        </Alert>
                      ))}
                    </div>
                  )}

                  {promptResult.recommendations.length > 0 && (
                    <div className="space-y-3">
                      <h3 className="font-semibold flex items-center gap-2">
                        <CheckCircle2 className="h-5 w-5 text-green-600" />
                        Recommendations
                      </h3>
                      <ul className="space-y-2">
                        {promptResult.recommendations.map((rec, idx) => (
                          <li key={idx} className="flex items-start gap-2 text-sm">
                            <CheckCircle2 className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                            <span>{rec}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="code" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Code Security Analysis</CardTitle>
                <CardDescription>
                  Scan your code for security vulnerabilities and coding issues
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Enter your code</Label>
                  <Textarea
                    value={codeText}
                    onChange={(e) => setCodeText(e.target.value)}
                    placeholder="Paste your code here..."
                    className="min-h-[200px] font-mono text-sm"
                  />
                </div>
                <div className="flex gap-2">
                  <Button
                    onClick={analyzeCode}
                    disabled={codeAnalyzing}
                    className="flex-1"
                  >
                    {codeAnalyzing ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Analyzing...
                      </>
                    ) : (
                      <>
                        <Code className="mr-2 h-4 w-4" />
                        Analyze Code
                      </>
                    )}
                  </Button>
                  {codeResult && (
                    <Button
                      onClick={() => exportToPDF('code')}
                      variant="outline"
                    >
                      <FileText className="mr-2 h-4 w-4" />
                      Export PDF
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>

            {codeResult && (
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle>Analysis Results</CardTitle>
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-muted-foreground">Risk Score:</span>
                      <span className={`text-2xl font-bold ${getRiskColor(codeResult.risk_score)}`}>
                        {codeResult.risk_score}/5
                      </span>
                    </div>
                  </div>
                  <CardDescription>{codeResult.summary}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {codeResult.vulnerabilities.length > 0 && (
                    <div className="space-y-3">
                      <h3 className="font-semibold flex items-center gap-2">
                        <AlertTriangle className="h-5 w-5 text-orange-600" />
                        Vulnerabilities Found
                      </h3>
                      {codeResult.vulnerabilities.map((vuln, idx) => (
                        <Alert key={idx}>
                          <AlertDescription className="space-y-2">
                            <div className="flex items-center justify-between">
                              <span className="font-semibold">{vuln.type}</span>
                              <div className="flex items-center gap-2">
                                {vuln.line && (
                                  <Badge variant="outline">Line {vuln.line}</Badge>
                                )}
                                <Badge variant={getSeverityColor(vuln.severity) as any}>
                                  {vuln.severity}
                                </Badge>
                              </div>
                            </div>
                            <p className="text-sm text-muted-foreground">{vuln.description}</p>
                            <p className="text-sm">
                              <strong>Recommendation:</strong> {vuln.recommendation}
                            </p>
                          </AlertDescription>
                        </Alert>
                      ))}
                    </div>
                  )}

                  {codeResult.recommendations.length > 0 && (
                    <div className="space-y-3">
                      <h3 className="font-semibold flex items-center gap-2">
                        <CheckCircle2 className="h-5 w-5 text-green-600" />
                        Recommendations
                      </h3>
                      <ul className="space-y-2">
                        {codeResult.recommendations.map((rec, idx) => (
                          <li key={idx} className="flex items-start gap-2 text-sm">
                            <CheckCircle2 className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                            <span>{rec}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
