import React, { useState } from 'react';
import { AlertTriangle, CheckCircle, XCircle, Info } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';

/**
 * Pre-Flight Permission Check Component
 * 
 * 3-question screening to identify risky permissions before assessment
 * Warns users but does not block them from proceeding
 */

const PreFlightCheck = ({ onComplete }) => {
  const [answers, setAnswers] = useState({
    question1: null,
    question2: null,
    question3: null
  });

  const [showResults, setShowResults] = useState(false);

  const questions = [
    {
      id: 'question1',
      text: 'Does your AI agent require access to Customer Content (customer-uploaded files, messages, or communications)?',
      warning: 'Customer Content is NOT allowed on any Low Code platform. You must use High Code solutions with proper security controls.',
      riskLevel: 'critical'
    },
    {
      id: 'question2',
      text: 'Will your AI agent handle Highly Sensitive Security Data (API keys, passwords, encryption keys, or security credentials)?',
      warning: 'Highly Sensitive Security Data is NOT allowed on any platform. You must implement secure credential management systems.',
      riskLevel: 'critical'
    },
    {
      id: 'question3',
      text: 'Does your AI agent need to process Customer-Created Metadata (customer-defined tags, labels, or custom attributes)?',
      warning: 'Customer-Created Metadata is NOT allowed on any Low Code platform. Consider using High Code solutions or redesigning your approach.',
      riskLevel: 'critical'
    }
  ];

  const handleAnswer = (questionId, answer) => {
    setAnswers(prev => ({
      ...prev,
      [questionId]: answer
    }));
  };

  const handleSubmit = () => {
    setShowResults(true);
  };

  const handleContinue = () => {
    const warnings = [];
    questions.forEach(q => {
      if (answers[q.id] === true) {
        warnings.push({
          question: q.text,
          warning: q.warning,
          riskLevel: q.riskLevel
        });
      }
    });

    onComplete({
      passed: warnings.length === 0,
      warnings: warnings,
      answers: answers
    });
  };

  const allAnswered = Object.values(answers).every(a => a !== null);
  const hasWarnings = Object.values(answers).some(a => a === true);
  const warningCount = Object.values(answers).filter(a => a === true).length;

  if (showResults) {
    return (
      <Card className="w-full max-w-4xl mx-auto border-2" style={{ borderColor: hasWarnings ? '#FF9900' : '#232F3E' }}>
        <CardHeader className="bg-gradient-to-r from-[#232F3E] to-[#37475A] text-white">
          <CardTitle className="flex items-center gap-2 text-2xl">
            {hasWarnings ? (
              <>
                <AlertTriangle className="h-6 w-6 text-[#FF9900]" />
                Pre-Flight Check: Warnings Detected
              </>
            ) : (
              <>
                <CheckCircle className="h-6 w-6 text-green-400" />
                Pre-Flight Check: Passed
              </>
            )}
          </CardTitle>
          <CardDescription className="text-gray-200">
            {hasWarnings 
              ? `${warningCount} critical permission ${warningCount === 1 ? 'issue' : 'issues'} identified`
              : 'No critical permission issues detected'
            }
          </CardDescription>
        </CardHeader>
        <CardContent className="p-6 space-y-4">
          {hasWarnings ? (
            <>
              <Alert className="border-[#FF9900] bg-orange-50">
                <AlertTriangle className="h-5 w-5 text-[#FF9900]" />
                <AlertDescription className="text-gray-800 ml-2">
                  <strong>Warning:</strong> Your project requires access to restricted data types. Please review the warnings below carefully.
                </AlertDescription>
              </Alert>

              <div className="space-y-3">
                {questions.map(q => {
                  if (answers[q.id] === true) {
                    return (
                      <div key={q.id} className="bg-red-50 border-l-4 border-red-500 p-4 rounded">
                        <div className="flex items-start gap-3">
                          <XCircle className="h-5 w-5 text-red-500 mt-0.5 flex-shrink-0" />
                          <div>
                            <p className="font-semibold text-red-900 mb-1">{q.text}</p>
                            <p className="text-red-700 text-sm">{q.warning}</p>
                          </div>
                        </div>
                      </div>
                    );
                  }
                  return null;
                })}
              </div>

              <div className="bg-blue-50 border-l-4 border-blue-500 p-4 rounded mt-4">
                <div className="flex items-start gap-3">
                  <Info className="h-5 w-5 text-blue-500 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="font-semibold text-blue-900 mb-1">Recommendations:</p>
                    <ul className="text-blue-800 text-sm space-y-1 list-disc list-inside">
                      <li>Consider using <strong>High Code platforms</strong> (AWS Bedrock RAG Agent, Multi-Agent, Lambda, or Custom GenAI)</li>
                      <li>Implement proper <strong>data classification and access controls</strong></li>
                      <li>Ensure <strong>security review</strong> is completed before deployment</li>
                      <li>Review the <strong>Mechanism page</strong> for platform compatibility details</li>
                      <li>Consider <strong>redesigning your approach</strong> to avoid restricted data types if possible</li>
                    </ul>
                  </div>
                </div>
              </div>

              <div className="bg-yellow-50 border border-yellow-300 p-4 rounded mt-4">
                <p className="text-yellow-900 text-sm">
                  <strong>Note:</strong> These warnings will not prevent you from completing the assessment, but they will be flagged in your final report. 
                  You are responsible for ensuring compliance with AWS data handling policies.
                </p>
              </div>
            </>
          ) : (
            <>
              <Alert className="border-green-500 bg-green-50">
                <CheckCircle className="h-5 w-5 text-green-600" />
                <AlertDescription className="text-gray-800 ml-2">
                  <strong>Good news!</strong> Your project does not require access to restricted data types based on your responses.
                </AlertDescription>
              </Alert>

              <div className="bg-blue-50 border-l-4 border-blue-500 p-4 rounded">
                <div className="flex items-start gap-3">
                  <Info className="h-5 w-5 text-blue-500 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-blue-900 text-sm">
                      You may proceed with both <strong>Low Code</strong> and <strong>High Code</strong> platforms. 
                      Review the Mechanism page to select the most appropriate platform for your use case.
                    </p>
                  </div>
                </div>
              </div>
            </>
          )}

          <div className="flex justify-end gap-3 mt-6 pt-4 border-t">
            <Button
              variant="outline"
              onClick={() => setShowResults(false)}
              className="border-gray-300"
            >
              Review Answers
            </Button>
            <Button
              onClick={handleContinue}
              className="bg-[#FF9900] hover:bg-[#EC7211] text-white"
            >
              Continue to Assessment
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full max-w-4xl mx-auto border-2 border-[#232F3E]">
      <CardHeader className="bg-gradient-to-r from-[#232F3E] to-[#37475A] text-white">
        <CardTitle className="text-2xl">Pre-Flight Permission Check</CardTitle>
        <CardDescription className="text-gray-200">
          Answer these 3 questions to identify potential data handling restrictions
        </CardDescription>
      </CardHeader>
      <CardContent className="p-6">
        <Alert className="mb-6 border-blue-500 bg-blue-50">
          <Info className="h-5 w-5 text-blue-600" />
          <AlertDescription className="text-gray-800 ml-2">
            This quick check helps identify if your project requires access to restricted data types. 
            <strong> Your answers will not prevent you from proceeding</strong>, but warnings will be included in your assessment report.
          </AlertDescription>
        </Alert>

        <div className="space-y-6">
          {questions.map((q, index) => (
            <div key={q.id} className="bg-white border border-gray-200 rounded-lg p-5 shadow-sm">
              <div className="flex items-start gap-3 mb-4">
                <div className="flex-shrink-0 w-8 h-8 rounded-full bg-[#232F3E] text-white flex items-center justify-center font-semibold">
                  {index + 1}
                </div>
                <p className="text-gray-900 font-medium flex-1">{q.text}</p>
              </div>
              
              <div className="flex gap-3 ml-11">
                <Button
                  variant={answers[q.id] === true ? 'default' : 'outline'}
                  onClick={() => handleAnswer(q.id, true)}
                  className={answers[q.id] === true 
                    ? 'bg-[#FF9900] hover:bg-[#EC7211] text-white' 
                    : 'border-gray-300 hover:bg-gray-50'
                  }
                >
                  Yes
                </Button>
                <Button
                  variant={answers[q.id] === false ? 'default' : 'outline'}
                  onClick={() => handleAnswer(q.id, false)}
                  className={answers[q.id] === false 
                    ? 'bg-[#232F3E] hover:bg-[#37475A] text-white' 
                    : 'border-gray-300 hover:bg-gray-50'
                  }
                >
                  No
                </Button>
              </div>
            </div>
          ))}
        </div>

        <div className="flex justify-end mt-8 pt-6 border-t">
          <Button
            onClick={handleSubmit}
            disabled={!allAnswered}
            className="bg-[#FF9900] hover:bg-[#EC7211] text-white disabled:bg-gray-300 disabled:cursor-not-allowed"
          >
            Review Results
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default PreFlightCheck;

